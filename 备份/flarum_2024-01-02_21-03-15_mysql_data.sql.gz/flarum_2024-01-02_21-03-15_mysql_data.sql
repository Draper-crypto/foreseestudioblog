-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: flarum
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_tokens`
--

DROP TABLE IF EXISTS `access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_tokens` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `token` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `access_tokens_token_unique` (`token`),
  KEY `access_tokens_user_id_foreign` (`user_id`),
  KEY `access_tokens_type_index` (`type`),
  CONSTRAINT `access_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `access_tokens`
--

LOCK TABLES `access_tokens` WRITE;
/*!40000 ALTER TABLE `access_tokens` DISABLE KEYS */;
INSERT INTO `access_tokens` VALUES (1,'y0aOrwXPkCKG30R0TgnRpYqqmHMx9Ye2aQOCv8PM',1,'2023-12-27 02:34:19','2023-12-27 02:32:07','session_remember',NULL,'192.168.1.65','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'),(21,'tFtlsguN2XrAlb1xJ1m1ltkfD5pfiiCoJTj3Ma4h',3,'2023-12-28 08:39:56','2023-12-28 08:37:31','session_remember',NULL,'127.0.0.1','Mozilla/5.0 (iPhone; CPU iPhone OS 17_0_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.44(0x18002c2f) NetType/4G Language/zh_CN'),(35,'8Xk1ChRMHCcRbgARsaKh3h92grtPnZKlrYYKag4L',1,'2024-01-02 13:00:16','2024-01-02 12:58:24','session',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0');
/*!40000 ALTER TABLE `access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `allowed_ips` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `last_activity_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `api_keys_key_unique` (`key`),
  KEY `api_keys_user_id_foreign` (`user_id`),
  CONSTRAINT `api_keys_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `api_keys`
--

LOCK TABLES `api_keys` WRITE;
/*!40000 ALTER TABLE `api_keys` DISABLE KEYS */;
/*!40000 ALTER TABLE `api_keys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_meta`
--

DROP TABLE IF EXISTS `blog_meta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_meta` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `discussion_id` int(10) unsigned NOT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `is_featured` tinyint(1) DEFAULT '0',
  `is_sized` tinyint(1) DEFAULT '0',
  `is_pending_review` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `blog_meta_discussion_id_foreign` (`discussion_id`),
  CONSTRAINT `blog_meta_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_meta`
--

LOCK TABLES `blog_meta` WRITE;
/*!40000 ALTER TABLE `blog_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_meta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_emojis`
--

DROP TABLE IF EXISTS `custom_emojis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_emojis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_to_replace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_emojis`
--

LOCK TABLES `custom_emojis` WRITE;
/*!40000 ALTER TABLE `custom_emojis` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_emojis` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_sticky_tag`
--

DROP TABLE IF EXISTS `discussion_sticky_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_sticky_tag` (
  `discussion_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`discussion_id`,`tag_id`),
  KEY `discussion_sticky_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `discussion_sticky_tag_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_sticky_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_sticky_tag`
--

LOCK TABLES `discussion_sticky_tag` WRITE;
/*!40000 ALTER TABLE `discussion_sticky_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `discussion_sticky_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_tag`
--

DROP TABLE IF EXISTS `discussion_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_tag` (
  `discussion_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`discussion_id`,`tag_id`),
  KEY `discussion_tag_tag_id_foreign` (`tag_id`),
  CONSTRAINT `discussion_tag_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discussion_tag_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_tag`
--

LOCK TABLES `discussion_tag` WRITE;
/*!40000 ALTER TABLE `discussion_tag` DISABLE KEYS */;
INSERT INTO `discussion_tag` VALUES (1,2,'2023-12-27 14:36:11'),(2,1,'2023-12-27 05:42:39'),(3,2,'2023-12-27 14:42:00'),(8,1,'2023-12-27 14:16:58'),(9,1,'2023-12-27 15:04:07'),(10,1,'2023-12-28 04:59:48'),(11,1,'2023-12-28 05:40:45'),(12,1,'2023-12-28 05:53:08'),(13,1,'2023-12-28 08:07:56'),(14,1,'2023-12-28 08:08:37'),(15,1,'2023-12-29 17:34:23'),(17,1,'2023-12-31 07:54:57'),(18,1,'2023-12-31 08:16:24'),(19,1,'2023-12-31 08:43:46');
/*!40000 ALTER TABLE `discussion_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_user`
--

DROP TABLE IF EXISTS `discussion_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_user` (
  `user_id` int(10) unsigned NOT NULL,
  `discussion_id` int(10) unsigned NOT NULL,
  `last_read_at` datetime DEFAULT NULL,
  `last_read_post_number` int(10) unsigned DEFAULT NULL,
  `subscription` enum('follow','ignore') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bookmarked_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`user_id`,`discussion_id`),
  KEY `discussion_user_discussion_id_foreign` (`discussion_id`),
  KEY `discussion_user_bookmarked_at_index` (`bookmarked_at`),
  CONSTRAINT `discussion_user_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `discussion_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_user`
--

LOCK TABLES `discussion_user` WRITE;
/*!40000 ALTER TABLE `discussion_user` DISABLE KEYS */;
INSERT INTO `discussion_user` VALUES (1,1,'2023-12-27 14:37:04',2,NULL,NULL),(1,2,'2023-12-27 15:53:31',2,NULL,NULL),(1,3,'2023-12-27 14:42:06',2,NULL,NULL),(1,8,'2023-12-27 14:59:08',2,NULL,NULL),(1,9,'2023-12-27 15:04:07',1,NULL,NULL),(1,10,'2023-12-28 05:35:54',1,NULL,NULL),(1,11,'2023-12-28 05:46:52',1,NULL,NULL),(1,12,'2023-12-28 06:32:13',1,NULL,NULL),(1,13,'2023-12-28 08:07:57',1,NULL,NULL),(1,14,'2023-12-28 08:08:38',1,NULL,NULL),(1,15,'2023-12-29 17:48:01',2,NULL,NULL),(1,17,'2023-12-31 07:54:58',1,NULL,NULL),(1,18,'2023-12-31 08:16:25',1,NULL,NULL),(1,19,'2023-12-31 08:43:46',1,NULL,NULL),(2,1,'2023-12-28 05:36:28',1,NULL,NULL),(2,2,'2023-12-28 05:36:25',1,NULL,NULL),(2,3,'2023-12-28 05:36:27',1,NULL,NULL),(2,8,'2023-12-28 05:36:27',1,NULL,NULL),(2,9,'2023-12-28 05:36:26',1,NULL,NULL),(2,10,'2023-12-28 04:59:51',1,NULL,NULL),(2,11,'2023-12-28 05:40:54',1,NULL,NULL),(2,12,'2023-12-28 05:53:10',1,NULL,NULL),(3,2,'2023-12-28 08:37:59',2,NULL,NULL),(3,12,'2023-12-28 08:41:07',1,'follow',NULL);
/*!40000 ALTER TABLE `discussion_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussion_views`
--

DROP TABLE IF EXISTS `discussion_views`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussion_views` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `discussion_id` int(10) unsigned NOT NULL,
  `ip` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `visited_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `discussion_views_discussion_id_foreign` (`discussion_id`),
  KEY `discussion_views_user_id_foreign` (`user_id`),
  CONSTRAINT `discussion_views_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `discussion_views_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussion_views`
--

LOCK TABLES `discussion_views` WRITE;
/*!40000 ALTER TABLE `discussion_views` DISABLE KEYS */;
INSERT INTO `discussion_views` VALUES (1,1,1,'127.0.0.1','2023-12-27 03:09:27'),(2,1,2,'127.0.0.1','2023-12-27 05:42:40'),(3,1,3,'127.0.0.1','2023-12-27 05:48:11'),(4,1,3,'127.0.0.1','2023-12-27 05:50:11'),(9,NULL,3,'127.0.0.1','2023-12-27 06:57:22'),(10,NULL,2,'127.0.0.1','2023-12-27 06:57:22'),(11,NULL,1,'127.0.0.1','2023-12-27 06:57:26'),(13,NULL,2,'127.0.0.1','2023-12-27 06:57:40'),(15,NULL,1,'127.0.0.1','2023-12-27 13:30:22'),(16,NULL,2,'127.0.0.1','2023-12-27 13:30:23'),(17,NULL,3,'127.0.0.1','2023-12-27 13:30:23'),(20,1,8,'127.0.0.1','2023-12-27 14:16:59'),(21,1,8,'127.0.0.1','2023-12-27 14:19:47'),(22,1,8,'127.0.0.1','2023-12-27 14:33:12'),(23,1,1,'127.0.0.1','2023-12-27 14:36:13'),(24,1,1,'127.0.0.1','2023-12-27 14:36:30'),(25,1,1,'127.0.0.1','2023-12-27 14:36:58'),(26,1,3,'127.0.0.1','2023-12-27 14:42:02'),(27,1,3,'127.0.0.1','2023-12-27 14:44:01'),(28,1,3,'127.0.0.1','2023-12-27 14:44:16'),(29,1,8,'127.0.0.1','2023-12-27 14:59:06'),(30,1,2,'127.0.0.1','2023-12-27 14:59:38'),(31,1,2,'127.0.0.1','2023-12-27 15:00:56'),(32,1,9,'127.0.0.1','2023-12-27 15:04:08'),(33,1,9,'127.0.0.1','2023-12-27 15:05:06'),(34,1,8,'127.0.0.1','2023-12-27 15:11:53'),(35,1,8,'127.0.0.1','2023-12-27 15:13:03'),(36,1,8,'127.0.0.1','2023-12-27 15:53:00'),(37,1,2,'127.0.0.1','2023-12-27 15:53:23'),(38,1,1,'127.0.0.1','2023-12-27 15:53:38'),(39,1,3,'127.0.0.1','2023-12-27 15:54:27'),(40,NULL,9,'127.0.0.1','2023-12-27 16:01:33'),(41,NULL,1,'127.0.0.1','2023-12-27 16:01:33'),(42,NULL,8,'127.0.0.1','2023-12-27 16:01:34'),(43,NULL,3,'127.0.0.1','2023-12-27 16:01:34'),(44,NULL,9,'127.0.0.1','2023-12-27 16:01:34'),(45,NULL,8,'127.0.0.1','2023-12-27 16:01:36'),(46,NULL,1,'127.0.0.1','2023-12-27 16:01:36'),(47,NULL,2,'127.0.0.1','2023-12-27 16:01:38'),(48,NULL,9,'127.0.0.1','2023-12-27 16:01:40'),(49,NULL,8,'127.0.0.1','2023-12-27 16:01:45'),(50,NULL,2,'127.0.0.1','2023-12-27 16:01:45'),(51,NULL,2,'127.0.0.1','2023-12-27 16:01:47'),(52,NULL,1,'127.0.0.1','2023-12-27 16:36:49'),(53,NULL,2,'127.0.0.1','2023-12-27 16:36:50'),(54,NULL,3,'127.0.0.1','2023-12-27 16:36:50'),(55,NULL,8,'127.0.0.1','2023-12-27 16:36:51'),(56,NULL,9,'127.0.0.1','2023-12-27 16:36:52'),(57,1,8,'127.0.0.1','2023-12-28 03:27:10'),(58,2,10,'127.0.0.1','2023-12-28 04:59:52'),(59,2,10,'127.0.0.1','2023-12-28 05:00:02'),(60,1,10,'127.0.0.1','2023-12-28 05:01:55'),(61,1,10,'127.0.0.1','2023-12-28 05:14:17'),(62,1,10,'127.0.0.1','2023-12-28 05:35:44'),(63,1,10,'127.0.0.1','2023-12-28 05:36:02'),(64,2,11,'127.0.0.1','2023-12-28 05:40:54'),(65,2,11,'127.0.0.1','2023-12-28 05:41:00'),(66,2,11,'127.0.0.1','2023-12-28 05:41:19'),(67,1,11,'127.0.0.1','2023-12-28 05:41:52'),(68,2,11,'127.0.0.1','2023-12-28 05:43:14'),(69,2,12,'127.0.0.1','2023-12-28 05:53:11'),(70,2,12,'127.0.0.1','2023-12-28 06:26:31'),(71,2,12,'127.0.0.1','2023-12-28 06:26:51'),(72,NULL,2,'127.0.0.1','2023-12-28 06:43:37'),(73,NULL,12,'127.0.0.1','2023-12-28 06:43:52'),(74,NULL,12,'127.0.0.1','2023-12-28 06:44:06'),(75,1,13,'127.0.0.1','2023-12-28 08:07:58'),(76,1,14,'127.0.0.1','2023-12-28 08:08:39'),(77,3,2,'127.0.0.1','2023-12-28 08:37:51'),(78,3,12,'127.0.0.1','2023-12-28 08:40:16'),(79,3,12,'127.0.0.1','2023-12-28 08:40:47'),(80,1,12,'127.0.0.1','2023-12-28 08:48:54'),(81,1,12,'127.0.0.1','2023-12-28 08:49:12'),(82,NULL,2,'127.0.0.1','2023-12-28 09:50:52'),(83,NULL,10,'127.0.0.1','2023-12-28 16:29:24'),(84,NULL,11,'127.0.0.1','2023-12-28 16:29:26'),(85,NULL,12,'127.0.0.1','2023-12-28 16:29:26'),(86,NULL,13,'127.0.0.1','2023-12-28 16:29:28'),(87,NULL,14,'127.0.0.1','2023-12-28 16:29:28'),(88,NULL,2,'127.0.0.1','2023-12-28 16:29:29'),(89,NULL,3,'127.0.0.1','2023-12-28 16:29:31'),(90,NULL,8,'127.0.0.1','2023-12-28 16:29:32'),(91,NULL,9,'127.0.0.1','2023-12-28 16:29:32'),(92,NULL,13,'127.0.0.1','2023-12-28 20:59:30'),(93,NULL,10,'127.0.0.1','2023-12-29 06:31:08'),(94,NULL,11,'127.0.0.1','2023-12-29 09:05:43'),(95,1,11,'127.0.0.1','2023-12-29 09:05:59');
/*!40000 ALTER TABLE `discussion_views` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `discussions`
--

DROP TABLE IF EXISTS `discussions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discussions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_count` int(11) NOT NULL DEFAULT '1',
  `participant_count` int(10) unsigned NOT NULL DEFAULT '0',
  `post_number_index` int(10) unsigned NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `first_post_id` int(10) unsigned DEFAULT NULL,
  `last_posted_at` datetime DEFAULT NULL,
  `last_posted_user_id` int(10) unsigned DEFAULT NULL,
  `last_post_id` int(10) unsigned DEFAULT NULL,
  `last_post_number` int(10) unsigned DEFAULT NULL,
  `hidden_at` datetime DEFAULT NULL,
  `hidden_user_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `is_approved` tinyint(1) NOT NULL DEFAULT '1',
  `is_sticky` tinyint(1) NOT NULL DEFAULT '0',
  `is_locked` tinyint(1) NOT NULL DEFAULT '0',
  `view_count` int(11) NOT NULL DEFAULT '0',
  `best_answer_post_id` int(10) unsigned DEFAULT NULL,
  `best_answer_user_id` int(10) unsigned DEFAULT NULL,
  `best_answer_notified` tinyint(1) NOT NULL,
  `best_answer_set_at` datetime DEFAULT NULL,
  `frontpage` tinyint(1) NOT NULL DEFAULT '0',
  `frontdate` datetime DEFAULT NULL,
  `is_stickiest` tinyint(1) NOT NULL DEFAULT '0',
  `is_tag_sticky` tinyint(1) NOT NULL DEFAULT '0',
  `article_series_id` int(10) unsigned DEFAULT NULL,
  `article_series_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discussions_hidden_user_id_foreign` (`hidden_user_id`),
  KEY `discussions_first_post_id_foreign` (`first_post_id`),
  KEY `discussions_last_post_id_foreign` (`last_post_id`),
  KEY `discussions_last_posted_at_index` (`last_posted_at`),
  KEY `discussions_last_posted_user_id_index` (`last_posted_user_id`),
  KEY `discussions_created_at_index` (`created_at`),
  KEY `discussions_user_id_index` (`user_id`),
  KEY `discussions_comment_count_index` (`comment_count`),
  KEY `discussions_participant_count_index` (`participant_count`),
  KEY `discussions_hidden_at_index` (`hidden_at`),
  KEY `discussions_is_sticky_created_at_index` (`is_sticky`,`created_at`),
  KEY `discussions_is_sticky_last_posted_at_index` (`is_sticky`,`last_posted_at`),
  KEY `discussions_is_locked_index` (`is_locked`),
  KEY `discussions_best_answer_post_id_foreign` (`best_answer_post_id`),
  KEY `discussions_best_answer_user_id_foreign` (`best_answer_user_id`),
  KEY `discussions_best_answer_set_at_index` (`best_answer_set_at`),
  KEY `discussions_is_stickiest_last_posted_at_index` (`is_stickiest`,`last_posted_at`),
  KEY `discussions_is_stickiest_created_at_index` (`is_stickiest`,`created_at`),
  KEY `discussions_is_tag_sticky_last_posted_at_index` (`is_tag_sticky`,`last_posted_at`),
  KEY `discussions_is_tag_sticky_created_at_index` (`is_tag_sticky`,`created_at`),
  KEY `discussions_article_series_id_foreign` (`article_series_id`),
  FULLTEXT KEY `title` (`title`) /*!50100 WITH PARSER `ngram` */ ,
  CONSTRAINT `discussions_article_series_id_foreign` FOREIGN KEY (`article_series_id`) REFERENCES `tags` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_best_answer_post_id_foreign` FOREIGN KEY (`best_answer_post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_best_answer_user_id_foreign` FOREIGN KEY (`best_answer_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_first_post_id_foreign` FOREIGN KEY (`first_post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_hidden_user_id_foreign` FOREIGN KEY (`hidden_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_last_post_id_foreign` FOREIGN KEY (`last_post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_last_posted_user_id_foreign` FOREIGN KEY (`last_posted_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `discussions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `discussions`
--

LOCK TABLES `discussions` WRITE;
/*!40000 ALTER TABLE `discussions` DISABLE KEYS */;
INSERT INTO `discussions` VALUES (1,' 中文文案排版指北',1,1,0,'2023-12-27 03:09:26',1,1,'2023-12-27 03:09:26',1,1,1,NULL,NULL,'zhong-wen-wen-an-pai-ban-zhi-bei',0,1,0,0,10,NULL,NULL,1,NULL,1,'2023-12-27 15:00:27',0,0,NULL,NULL),(2,'Foresee Studio论坛隐私政策',1,1,0,'2023-12-27 05:42:39',1,2,'2023-12-27 05:42:39',1,2,1,NULL,NULL,'foresee-studiolun-tan-yin-si-zheng-ce',0,1,0,0,15,NULL,NULL,0,NULL,0,NULL,1,0,NULL,NULL),(3,'Markdown语法使用指南',1,1,0,'2023-12-27 05:48:10',1,3,'2023-12-27 05:48:10',1,3,1,NULL,NULL,'markdownyu-fa-shi-yong-zhi-nan',0,1,0,0,11,NULL,NULL,0,NULL,1,'2023-12-27 15:00:29',0,0,NULL,NULL),(8,'更新日志',1,1,0,'2023-12-27 14:16:58',1,8,'2023-12-27 14:16:58',1,8,1,NULL,NULL,'geng-xin-ri-zhi',0,1,0,0,13,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(9,'整理composer安装版本的python脚本',1,1,0,'2023-12-27 15:04:07',1,13,'2023-12-27 15:04:07',1,13,1,NULL,NULL,'zheng-li-composeran-zhuang-ban-ben-de-pythonjiao-ben',0,1,0,0,7,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(10,'FORESEE STUDIO为人工智能领域注入新的活力',1,0,0,'2023-12-28 04:59:48',2,14,'2023-12-28 04:59:48',2,14,1,NULL,NULL,'foresee-studiowei-ren-gong-zhi-neng-ling-yu-zhu-ru-xin-de-huo-li',0,1,0,0,8,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(11,'【独家】先知科技工作室正式更名！',1,0,0,'2023-12-28 05:40:45',2,15,'2023-12-28 05:40:45',2,15,1,NULL,NULL,'du-jia-xian-zhi-ke-ji-gong-zuo-shi-zheng-shi-geng-ming',0,1,0,0,8,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(12,'求知若渴，虚心若愚',1,1,0,'2023-12-28 05:53:08',2,16,'2023-12-28 05:53:08',2,16,1,NULL,NULL,'qiu-zhi-ruo-ke-xu-xin-ruo-yu',0,1,0,0,10,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(13,'Flaurm界面优化',1,1,0,'2023-12-28 08:07:56',1,17,'2023-12-28 08:07:56',1,17,1,NULL,NULL,'flaurmjie-mian-you-hua',0,1,0,0,3,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(14,'安装extiverse/mercury时报错',1,1,0,'2023-12-28 08:08:38',1,18,'2023-12-28 08:08:38',1,18,1,NULL,NULL,'an-zhuang-extiversemercuryshi-bao-cuo',0,1,0,0,2,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(15,'Foresee Studio论坛社区规范',1,1,0,'2023-12-29 17:34:24',1,19,'2023-12-29 17:34:24',1,19,1,NULL,NULL,'foresee-studiolun-tan-she-qu-gui-fan',0,1,0,0,0,NULL,NULL,0,NULL,0,NULL,1,0,NULL,NULL),(17,'《窄门》读书笔记',1,1,0,'2023-12-31 07:54:58',1,22,'2023-12-31 07:54:58',1,22,1,NULL,NULL,'zhai-men-du-shu-bi-ji',0,1,0,0,0,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(18,'随笔03-2023届新生入学分享会',1,1,0,'2023-12-31 08:16:24',1,23,'2023-12-31 08:16:24',1,23,1,NULL,NULL,'sui-bi-03-2023jie-xin-sheng-ru-xue-fen-xiang-hui',0,1,0,0,0,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL),(19,'BBCode',1,1,0,'2023-12-31 08:43:46',1,24,'2023-12-31 08:43:46',1,24,1,NULL,NULL,'bbcode',0,1,0,0,0,NULL,NULL,0,NULL,0,NULL,0,0,NULL,NULL);
/*!40000 ALTER TABLE `discussions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doorkeys`
--

DROP TABLE IF EXISTS `doorkeys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doorkeys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `max_uses` int(10) unsigned NOT NULL,
  `uses` int(10) unsigned NOT NULL,
  `activates` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `doorkeys_group_id_foreign` (`group_id`),
  CONSTRAINT `doorkeys_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doorkeys`
--

LOCK TABLES `doorkeys` WRITE;
/*!40000 ALTER TABLE `doorkeys` DISABLE KEYS */;
/*!40000 ALTER TABLE `doorkeys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci,
  `relationships` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` datetime NOT NULL,
  `scheduled_for` datetime DEFAULT NULL,
  `scheduled_validation_error` mediumtext COLLATE utf8mb4_unicode_ci,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `extra` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drafts_user_id_foreign` (`user_id`),
  CONSTRAINT `drafts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_tokens`
--

DROP TABLE IF EXISTS `email_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_tokens` (
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`token`),
  KEY `email_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `email_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_tokens`
--

LOCK TABLES `email_tokens` WRITE;
/*!40000 ALTER TABLE `email_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flags`
--

DROP TABLE IF EXISTS `flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` int(10) unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason_detail` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `flags_post_id_foreign` (`post_id`),
  KEY `flags_user_id_foreign` (`user_id`),
  KEY `flags_created_at_index` (`created_at`),
  CONSTRAINT `flags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `flags_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flags`
--

LOCK TABLES `flags` WRITE;
/*!40000 ALTER TABLE `flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fof_linguist_strings`
--

DROP TABLE IF EXISTS `fof_linguist_strings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fof_linguist_strings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `locale` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fof_linguist_strings_key_locale_unique` (`key`,`locale`),
  KEY `fof_linguist_strings_key_index` (`key`),
  KEY `fof_linguist_strings_locale_index` (`locale`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fof_linguist_strings`
--

LOCK TABLES `fof_linguist_strings` WRITE;
/*!40000 ALTER TABLE `fof_linguist_strings` DISABLE KEYS */;
/*!40000 ALTER TABLE `fof_linguist_strings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fof_terms_policies`
--

DROP TABLE IF EXISTS `fof_terms_policies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fof_terms_policies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sort` int(10) unsigned DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_message` text COLLATE utf8mb4_unicode_ci,
  `terms_updated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fof_terms_policies_sort_index` (`sort`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fof_terms_policies`
--

LOCK TABLES `fof_terms_policies` WRITE;
/*!40000 ALTER TABLE `fof_terms_policies` DISABLE KEYS */;
INSERT INTO `fof_terms_policies` VALUES (1,NULL,'《Foresee Studio论坛隐私政策》','https://www.foreseestudioblog.top/d/2','管理员更新了《Foresee Studio论坛隐私政策》','2023-12-29 09:16:58','2023-12-29 09:16:45','2023-12-29 09:17:01'),(2,NULL,'《Foresee Studio论坛社区规范》','https://www.foreseestudioblog.top/d/15','管理员更新了《Foresee Studio论坛社区规范》','2023-12-29 09:35:47','2023-12-29 09:35:30','2023-12-29 09:35:51');
/*!40000 ALTER TABLE `fof_terms_policies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fof_terms_policy_user`
--

DROP TABLE IF EXISTS `fof_terms_policy_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fof_terms_policy_user` (
  `policy_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `accepted_at` timestamp NOT NULL,
  PRIMARY KEY (`policy_id`,`user_id`),
  KEY `fof_terms_policy_user_user_id_foreign` (`user_id`),
  KEY `fof_terms_policy_user_accepted_at_index` (`accepted_at`),
  CONSTRAINT `fof_terms_policy_user_policy_id_foreign` FOREIGN KEY (`policy_id`) REFERENCES `fof_terms_policies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fof_terms_policy_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fof_terms_policy_user`
--

LOCK TABLES `fof_terms_policy_user` WRITE;
/*!40000 ALTER TABLE `fof_terms_policy_user` DISABLE KEYS */;
INSERT INTO `fof_terms_policy_user` VALUES (1,1,'2023-12-29 09:28:30'),(2,1,'2023-12-29 09:39:01');
/*!40000 ALTER TABLE `fof_terms_policy_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fof_upload_downloads`
--

DROP TABLE IF EXISTS `fof_upload_downloads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fof_upload_downloads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_id` int(10) unsigned NOT NULL,
  `discussion_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `downloaded_at` timestamp NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fof_upload_downloads_file_id_foreign` (`file_id`),
  KEY `fof_upload_downloads_discussion_id_foreign` (`discussion_id`),
  KEY `fof_upload_downloads_actor_id_foreign` (`actor_id`),
  KEY `fof_upload_downloads_post_id_foreign` (`post_id`),
  CONSTRAINT `fof_upload_downloads_actor_id_foreign` FOREIGN KEY (`actor_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fof_upload_downloads_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fof_upload_downloads_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `fof_upload_files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fof_upload_downloads_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fof_upload_downloads`
--

LOCK TABLES `fof_upload_downloads` WRITE;
/*!40000 ALTER TABLE `fof_upload_downloads` DISABLE KEYS */;
/*!40000 ALTER TABLE `fof_upload_downloads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fof_upload_files`
--

DROP TABLE IF EXISTS `fof_upload_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fof_upload_files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `actor_id` int(10) unsigned DEFAULT NULL,
  `discussion_id` int(10) unsigned DEFAULT NULL,
  `post_id` int(10) unsigned DEFAULT NULL,
  `base_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `upload_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remote_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hide_from_media_manager` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fof_upload_files_actor_id_hide_from_media_manager_index` (`actor_id`,`hide_from_media_manager`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fof_upload_files`
--

LOCK TABLES `fof_upload_files` WRITE;
/*!40000 ALTER TABLE `fof_upload_files` DISABLE KEYS */;
/*!40000 ALTER TABLE `fof_upload_files` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_permission`
--

DROP TABLE IF EXISTS `group_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_permission` (
  `group_id` int(10) unsigned NOT NULL,
  `permission` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`group_id`,`permission`),
  CONSTRAINT `group_permission_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_permission`
--

LOCK TABLES `group_permission` WRITE;
/*!40000 ALTER TABLE `group_permission` DISABLE KEYS */;
INSERT INTO `group_permission` VALUES (2,'discussion.readViewnumber','2023-12-28 05:04:23'),(2,'fof-socialprofile.view','2023-12-28 05:04:41'),(2,'fof-user-bio.view','2023-12-28 05:03:01'),(2,'viewForum',NULL),(3,'blog.autoApprovePosts','2023-12-28 05:02:38'),(3,'blog.writeArticles','2023-12-28 05:02:35'),(3,'discussion.flagPosts','2023-12-27 02:32:09'),(3,'discussion.likePosts','2023-12-27 02:32:48'),(3,'discussion.polls.start','2023-12-28 05:07:19'),(3,'discussion.polls.vote','2023-12-28 05:07:46'),(3,'discussion.reply',NULL),(3,'discussion.replyWithoutApproval','2023-12-27 02:32:17'),(3,'discussion.selectBestAnswerOwnDiscussion','2023-12-27 03:10:52'),(3,'discussion.startWithoutApproval','2023-12-27 02:32:17'),(3,'fof-socialprofile.editOwn','2023-12-27 05:45:43'),(3,'fof-user-bio.editOwn','2023-12-28 05:07:28'),(3,'nearata-cakeday.can_view_anniversaries_page','2023-12-28 05:04:21'),(3,'postWithoutThrottle','2023-12-28 05:09:07'),(3,'searchUsers',NULL),(3,'setProfileCover','2023-12-27 06:02:33'),(3,'startDiscussion',NULL),(3,'user.createModeratorNotes','2023-12-28 05:13:06'),(3,'user.editOwnNickname','2023-12-27 05:49:33'),(3,'user.viewModeratorNotes','2023-12-28 05:13:09'),(4,'blog.canApprovePosts','2023-12-27 06:45:38'),(4,'discussion.approvePosts','2023-12-27 02:32:17'),(4,'discussion.editPosts',NULL),(4,'discussion.front','2023-12-27 05:41:27'),(4,'discussion.hide',NULL),(4,'discussion.hidePosts',NULL),(4,'discussion.lock','2023-12-27 02:32:46'),(4,'discussion.rename',NULL),(4,'discussion.stickiest','2023-12-27 05:51:48'),(4,'discussion.stickiest.tagSticky','2023-12-27 05:51:48'),(4,'discussion.sticky','2023-12-27 02:32:35'),(4,'discussion.tag','2023-12-27 02:32:20'),(4,'discussion.viewFlags','2023-12-27 02:32:09'),(4,'discussion.viewIpsPosts',NULL),(4,'fof-socialprofile.editAny','2023-12-27 05:45:43'),(4,'fof-upload.deleteUserUploads','2023-12-29 17:27:09'),(4,'fof-upload.viewUserUploads','2023-12-29 17:27:09'),(4,'user.saveDrafts','2023-12-27 03:15:08'),(4,'user.scheduleDrafts','2023-12-27 03:15:09'),(4,'user.suspend','2023-12-27 02:32:31'),(4,'user.viewLastSeenAt',NULL);
/*!40000 ALTER TABLE `group_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_user`
--

DROP TABLE IF EXISTS `group_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_user` (
  `user_id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`group_id`),
  KEY `group_user_group_id_foreign` (`group_id`),
  CONSTRAINT `group_user_group_id_foreign` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_user`
--

LOCK TABLES `group_user` WRITE;
/*!40000 ALTER TABLE `group_user` DISABLE KEYS */;
INSERT INTO `group_user` VALUES (1,1,'2023-12-27 02:32:07'),(2,4,'2023-12-28 05:46:30');
/*!40000 ALTER TABLE `group_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name_singular` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_plural` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
INSERT INTO `groups` VALUES (1,'Admin','Admins','#B72A2A','fas fa-wrench',0,NULL,NULL),(2,'Guest','Guests',NULL,NULL,0,NULL,NULL),(3,'Member','Members',NULL,NULL,0,NULL,NULL),(4,'Mod','Mods','#80349E','fas fa-bolt',0,NULL,NULL);
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `links`
--

DROP TABLE IF EXISTS `links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `links` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int(11) DEFAULT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT '0',
  `is_newtab` tinyint(1) NOT NULL DEFAULT '0',
  `parent_id` int(10) unsigned DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `visibility` enum('everyone','members','guests') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'everyone',
  PRIMARY KEY (`id`),
  KEY `links_parent_id_foreign` (`parent_id`),
  KEY `links_visibility_index` (`visibility`),
  CONSTRAINT `links_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `links` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `links`
--

LOCK TABLES `links` WRITE;
/*!40000 ALTER TABLE `links` DISABLE KEYS */;
INSERT INTO `links` VALUES (1,'John\'s Blog','https://www.draper-crypto.top/',0,0,1,NULL,'','everyone'),(2,'About us','https://foreseestudio.top/',1,0,1,NULL,'','everyone'),(3,'其他','',2,0,0,NULL,'','everyone'),(4,'7-104文件传输系统','http://jlstudio.natapp1.cc',0,0,1,3,'','everyone'),(5,'ChatGPT Next','https://www.rjjndsgzs.top/',1,0,1,3,'','everyone');
/*!40000 ALTER TABLE `links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_providers`
--

DROP TABLE IF EXISTS `login_providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_providers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `provider` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_providers_provider_identifier_unique` (`provider`,`identifier`),
  KEY `login_providers_user_id_foreign` (`user_id`),
  CONSTRAINT `login_providers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_providers`
--

LOCK TABLES `login_providers` WRITE;
/*!40000 ALTER TABLE `login_providers` DISABLE KEYS */;
/*!40000 ALTER TABLE `login_providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=270 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2015_02_24_000000_create_access_tokens_table',NULL),(2,'2015_02_24_000000_create_api_keys_table',NULL),(3,'2015_02_24_000000_create_config_table',NULL),(4,'2015_02_24_000000_create_discussions_table',NULL),(5,'2015_02_24_000000_create_email_tokens_table',NULL),(6,'2015_02_24_000000_create_groups_table',NULL),(7,'2015_02_24_000000_create_notifications_table',NULL),(8,'2015_02_24_000000_create_password_tokens_table',NULL),(9,'2015_02_24_000000_create_permissions_table',NULL),(10,'2015_02_24_000000_create_posts_table',NULL),(11,'2015_02_24_000000_create_users_discussions_table',NULL),(12,'2015_02_24_000000_create_users_groups_table',NULL),(13,'2015_02_24_000000_create_users_table',NULL),(14,'2015_09_15_000000_create_auth_tokens_table',NULL),(15,'2015_09_20_224327_add_hide_to_discussions',NULL),(16,'2015_09_22_030432_rename_notification_read_time',NULL),(17,'2015_10_07_130531_rename_config_to_settings',NULL),(18,'2015_10_24_194000_add_ip_address_to_posts',NULL),(19,'2015_12_05_042721_change_access_tokens_columns',NULL),(20,'2015_12_17_194247_change_settings_value_column_to_text',NULL),(21,'2016_02_04_095452_add_slug_to_discussions',NULL),(22,'2017_04_07_114138_add_is_private_to_discussions',NULL),(23,'2017_04_07_114138_add_is_private_to_posts',NULL),(24,'2018_01_11_093900_change_access_tokens_columns',NULL),(25,'2018_01_11_094000_change_access_tokens_add_foreign_keys',NULL),(26,'2018_01_11_095000_change_api_keys_columns',NULL),(27,'2018_01_11_101800_rename_auth_tokens_to_registration_tokens',NULL),(28,'2018_01_11_102000_change_registration_tokens_rename_id_to_token',NULL),(29,'2018_01_11_102100_change_registration_tokens_created_at_to_datetime',NULL),(30,'2018_01_11_120604_change_posts_table_to_innodb',NULL),(31,'2018_01_11_155200_change_discussions_rename_columns',NULL),(32,'2018_01_11_155300_change_discussions_add_foreign_keys',NULL),(33,'2018_01_15_071700_rename_users_discussions_to_discussion_user',NULL),(34,'2018_01_15_071800_change_discussion_user_rename_columns',NULL),(35,'2018_01_15_071900_change_discussion_user_add_foreign_keys',NULL),(36,'2018_01_15_072600_change_email_tokens_rename_id_to_token',NULL),(37,'2018_01_15_072700_change_email_tokens_add_foreign_keys',NULL),(38,'2018_01_15_072800_change_email_tokens_created_at_to_datetime',NULL),(39,'2018_01_18_130400_rename_permissions_to_group_permission',NULL),(40,'2018_01_18_130500_change_group_permission_add_foreign_keys',NULL),(41,'2018_01_18_130600_rename_users_groups_to_group_user',NULL),(42,'2018_01_18_130700_change_group_user_add_foreign_keys',NULL),(43,'2018_01_18_133000_change_notifications_columns',NULL),(44,'2018_01_18_133100_change_notifications_add_foreign_keys',NULL),(45,'2018_01_18_134400_change_password_tokens_rename_id_to_token',NULL),(46,'2018_01_18_134500_change_password_tokens_add_foreign_keys',NULL),(47,'2018_01_18_134600_change_password_tokens_created_at_to_datetime',NULL),(48,'2018_01_18_135000_change_posts_rename_columns',NULL),(49,'2018_01_18_135100_change_posts_add_foreign_keys',NULL),(50,'2018_01_30_112238_add_fulltext_index_to_discussions_title',NULL),(51,'2018_01_30_220100_create_post_user_table',NULL),(52,'2018_01_30_222900_change_users_rename_columns',NULL),(55,'2018_09_15_041340_add_users_indicies',NULL),(56,'2018_09_15_041828_add_discussions_indicies',NULL),(57,'2018_09_15_043337_add_notifications_indices',NULL),(58,'2018_09_15_043621_add_posts_indices',NULL),(59,'2018_09_22_004100_change_registration_tokens_columns',NULL),(60,'2018_09_22_004200_create_login_providers_table',NULL),(61,'2018_10_08_144700_add_shim_prefix_to_group_icons',NULL),(62,'2019_10_12_195349_change_posts_add_discussion_foreign_key',NULL),(63,'2020_03_19_134512_change_discussions_default_comment_count',NULL),(64,'2020_04_21_130500_change_permission_groups_add_is_hidden',NULL),(65,'2021_03_02_040000_change_access_tokens_add_type',NULL),(66,'2021_03_02_040500_change_access_tokens_add_id',NULL),(67,'2021_03_02_041000_change_access_tokens_add_title_ip_agent',NULL),(68,'2021_04_18_040500_change_migrations_add_id_primary_key',NULL),(69,'2021_04_18_145100_change_posts_content_column_to_mediumtext',NULL),(70,'2018_07_21_000000_seed_default_groups',NULL),(71,'2018_07_21_000100_seed_default_group_permissions',NULL),(72,'2021_05_10_000000_rename_permissions',NULL),(73,'2022_05_20_000000_add_timestamps_to_groups_table',NULL),(74,'2022_05_20_000001_add_created_at_to_group_user_table',NULL),(75,'2022_05_20_000002_add_created_at_to_group_permission_table',NULL),(76,'2022_07_14_000000_add_type_index_to_posts',NULL),(77,'2022_07_14_000001_add_type_created_at_composite_index_to_posts',NULL),(78,'2022_08_06_000000_change_access_tokens_last_activity_at_to_nullable',NULL),(79,'2015_09_02_000000_add_flags_read_time_to_users_table','flarum-flags'),(80,'2015_09_02_000000_create_flags_table','flarum-flags'),(81,'2017_07_22_000000_add_default_permissions','flarum-flags'),(82,'2018_06_27_101500_change_flags_rename_time_to_created_at','flarum-flags'),(83,'2018_06_27_101600_change_flags_add_foreign_keys','flarum-flags'),(84,'2018_06_27_105100_change_users_rename_flags_read_time_to_read_flags_at','flarum-flags'),(85,'2018_09_15_043621_add_flags_indices','flarum-flags'),(86,'2019_10_22_000000_change_reason_text_col_type','flarum-flags'),(87,'2015_09_21_011527_add_is_approved_to_discussions','flarum-approval'),(88,'2015_09_21_011706_add_is_approved_to_posts','flarum-approval'),(89,'2017_07_22_000000_add_default_permissions','flarum-approval'),(90,'2015_02_24_000000_create_discussions_tags_table','flarum-tags'),(91,'2015_02_24_000000_create_tags_table','flarum-tags'),(92,'2015_02_24_000000_create_users_tags_table','flarum-tags'),(93,'2015_02_24_000000_set_default_settings','flarum-tags'),(94,'2015_10_19_061223_make_slug_unique','flarum-tags'),(95,'2017_07_22_000000_add_default_permissions','flarum-tags'),(96,'2018_06_27_085200_change_tags_columns','flarum-tags'),(97,'2018_06_27_085300_change_tags_add_foreign_keys','flarum-tags'),(98,'2018_06_27_090400_rename_users_tags_to_tag_user','flarum-tags'),(99,'2018_06_27_100100_change_tag_user_rename_read_time_to_marked_as_read_at','flarum-tags'),(100,'2018_06_27_100200_change_tag_user_add_foreign_keys','flarum-tags'),(101,'2018_06_27_103000_rename_discussions_tags_to_discussion_tag','flarum-tags'),(102,'2018_06_27_103100_add_discussion_tag_foreign_keys','flarum-tags'),(103,'2019_04_21_000000_add_icon_to_tags_table','flarum-tags'),(104,'2022_05_20_000003_add_timestamps_to_tags_table','flarum-tags'),(105,'2022_05_20_000004_add_created_at_to_discussion_tag_table','flarum-tags'),(106,'2023_03_01_000000_create_post_mentions_tag_table','flarum-tags'),(107,'2015_05_11_000000_add_suspended_until_to_users_table','flarum-suspend'),(108,'2015_09_14_000000_rename_suspended_until_column','flarum-suspend'),(109,'2017_07_22_000000_add_default_permissions','flarum-suspend'),(110,'2018_06_27_111400_change_users_rename_suspend_until_to_suspended_until','flarum-suspend'),(111,'2021_10_27_000000_add_suspend_reason_and_message','flarum-suspend'),(112,'2015_05_11_000000_add_subscription_to_users_discussions_table','flarum-subscriptions'),(113,'2015_02_24_000000_add_sticky_to_discussions','flarum-sticky'),(114,'2017_07_22_000000_add_default_permissions','flarum-sticky'),(115,'2018_09_15_043621_add_discussions_indices','flarum-sticky'),(116,'2021_01_13_000000_add_discussion_last_posted_at_indices','flarum-sticky'),(117,'2015_05_11_000000_create_mentions_posts_table','flarum-mentions'),(118,'2015_05_11_000000_create_mentions_users_table','flarum-mentions'),(119,'2018_06_27_102000_rename_mentions_posts_to_post_mentions_post','flarum-mentions'),(120,'2018_06_27_102100_rename_mentions_users_to_post_mentions_user','flarum-mentions'),(121,'2018_06_27_102200_change_post_mentions_post_rename_mentions_id_to_mentions_post_id','flarum-mentions'),(122,'2018_06_27_102300_change_post_mentions_post_add_foreign_keys','flarum-mentions'),(123,'2018_06_27_102400_change_post_mentions_user_rename_mentions_id_to_mentions_user_id','flarum-mentions'),(124,'2018_06_27_102500_change_post_mentions_user_add_foreign_keys','flarum-mentions'),(125,'2021_04_19_000000_set_default_settings','flarum-mentions'),(126,'2022_05_20_000005_add_created_at_to_post_mentions_post_table','flarum-mentions'),(127,'2022_05_20_000006_add_created_at_to_post_mentions_user_table','flarum-mentions'),(128,'2022_10_21_000000_create_post_mentions_group_table','flarum-mentions'),(129,'2021_03_25_000000_default_settings','flarum-markdown'),(130,'2015_02_24_000000_add_locked_to_discussions','flarum-lock'),(131,'2017_07_22_000000_add_default_permissions','flarum-lock'),(132,'2018_09_15_043621_add_discussions_indices','flarum-lock'),(133,'2015_05_11_000000_create_posts_likes_table','flarum-likes'),(134,'2015_09_04_000000_add_default_like_permissions','flarum-likes'),(135,'2018_06_27_100600_rename_posts_likes_to_post_likes','flarum-likes'),(136,'2018_06_27_100700_change_post_likes_add_foreign_keys','flarum-likes'),(137,'2021_05_10_094200_add_created_at_to_post_likes_table','flarum-likes'),(138,'2018_09_29_060444_replace_emoji_shorcuts_with_unicode','flarum-emoji'),(139,'2019_09_22_01_rename_flagrow_tables','fof-linguist'),(140,'2019_09_22_02_create_strings_table','fof-linguist'),(141,'2021_02_24_000000_default_settings','askvortsov-checklist'),(142,'2022_08_17_alter_discussion_user_add_bookmarked','clarkwinkelmann-discussion-bookmarks'),(143,'2017_11_07_223624_discussions_add_views','michaelbelgium-discussion-views'),(144,'2018_11_30_141817_discussions_rename_views','michaelbelgium-discussion-views'),(145,'2020_01_11_220612_add_discussionviews_table','michaelbelgium-discussion-views'),(146,'2020_10_06_alter_users_add_approval_count','clarkwinkelmann-first-post-approval'),(147,'2021_07_06_000000_set_default_settings','the-turk-flamoji'),(148,'2021_07_08_000000_create_custom_emojis_table','the-turk-flamoji'),(149,'2019_11_04_000001_add_columns_to_discussions_table','fof-best-answer'),(150,'2019_11_04_000002_add_foreign_keys_to_best_anwer_columns','fof-best-answer'),(151,'2019_11_04_000003_migrate_extension_settings','fof-best-answer'),(152,'2020_02_04_205300_add_best_answer_set_timestamp','fof-best-answer'),(153,'2021_08_09_add_qna_column_to_tags_table','fof-best-answer'),(154,'2021_08_10_add_reminders_column_to_tags_table','fof-best-answer'),(155,'2021_08_15_migrate_reminder_settings','fof-best-answer'),(156,'2021_09_10_add_default_filter_option_setting','fof-best-answer'),(157,'2022_05_19_000000_add_best_answer_count_to_users_table','fof-best-answer'),(158,'2023_11_23_000000_create_enabled_tags_setting_key','fof-best-answer'),(159,'0000_00_00_000000_migrate_extension_settings','fof-cookie-consent'),(160,'2018_11_18_01_create_doorkey_table','fof-doorman'),(161,'2018_11_19_01_add_invite_code_to_users','fof-doorman'),(162,'2020_11_14_000000_migrate_settings_to_fof','fof-doorman'),(163,'2019_08_02_171300_create_drafts_table','fof-drafts'),(164,'2019_08_02_172100_add_drafts_foreign_keys','fof-drafts'),(165,'2019_08_03_171600_add_default_permissions','fof-drafts'),(166,'2019_08_04_151000_change_content_to_medium_text','fof-drafts'),(167,'2020_05_24_000000_add_scheduled_at_column','fof-drafts'),(168,'2020_05_24_000001_add_schedule_post_permission','fof-drafts'),(169,'2020_05_24_000002_add_error_and_ip_columns','fof-drafts'),(170,'2020_05_24_000003_add_scheduled_post_setting','fof-drafts'),(171,'2020_08_16_000000_add_extra_to_drafts','fof-drafts'),(172,'2022_12_05_000000_modify_drafts_table_allow_null_title','fof-drafts'),(173,'2017_03_08_102708_add_emailed_to_posts','fof-filter'),(174,'2019_07_05_022521_add_auto_mod_to_posts','fof-filter'),(175,'2021_09_12_modify_badwords_delimiter','fof-filter'),(176,'2019_06_11_000000_add_subscription_to_users_tags_table','fof-follow-tags'),(177,'2019_06_28_000000_add_hide_subscription_option','fof-follow-tags'),(178,'2021_01_22_000000_add_indicies','fof-follow-tags'),(179,'2022_05_20_000000_add_timestamps_to_tag_user_table','fof-follow-tags'),(180,'2018_05_01_000000_add_frontpage_table','fof-frontpage'),(181,'2018_05_02_000000_add_default_permissions','fof-frontpage'),(182,'2016_02_13_000000_create_links_table','fof-links'),(183,'2016_04_19_065618_change_links_columns','fof-links'),(184,'2020_03_16_000000_add_child_links','fof-links'),(185,'2020_09_10_000000_add_icon_to_links_table','fof-links'),(186,'2021_01_17_000000_add_registered_users_only_to_links_table','fof-links'),(187,'2021_01_17_000001_add_visibility_to_links_table','fof-links'),(188,'2021_01_17_000001_drop_registered_users_only_column_and_migrate_options','fof-links'),(189,'2020_02_25_000001_create_moderator_notes_table','fof-moderator-notes'),(190,'2020_02_25_000002_add_default_permissions','fof-moderator-notes'),(191,'2020_02_29_000001_modify_users_notes_foreign_keys','fof-moderator-notes'),(192,'2020_04_31_000000_format_note_content_for_renderer','fof-moderator-notes'),(193,'2020_06_27_000000_set_default_theme','fof-nightmode'),(194,'2020_07_12_000000_migrate_old_user_settings','fof-nightmode'),(195,'2019_07_01_000000_add_polls_table','fof-polls'),(196,'2019_07_01_000001_add_poll_options_table','fof-polls'),(197,'2019_07_01_000002_add_poll_votes_table','fof-polls'),(198,'2021_04_06_000000_alter_options_add_vote_count','fof-polls'),(199,'2021_04_06_000001_alter_polls_add_vote_count','fof-polls'),(200,'2022_10_25_000000_alter_options_add_image','fof-polls'),(201,'2023_06_04_000000_add_allow_multiple_votes_option','fof-polls'),(202,'2023_06_05_000000_add_max_votes_option','fof-polls'),(203,'2023_07_05_000001_rename_permissions','fof-polls'),(204,'2023_07_08_000000_rename_polls_discussion_id_column','fof-polls'),(205,'2023_07_08_000001_update_polls_discussion_relation_to_first_post','fof-polls'),(206,'2023_07_14_000000_create_polls_settings_column','fof-polls'),(207,'2023_07_14_000001_polls_use_settings_column','fof-polls'),(208,'2019_06_17_000000_add_settings_social_list','fof-share-social'),(209,'2020_06_07_000000_set_default','fof-sitemap'),(210,'2019_02_05_000000_migrate_from_fa_4','fof-socialprofile'),(211,'2019_02_05_000001_create_socialbuttons_column','fof-socialprofile'),(212,'2021_08_12_000000_add_default_permissions','fof-socialprofile'),(213,'2019_10_22_01_rename_permissions','fof-terms'),(214,'2019_10_22_02_rename_settings','fof-terms'),(215,'2019_10_22_03_rename_flagrow_tables','fof-terms'),(216,'2019_10_22_04_remove_flagrow_migrations','fof-terms'),(217,'2019_10_22_05_create_terms_policies','fof-terms'),(218,'2019_10_22_06_create_terms_policy_user','fof-terms'),(219,'2020_07_01_000000_create_bio_column','fof-user-bio'),(220,'2021_01_17_000000_set_default_bio_length','fof-user-bio'),(221,'2019_06_10_000000_rename_permissions','fof-user-directory'),(222,'2020_11_23_000000_add_nickname_column','flarum-nicknames'),(223,'2020_12_02_000001_set_default_permissions','flarum-nicknames'),(224,'2021_11_16_000000_nickname_column_nullable','flarum-nicknames'),(225,'2020_05_29_000000_add_push_subscriptions_table','askvortsov-pwa'),(226,'2020_08_02_000000_change_endpoint_collation','askvortsov-pwa'),(227,'2020_08_02_000001_remove_unique_constraint','askvortsov-pwa'),(228,'2023_04_13_000000_add_last_used_column','askvortsov-pwa'),(229,'2021_07_04_000000_add_stickies_to_discussions','the-turk-stickiest'),(230,'2021_07_04_000001_add_discussions_stickiest_last_posted_at_indices','the-turk-stickiest'),(231,'2021_07_04_000002_add_discussions_created_at_indices','the-turk-stickiest'),(232,'2021_07_23_000000_add_default_permissions','the-turk-stickiest'),(233,'2022_07_21_000000_drop_discussions_is_tagSticky_indices','the-turk-stickiest'),(234,'2022_07_21_000001_change_discussions_drop_is_tagSticky','the-turk-stickiest'),(235,'2022_07_21_000002_add_is_tag_sticky_to_discussions_table','the-turk-stickiest'),(236,'2022_07_21_000003_add_discussions_is_tag_sticky_indices','the-turk-stickiest'),(237,'2022_07_21_000004_create_discussion_sticky_tag_table','the-turk-stickiest'),(238,'2021_03_13_000000_add_tags_text_color_column','nearata-tags-color-generator'),(239,'2022_08_04_000000_remove_is_custom_color','nearata-tags-color-generator'),(240,'2022_08_13_000000_remove_text_color','nearata-tags-color-generator'),(241,'2020_05_16_01_rename_itnt_settings','gitzaai-mobile-ui-tab-2'),(242,'2021_01_10_01_drop_itnt_settings','gitzaai-mobile-ui-tab-2'),(243,'2021_01_10_02_set_default_settings','gitzaai-mobile-ui-tab-2'),(244,'2019_10_07_000000_add_cover_column','sycho-profile-cover'),(245,'2020_07_25_000000_add_default_cover_permissions','sycho-profile-cover'),(246,'2020_10_17_16_34_create_blog_meta_table','v17development-blog'),(247,'2020_10_17_16_50_add_default_permissions','v17development-blog'),(248,'2021_06_29_000000_tags_is_article_series_column','askvortsov-article-series'),(249,'2021_06_29_000001_discussions_article_series_columns','askvortsov-article-series'),(256,'2020_02_06_01_rename_flagrow_permissions','fof-upload'),(257,'2020_02_06_02_rename_flagrow_settings','fof-upload'),(258,'2020_02_06_03_rename_flagrow_tables','fof-upload'),(259,'2020_02_06_04_remove_flagrow_migrations','fof-upload'),(260,'2020_02_06_05_create_files_table','fof-upload'),(261,'2020_02_06_06_create_downloads_table','fof-upload'),(262,'2020_02_06_07_alter_downloads_add_post_constraint','fof-upload'),(263,'2021_02_11_01_add_uploads_view_and_delete_permissions','fof-upload'),(264,'2021_03_13_000000_alter_upload_files_add_hidden_from_media_manager','fof-upload'),(265,'2021_03_13_set_created_at_to_default_as_current_timestamp','fof-upload'),(266,'2021_09_30_000000_add_index_actor_id_and_hide_media','fof-upload'),(267,'2020_12_24_000000_default_settings','ianm-synopsis'),(268,'2021_12_08_000000_add_tags_synopsis_cols','ianm-synopsis'),(269,'2019_09_12_000000_add_templates_to_settings','fof-pretty-mail');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `from_user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(10) unsigned DEFAULT NULL,
  `data` blob,
  `created_at` datetime NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_from_user_id_foreign` (`from_user_id`),
  KEY `notifications_user_id_index` (`user_id`),
  CONSTRAINT `notifications_from_user_id_foreign` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,1,NULL,'postFlagged',14,NULL,'2023-12-28 04:59:49',1,'2023-12-28 05:46:13'),(2,1,2,'postUnapproved',14,NULL,'2023-12-28 04:59:50',1,'2023-12-28 05:46:13'),(3,1,2,'discussionCreated',10,NULL,'2023-12-28 05:02:08',0,'2023-12-28 05:14:28'),(4,1,NULL,'postFlagged',15,NULL,'2023-12-28 05:40:46',1,'2023-12-28 05:46:13'),(5,1,2,'postUnapproved',15,NULL,'2023-12-28 05:40:48',1,'2023-12-28 05:46:13'),(6,1,2,'discussionCreated',11,NULL,'2023-12-28 05:42:10',0,'2023-12-28 05:46:13'),(7,1,2,'discussionCreated',12,NULL,'2023-12-28 05:53:09',0,'2023-12-28 06:36:47');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` datetime NOT NULL,
  `edit_time` datetime DEFAULT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci COMMENT ' ',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `is_html` tinyint(1) NOT NULL DEFAULT '0',
  `is_restricted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_tokens`
--

DROP TABLE IF EXISTS `password_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_tokens` (
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`token`),
  KEY `password_tokens_user_id_foreign` (`user_id`),
  CONSTRAINT `password_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_tokens`
--

LOCK TABLES `password_tokens` WRITE;
/*!40000 ALTER TABLE `password_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_options`
--

DROP TABLE IF EXISTS `poll_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_options` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `answer` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `poll_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `vote_count` int(10) unsigned NOT NULL DEFAULT '0',
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_options_poll_id_foreign` (`poll_id`),
  CONSTRAINT `poll_options_poll_id_foreign` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_options`
--

LOCK TABLES `poll_options` WRITE;
/*!40000 ALTER TABLE `poll_options` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `poll_votes`
--

DROP TABLE IF EXISTS `poll_votes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `poll_votes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `poll_id` int(10) unsigned NOT NULL,
  `option_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `poll_votes_poll_id_foreign` (`poll_id`),
  KEY `poll_votes_option_id_foreign` (`option_id`),
  KEY `poll_votes_user_id_foreign` (`user_id`),
  CONSTRAINT `poll_votes_option_id_foreign` FOREIGN KEY (`option_id`) REFERENCES `poll_options` (`id`) ON DELETE CASCADE,
  CONSTRAINT `poll_votes_poll_id_foreign` FOREIGN KEY (`poll_id`) REFERENCES `polls` (`id`) ON DELETE CASCADE,
  CONSTRAINT `poll_votes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `poll_votes`
--

LOCK TABLES `poll_votes` WRITE;
/*!40000 ALTER TABLE `poll_votes` DISABLE KEYS */;
/*!40000 ALTER TABLE `poll_votes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `polls`
--

DROP TABLE IF EXISTS `polls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `polls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `public_poll` tinyint(1) NOT NULL,
  `end_date` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `vote_count` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_multiple_votes` tinyint(1) NOT NULL DEFAULT '0',
  `max_votes` int(10) unsigned NOT NULL DEFAULT '0',
  `settings` json NOT NULL,
  PRIMARY KEY (`id`),
  KEY `polls_user_id_foreign` (`user_id`),
  KEY `polls_post_id_foreign` (`post_id`),
  CONSTRAINT `polls_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `polls_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `polls`
--

LOCK TABLES `polls` WRITE;
/*!40000 ALTER TABLE `polls` DISABLE KEYS */;
/*!40000 ALTER TABLE `polls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_likes`
--

DROP TABLE IF EXISTS `post_likes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_likes` (
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`user_id`),
  KEY `post_likes_user_id_foreign` (`user_id`),
  CONSTRAINT `post_likes_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_likes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_likes`
--

LOCK TABLES `post_likes` WRITE;
/*!40000 ALTER TABLE `post_likes` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_likes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_mentions_group`
--

DROP TABLE IF EXISTS `post_mentions_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_mentions_group` (
  `post_id` int(10) unsigned NOT NULL,
  `mentions_group_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`mentions_group_id`),
  KEY `post_mentions_group_mentions_group_id_foreign` (`mentions_group_id`),
  CONSTRAINT `post_mentions_group_mentions_group_id_foreign` FOREIGN KEY (`mentions_group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_mentions_group_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_mentions_group`
--

LOCK TABLES `post_mentions_group` WRITE;
/*!40000 ALTER TABLE `post_mentions_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_mentions_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_mentions_post`
--

DROP TABLE IF EXISTS `post_mentions_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_mentions_post` (
  `post_id` int(10) unsigned NOT NULL,
  `mentions_post_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`mentions_post_id`),
  KEY `post_mentions_post_mentions_post_id_foreign` (`mentions_post_id`),
  CONSTRAINT `post_mentions_post_mentions_post_id_foreign` FOREIGN KEY (`mentions_post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_mentions_post_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_mentions_post`
--

LOCK TABLES `post_mentions_post` WRITE;
/*!40000 ALTER TABLE `post_mentions_post` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_mentions_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_mentions_tag`
--

DROP TABLE IF EXISTS `post_mentions_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_mentions_tag` (
  `post_id` int(10) unsigned NOT NULL,
  `mentions_tag_id` int(10) unsigned NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`mentions_tag_id`),
  KEY `post_mentions_tag_mentions_tag_id_foreign` (`mentions_tag_id`),
  CONSTRAINT `post_mentions_tag_mentions_tag_id_foreign` FOREIGN KEY (`mentions_tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_mentions_tag_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_mentions_tag`
--

LOCK TABLES `post_mentions_tag` WRITE;
/*!40000 ALTER TABLE `post_mentions_tag` DISABLE KEYS */;
INSERT INTO `post_mentions_tag` VALUES (9,1,'2023-12-27 22:36:11'),(9,2,'2023-12-27 22:36:11'),(10,1,'2023-12-27 22:42:00'),(10,2,'2023-12-27 22:42:00');
/*!40000 ALTER TABLE `post_mentions_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_mentions_user`
--

DROP TABLE IF EXISTS `post_mentions_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_mentions_user` (
  `post_id` int(10) unsigned NOT NULL,
  `mentions_user_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`mentions_user_id`),
  KEY `post_mentions_user_mentions_user_id_foreign` (`mentions_user_id`),
  CONSTRAINT `post_mentions_user_mentions_user_id_foreign` FOREIGN KEY (`mentions_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_mentions_user_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_mentions_user`
--

LOCK TABLES `post_mentions_user` WRITE;
/*!40000 ALTER TABLE `post_mentions_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_mentions_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `post_user`
--

DROP TABLE IF EXISTS `post_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `post_user` (
  `post_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`post_id`,`user_id`),
  KEY `post_user_user_id_foreign` (`user_id`),
  CONSTRAINT `post_user_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `post_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `post_user`
--

LOCK TABLES `post_user` WRITE;
/*!40000 ALTER TABLE `post_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `post_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `posts`
--

DROP TABLE IF EXISTS `posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `posts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `discussion_id` int(10) unsigned NOT NULL,
  `number` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci COMMENT ' ',
  `edited_at` datetime DEFAULT NULL,
  `edited_user_id` int(10) unsigned DEFAULT NULL,
  `hidden_at` datetime DEFAULT NULL,
  `hidden_user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT '0',
  `is_approved` tinyint(1) NOT NULL DEFAULT '1',
  `emailed` tinyint(1) NOT NULL DEFAULT '0',
  `auto_mod` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `posts_discussion_id_number_unique` (`discussion_id`,`number`),
  KEY `posts_edited_user_id_foreign` (`edited_user_id`),
  KEY `posts_hidden_user_id_foreign` (`hidden_user_id`),
  KEY `posts_discussion_id_number_index` (`discussion_id`,`number`),
  KEY `posts_discussion_id_created_at_index` (`discussion_id`,`created_at`),
  KEY `posts_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `posts_type_index` (`type`),
  KEY `posts_type_created_at_index` (`type`,`created_at`),
  FULLTEXT KEY `content` (`content`) /*!50100 WITH PARSER `ngram` */ ,
  CONSTRAINT `posts_discussion_id_foreign` FOREIGN KEY (`discussion_id`) REFERENCES `discussions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `posts_edited_user_id_foreign` FOREIGN KEY (`edited_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_hidden_user_id_foreign` FOREIGN KEY (`hidden_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `posts`
--

LOCK TABLES `posts` WRITE;
/*!40000 ALTER TABLE `posts` DISABLE KEYS */;
INSERT INTO `posts` VALUES (1,1,1,'2023-12-27 03:09:26',1,'comment','<r><H1><s># </s>中文文案排版指北</H1>\n\n<QUOTE><i>&gt; </i> <p>统一中文文案、排版的相关用法，降低团队成员之间的沟通成本，增强网站气质。</p></QUOTE>\n\n<HR>------</HR>\n\n\n\n<H2><s>## </s>空格</H2>\n\n<QUOTE><i>&gt; </i><p>「有研究显示，打字的时候不喜欢在中文和英文之间加空格的人，感情路都走得很辛苦，有七成的比例会在 34 岁的时候跟自己不爱的人结婚，而其余三成的人最后只能把遗产留给自己的猫。毕竟爱情跟书写都需要适时地留白。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>与大家共勉之。」——<URL url=\"https://github.com/vinta/pangu.js\"><s>[</s>vinta/paranoid-auto-spacing<e>](https://github.com/vinta/pangu.js)</e></URL></p></QUOTE>\n\n<H3><s>### </s>中英文之间需要增加空格</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>在 LeanCloud 上，数据存储是围绕 <C><s>`</s>AVObject<e>`</e></C> 进行的。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>在LeanCloud上，数据存储是围绕<C><s>`</s>AVObject<e>`</e></C>进行的。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>在 LeanCloud上，数据存储是围绕<C><s>`</s>AVObject<e>`</e></C> 进行的。</p></QUOTE>\n\n<p>完整的正确用法：</p>\n\n<QUOTE><i>&gt; </i><p>在 LeanCloud 上，数据存储是围绕 <C><s>`</s>AVObject<e>`</e></C> 进行的。每个 <C><s>`</s>AVObject<e>`</e></C> 都包含了与 JSON 兼容的 key-value 对应的数据。数据是 schema-free 的，你不需要在每个 <C><s>`</s>AVObject<e>`</e></C> 上提前指定存在哪些键，只要直接设定对应的 key-value 即可。</p></QUOTE>\n\n<p>例外：「豆瓣FM」等产品名词，按照官方所定义的格式书写。</p>\n\n<H3><s>### </s>中文与数字之间需要增加空格</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>今天出去买菜花了 5000 元。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>今天出去买菜花了 5000元。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>今天出去买菜花了5000元。</p></QUOTE>\n\n<H3><s>### </s>数字与单位之间需要增加空格</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>我家的光纤入屋宽带有 10 Gbps，SSD 一共有 20 TB</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>我家的光纤入屋宽带有 10Gbps，SSD 一共有 20TB</p></QUOTE>\n\n<p>例外：度数／百分比与数字之间不需要增加空格：</p>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>角度为 90° 的角，就是直角。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>新 MacBook Pro 有 15% 的 CPU 性能提升。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>角度为 90 ° 的角，就是直角。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>新 MacBook Pro 有 15 % 的 CPU 性能提升。</p></QUOTE>\n\n<H3><s>### </s>全角标点与其他字符之间不加空格</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>刚刚买了一部 iPhone，好开心！</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>刚刚买了一部 iPhone ，好开心！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>刚刚买了一部 iPhone， 好开心！</p></QUOTE>\n\n<H3><s>### </s>用 <C><s>`</s>text-spacing<e>`</e></C> 来挽救？</H3>\n\n<p>CSS Text Module Level 4 的 <URL url=\"https://www.w3.org/TR/css-text-4/#text-spacing-property\"><s>[</s><C><s>`</s>text-spacing<e>`</e></C><e>](https://www.w3.org/TR/css-text-4/#text-spacing-property)</e></URL> 和 Microsoft 的 <URL url=\"https://msdn.microsoft.com/library/ms531164%28v=vs.85%29.aspx\"><s>[</s><C><s>`</s>-ms-text-autospace<e>`</e></C><e>](https://msdn.microsoft.com/library/ms531164(v=vs.85).aspx)</e></URL> 可以实现自动为中英文之间增加空白。不过目前并未普及，另外在其他应用场景，例如 macOS、iOS、Windows 等用户界面目前并不存在这个特性，所以请继续保持随手加空格的习惯。</p>\n\n<H2><s>## </s>标点符号</H2>\n\n<H3><s>### </s>不重复使用标点符号</H3>\n\n<p>即使中国大陆的标点符号用法允许重复使用标点符号，但是这么做会破坏句子的美观性。</p>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>德国队竟然战胜了巴西队！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>她竟然对你说「喵」？！</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>德国队竟然战胜了巴西队！！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>德国队竟然战胜了巴西队！！！！！！！！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>她竟然对你说「喵」？？！！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>她竟然对你说「喵」？！？！？？！！</p></QUOTE>\n\n<H2><s>## </s>全角和半角</H2>\n\n<p>不明白什么是全角（全形）与半角（半形）符号？请查看维基百科条目『<URL url=\"https://zh.wikipedia.org/wiki/%E5%85%A8%E5%BD%A2%E5%92%8C%E5%8D%8A%E5%BD%A2\"><s>[</s>全角和半角<e>](https://zh.wikipedia.org/wiki/全形和半形)</e></URL>』。</p>\n\n<H3><s>### </s>使用全角中文标点</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>嗨！你知道嘛？今天前台的小妹跟我说「喵」了哎！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>核磁共振成像（NMRI）是什么原理都不知道？JFGI！</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>嗨! 你知道嘛? 今天前台的小妹跟我说 “喵” 了哎！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>嗨!你知道嘛?今天前台的小妹跟我说\"喵\"了哎！</p>\n<i>&gt;</i>\n<i>&gt; </i><p>核磁共振成像 (NMRI) 是什么原理都不知道? JFGI!</p>\n<i>&gt;</i>\n<i>&gt; </i><p>核磁共振成像(NMRI)是什么原理都不知道?JFGI!</p></QUOTE>\n\n<H3><s>### </s>数字使用半角字符</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>这个蛋糕只卖 1000 元。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>这个蛋糕只卖 １０００ 元。</p></QUOTE>\n\n<p>例外：在设计稿、宣传海报中如出现极少量数字的情形时，为方便文字对齐，是可以使用全角数字的。</p>\n\n<H3><s>### </s>遇到完整的英文整句、特殊名词，其内容使用半角标点</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>乔布斯那句话是怎么说的？「Stay hungry, stay foolish.」</p>\n<i>&gt;</i>\n<i>&gt; </i><p>推荐你阅读《Hackers &amp; Painters: Big Ideas from the Computer Age》，非常的有趣。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>乔布斯那句话是怎么说的？「Stay hungry，stay foolish。」</p>\n<i>&gt;</i>\n<i>&gt; </i><p>推荐你阅读《Hackers＆Painters：Big Ideas from the Computer Age》，非常的有趣。</p></QUOTE>\n\n<H2><s>## </s>名词</H2>\n\n<H3><s>### </s>专有名词使用正确的大小写</H3>\n\n<p>大小写相关用法原属于英文书写范畴，不属于本 wiki 讨论内容，在这里只对部分易错用法进行简述。</p>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>使用 GitHub 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 GitHub、Foursquare、Microsoft Corporation、Google、Facebook, Inc.。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>使用 github 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>使用 GITHUB 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>使用 Github 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>使用 gitHub 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>使用 gｲんĤЦ8 登录</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 github、foursquare、microsoft corporation、google、facebook, inc.。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 GITHUB、FOURSQUARE、MICROSOFT CORPORATION、GOOGLE、FACEBOOK, INC.。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 Github、FourSquare、MicroSoft Corporation、Google、FaceBook, Inc.。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 gitHub、fourSquare、microSoft Corporation、google、faceBook, Inc.。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>我们的客户有 gｲんĤЦ8、ｷouЯƧquﾑгє、๓เςг๏ร๏Ŧt ς๏гק๏гคtเ๏ภn、900913、ƒ4ᄃëв๏๏к, IПᄃ.。</p></QUOTE>\n\n<p>注意：当网页中需要配合整体视觉风格而出现全部大写／小写的情形，HTML 中请使用标淮的大小写规范进行书写；并通过 <C><s>`</s>text-transform: uppercase;<e>`</e></C>／<C><s>`</s>text-transform: lowercase;<e>`</e></C> 对表现形式进行定义。</p>\n\n<H3><s>### </s>不要使用不地道的缩写</H3>\n\n<p>正确：</p>\n\n<QUOTE><i>&gt; </i><p>我们需要一位熟悉 TypeScript、HTML5，至少理解一种框架（如 React、Next.js）的前端开发者。</p></QUOTE>\n\n<p>错误：</p>\n\n<QUOTE><i>&gt; </i><p>我们需要一位熟悉 Ts、h5，至少理解一种框架（如 RJS、nextjs）的 FED。</p></QUOTE>\n\n<H2><s>## </s>争议</H2>\n\n<p>以下用法略带有个人色彩，即：无论是否遵循下述规则，从语法的角度来讲都是<STRONG><s>**</s>正确<e>**</e></STRONG>的。</p>\n\n<H3><s>### </s>链接之间增加空格</H3>\n\n<p>用法：</p>\n\n<QUOTE><i>&gt; </i><p>请 <URL url=\"https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#\"><s>[</s>提交一个 issue<e>](https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#)</e></URL> 并分配给相关同事。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>访问我们网站的最新动态，请 <URL url=\"https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#\"><s>[</s>点击这里<e>](https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#)</e></URL> 进行订阅！</p></QUOTE>\n\n<p>对比用法：</p>\n\n<QUOTE><i>&gt; </i><p>请<URL url=\"https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#\"><s>[</s>提交一个 issue<e>](https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#)</e></URL>并分配给相关同事。</p>\n<i>&gt;</i>\n<i>&gt; </i><p>访问我们网站的最新动态，请<URL url=\"https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#\"><s>[</s>点击这里<e>](https://github.com/gitzaai/chinese-copywriting-guidelines/blob/master/README.zh-Hans.md#)</e></URL>进行订阅！</p></QUOTE>\n\n<H3><s>### </s>简体中文使用直角引号</H3>\n\n<p>用法：</p>\n\n<QUOTE><i>&gt; </i><p>「老师，『有条不紊』的『紊』是什么意思？」</p></QUOTE>\n\n<p>对比用法：</p>\n\n<QUOTE><i>&gt; </i><p>“老师，‘有条不紊’的‘紊’是什么意思？”</p></QUOTE></r>','2023-12-27 14:37:11',1,NULL,NULL,'127.0.0.1',0,1,0,0),(2,2,1,'2023-12-27 05:42:39',1,'comment','<r><H1><s># </s>Foresee Studio论坛隐私政策</H1>\n\n<H2><s>## </s>引言</H2>\n\n<p>欢迎来到<URL url=\"https://www.foreseestudioblog.top/\"><s>[</s>Foresee Studio论坛<e>](https://www.foreseestudioblog.top/)</e></URL>。我们尊重并致力于保护您的隐私权。本隐私政策旨在透明地说明我们如何收集、使用、保护以及分享您的个人信息。</p>\n\n<H2><s>## </s>收集的信息</H2>\n\n<LIST type=\"decimal\"><LI><s>1. </s><STRONG><s>**</s>注册信息<e>**</e></STRONG>：当您在我们的论坛上注册时，我们可能会收集您的用户名、电子邮件地址、密码以及其他联系信息。</LI>\n<LI><s>2. </s><STRONG><s>**</s>使用信息<e>**</e></STRONG>：我们可能会收集有关您如何访问和使用论坛的信息，包括浏览器类型、访问时间、浏览的页面以及点击的链接。</LI>\n<LI><s>3. </s><STRONG><s>**</s>交流信息<e>**</e></STRONG>：当您与我们联系时，我们可能会保留您的通信记录，包括电子邮件或站内消息。</LI></LIST>\n\n<H2><s>## </s>使用信息的方式</H2>\n\n<LIST type=\"decimal\"><LI><s>1. </s><STRONG><s>**</s>提供服务<e>**</e></STRONG>：使用您的信息来提供论坛服务，包括账户管理、客户支持和论坛功能的维护。</LI>\n<LI><s>2. </s><STRONG><s>**</s>改进服务<e>**</e></STRONG>：使用您的信息来改进我们的服务，包括添加新功能或改善现有服务。</LI>\n<LI><s>3. </s><STRONG><s>**</s>安全和法律目的<e>**</e></STRONG>：使用您的信息来保护论坛的安全，防止欺诈行为，并确保符合适用的法律法规。</LI></LIST>\n\n<H2><s>## </s>数据共享</H2>\n\n<LIST type=\"decimal\"><LI><s>1. </s><STRONG><s>**</s>服务提供商<e>**</e></STRONG>：我们可能会与第三方服务提供商共享您的部分信息，以便他们帮助我们提供和改进服务（例如，托管服务或分析服务）。</LI>\n<LI><s>2. </s><STRONG><s>**</s>法律要求<e>**</e></STRONG>：在法律要求或为响应法律程序（如传票或搜查令）时，我们可能需要披露您的信息。</LI>\n<LI><s>3. </s><STRONG><s>**</s>合并或收购<e>**</e></STRONG>：在合并、出售资产或收购的情况下，您的信息可能会被转移给第三方。</LI></LIST>\n\n<H2><s>## </s>信息的安全</H2>\n\n<p>我们采取各种措施来保护您的个人信息，包括使用加密技术、设置访问控制以及进行定期的安全审核。</p>\n\n<H2><s>## </s>用户权利</H2>\n\n<LIST type=\"decimal\"><LI><s>1. </s><STRONG><s>**</s>访问和更新<e>**</e></STRONG>：您可以通过您的账户设置来访问并更新您的个人信息。</LI>\n<LI><s>2. </s><STRONG><s>**</s>删除账户<e>**</e></STRONG>：您可以请求删除您的账户，但请注意，某些信息可能因法律原因或合理商业目的而保留。</LI>\n<LI><s>3. </s><STRONG><s>**</s>选择退出<e>**</e></STRONG>：您可以选择不接收我们的营销邮件。</LI></LIST>\n\n<H2><s>## </s>政策变更</H2>\n\n<p>我们可能会不时更新此隐私政策。我们建议您定期查看本政策以了解任何变更。变更生效前，我们将通过论坛公告或电子邮件通知您。</p>\n\n<H2><s>## </s>联系方式</H2>\n\n<p>如有关于本隐私政策的问题，请通过<EMAIL email=\"jlstudioemail@163.com\">jlstudioemail@163.com</EMAIL>与我们联系。</p></r>','2023-12-27 15:00:16',1,NULL,NULL,'127.0.0.1',0,1,0,0),(3,3,1,'2023-12-27 05:48:10',1,'comment','<r><H1><s>#  </s>中文文案排版指北</H1>\n\n<HR>----</HR>\n\n<H2><s>## </s>1 标题</H2>\n\n<p>两种形式：<br/>\n1）使用<C><s>`</s>=<e>`</e></C>和<C><s>`</s>-<e>`</e></C>标记一级和二级标题。</p>\n\n<QUOTE><i>&gt; </i><p>一级标题<br/>\n<i>&gt; </i><C><s>`</s>=========<e>`</e></C><br/>\n<i>&gt; </i>二级标题<br/>\n<i>&gt; </i><C><s>`</s>---------<e>`</e></C></p></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><H1><s># </s>一级标题</H1>\n<i>&gt;</i>\n<i>&gt; </i><H2><s>## </s>二级标题</H2></QUOTE>\n\n<p>2）使用<C><s>`</s>#<e>`</e></C>，可表示1-6级标题。</p>\n\n<QUOTE><i>&gt; </i><p><ESC><s>\\</s>#</ESC> 一级标题<br/>\n<i>&gt; </i><ESC><s>\\</s>#</ESC># 二级标题<br/>\n<i>&gt; </i><ESC><s>\\</s>#</ESC>## 三级标题<br/>\n<i>&gt; </i><ESC><s>\\</s>#</ESC>### 四级标题<br/>\n<i>&gt; </i><ESC><s>\\</s>#</ESC>#### 五级标题<br/>\n<i>&gt; </i><ESC><s>\\</s>#</ESC>##### 六级标题</p></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><H1><s># </s>一级标题</H1>\n<i>&gt;</i>\n<i>&gt; </i><H2><s>## </s>二级标题</H2>\n<i>&gt;</i>\n<i>&gt; </i><H3><s>### </s>三级标题</H3>\n<i>&gt;</i>\n<i>&gt; </i><H4><s>#### </s>四级标题</H4>\n<i>&gt;</i>\n<i>&gt; </i><H5><s>##### </s>五级标题</H5>\n<i>&gt;</i>\n<i>&gt; </i><H6><s>###### </s>六级标题</H6></QUOTE>\n\n<H2><s>## </s>2 段落</H2>\n\n<p>段落的前后要有空行，所谓的空行是指没有文字内容。若想在段内强制换行的方式是使用<STRONG><s>**</s>两个以上<e>**</e></STRONG>空格加上回车（引用中换行省略回车）。</p>\n\n<H2><s>## </s>3 区块引用</H2>\n\n<p>在段落的每行或者只在第一行使用符号<C><s>`</s>&gt;<e>`</e></C>,还可使用多个嵌套引用，如：</p>\n\n<QUOTE><i>&gt; </i><p><ESC><s>\\</s>&gt;</ESC> 区块引用<br/>\n<i>&gt; </i><ESC><s>\\</s>&gt;</ESC>&gt; 嵌套引用</p></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><p>区块引用</p>\n<i>&gt;</i>\n<QUOTE><i>&gt; &gt; </i><p>嵌套引用</p></QUOTE></QUOTE>\n\n<H2><s>## </s>4 代码区块</H2>\n\n<p>代码区块的建立是在每行加上4个空格或者一个制表符（如同写代码一样）。如<br/>\n普通段落：</p>\n\n<p>void main()<br/>\n{<br/>\nprintf(“Hello, Markdown.”);<br/>\n}</p>\n\n<p>代码区块：</p>\n\n<CODE lang=\"cpp\"><s>```cpp</s><i>\n</i>void main()\n{\n    printf(\"Hello, Markdown.\");\n}<i>\n</i><e>```</e></CODE>\n\n<p><STRONG><s>**</s>注意<e>**</e></STRONG>:需要和普通段落之间存在空行。</p>\n\n<H2><s>## </s>5 强调</H2>\n\n<p>在强调内容两侧分别加上<C><s>`</s>*<e>`</e></C>或者<C><s>`</s>_<e>`</e></C>，如：</p>\n\n<QUOTE><i>&gt; </i><CODE lang=\"markdown\"><s>```markdown</s><i>\n&gt; </i>*斜体*，_斜体_\n<i>&gt; </i>**粗体**，__粗体__<i>\n&gt; </i><e>```</e></CODE></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><p><EM><s>*</s>斜体<e>*</e></EM>，<EM><s>*</s>斜体<e>*</e></EM><br/>\n<i>&gt; </i><STRONG><s>**</s>粗体<e>**</e></STRONG>，<STRONG><s>**</s>粗体<e>**</e></STRONG></p></QUOTE>\n\n<H2><s>## </s>6 列表</H2>\n\n<p>使用<C><s>`</s>·<e>`</e></C>、<C><s>`</s>+<e>`</e></C>、或<C><s>`</s>-<e>`</e></C>标记无序列表，如：</p>\n\n<QUOTE><i>&gt; </i><p>-（+<EM><s>*</s>） 第一项 -（+<e>*</e></EM>） 第二项 - （+*）第三项</p></QUOTE>\n\n<p><STRONG><s>**</s>注意<e>**</e></STRONG>：标记后面最少有一个<EM><s>*</s>空格<e>*</e></EM>或<EM><s>*</s>制表符<e>*</e></EM>。若不在引用区块中，必须和前方段落之间存在空行。</p>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><LIST><LI><s>- </s>第一项</LI>\n<i>&gt; </i><LI><s>- </s>第二项</LI>\n<i>&gt; </i><LI><s>- </s>第三项</LI></LIST></QUOTE>\n\n<p>有序列表的标记方式是将上述的符号换成数字,并辅以<C><s>`</s>.<e>`</e></C>，如：</p>\n\n<QUOTE><i>&gt; </i><p>1 . 第一项<br/>\n<i>&gt; </i>2 . 第二项<br/>\n<i>&gt; </i>3 . 第三项</p></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><LIST type=\"decimal\"><LI><s>1. </s>第一项</LI>\n<i>&gt; </i><LI><s>2. </s>第二项</LI>\n<i>&gt; </i><LI><s>3. </s>第三项</LI></LIST></QUOTE>\n\n<H2><s>## </s>7 分割线</H2>\n\n<p>分割线最常使用就是三个或以上<C><s>`</s>*<e>`</e></C>，还可以使用<C><s>`</s>-<e>`</e></C>和<C><s>`</s>_<e>`</e></C>。</p>\n\n<H2><s>## </s>8 链接</H2>\n\n<p>链接可以由两种形式生成：<STRONG><s>**</s>行内式<e>**</e></STRONG>和<STRONG><s>**</s>参考式<e>**</e></STRONG>。<br/>\n<STRONG><s>**</s>行内式<e>**</e></STRONG>：</p>\n\n<p>语法说明：</p>\n\n<p>[]里写链接文字，()里写链接地址, ()中的”“中可以为链接指定title属性，title属性可加可不加。title属性的效果是鼠标悬停在链接上会出现指定的 title文字。链接地址与链接标题前有一个空格。</p>\n\n<CODE lang=\"less\"><s>```less</s><i>\n</i>[行内式链接](https://www.baidu.comwww.baidu.com)\n[行内式链接带title属性](https://www.baidu.com \"baidu\")<i>\n</i><e>```</e></CODE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><p><URL url=\"https://www.baidu.com/\"><s>[</s>行内式链接<e>](https://www.baidu.com/)</e></URL><br/>\n<i>&gt; </i><URL url=\"https://www.baidu.com/\"><s>[</s>行内式链接带title属性<e>](https://www.baidu.com/)</e></URL></p></QUOTE>\n\n<p><STRONG><s>**</s>参考式<e>**</e></STRONG>：</p>\n\n<p>参考式超链接一般用在学术论文上面，或者另一种情况，如果某一个链接在文章中多处使用，那么使用引用 的方式创建链接将非常好，它可以让你对链接进行统一的管理。</p>\n\n<p>语法说明： 参考式链接分为两部分，文中的写法 [链接文字] [链接标记]，在文本的任意位置添加[链接标记]:链接地址 “链接标题”，链接地址与链接标题前有一个空格。</p>\n\n<p>如果链接文字本身可以做为链接标记，你也可以写成 [链接文字] [] [链接文字]：链接地址的形式，见代码的最后一行。</p>\n\n<QUOTE><i>&gt; </i><CODE lang=\"ruby\"><s>```ruby</s><i>\n&gt; </i>我经常用[Google][1]搜索,在[Youtube][2]看视频，使用[Telegram][3]聊天\n<i>&gt; </i>[1]:https://google.com \"Google\"\n<i>&gt; </i>[2]:https://youtube.com \"Youtube\"\n<i>&gt; </i>[3]:https://telegram.org \"Telegram\"<i>\n&gt; </i><e>```</e></CODE></QUOTE>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><p>我经常用<URL url=\"https://google.com/\"><s>[</s>Google<e>](https://google.com/)</e></URL>搜索,在<URL url=\"https://youtube.com/\"><s>[</s>Youtube<e>](https://youtube.com/)</e></URL>看视频，使用<URL url=\"https://telegram.org/\"><s>[</s>Telegram<e>](https://telegram.org/)</e></URL>聊天</p></QUOTE>\n\n<H2><s>## </s>9 图片</H2>\n\n<p>添加图片的形式和链接相似，只需在链接的基础上前方加一个<C><s>`</s>！<e>`</e></C>。</p>\n\n<CODE lang=\"less\"><s>```less</s><i>\n</i>[!](https://)<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>10 反斜杠<C><s>`</s>\\<e>`</e></C></H2>\n\n<p>相当于<STRONG><s>**</s>反转义<e>**</e></STRONG>作用。使符号成为普通符号。</p>\n\n<H2><s>## </s>11 符号’`\'</H2>\n\n<p>起到标记作用。如：</p>\n\n<p><C><s>`</s>ctrl+a<e>`</e></C> // ` 符号要跟内容用空格隔开</p>\n\n<p>效果：</p>\n\n<QUOTE><i>&gt; </i><CODE lang=\"css\"><s>```css</s><i>\n&gt; </i>ctrl+a<i>\n&gt; </i><e>```</e></CODE></QUOTE>\n\n<H2><s>## </s>12 分级目录</H2>\n\n<H3><s>### </s>语法：</H3>\n\n<CODE lang=\"bash\"><s>```bash</s><i>\n</i>* [目录1](#0)\n   * [标题1](#1)\n   * [标题2](#2)\n   * [标题3](#3)\n   * [标题4](#4)\n\n&lt;h3 id=\"1\"&gt;标题1&lt;/h3&gt;\n    这是ID1的内容。\n&lt;h3 id=\"2\"&gt;标题2&lt;/h3&gt;\n    这是ID2的内容。\n&lt;h3 id=\"3\"&gt;标题3&lt;/h3&gt;\n    这是ID3的内容。\n&lt;h3 id=\"4\"&gt;标题4&lt;/h3&gt;\n    这是ID4的内容。<i>\n</i><e>```</e></CODE>\n\n<H3><s>### </s>展示效果：</H3>\n\n<LIST><LI><s>- </s>目录1\n  <LIST><LI><s>- </s><URL url=\"https://forum.gitzaai.com/d/4-markdown%E8%AF%AD%E6%B3%95%E4%BD%BF%E7%94%A8%E6%8C%87%E5%8D%97/2#1\"><s>[</s>标题1<e>](https://forum.gitzaai.com/d/4-markdown语法使用指南/2#1)</e></URL></LI>\n  <LI><s>- </s><URL url=\"https://forum.gitzaai.com/d/4-markdown%E8%AF%AD%E6%B3%95%E4%BD%BF%E7%94%A8%E6%8C%87%E5%8D%97/2#2\"><s>[</s>标题2<e>](https://forum.gitzaai.com/d/4-markdown语法使用指南/2#2)</e></URL></LI>\n  <LI><s>- </s><URL url=\"https://forum.gitzaai.com/d/4-markdown%E8%AF%AD%E6%B3%95%E4%BD%BF%E7%94%A8%E6%8C%87%E5%8D%97/2#3\"><s>[</s>标题3<e>](https://forum.gitzaai.com/d/4-markdown语法使用指南/2#3)</e></URL></LI>\n  <LI><s>- </s><URL url=\"https://forum.gitzaai.com/d/4-markdown%E8%AF%AD%E6%B3%95%E4%BD%BF%E7%94%A8%E6%8C%87%E5%8D%97/2#4\"><s>[</s>标题4<e>](https://forum.gitzaai.com/d/4-markdown语法使用指南/2#4)</e></URL></LI></LIST></LI></LIST>\n\n<H2><s>## </s>13 表格</H2>\n\n<p>竖杠<C><s>`</s>|<e>`</e></C>下划线<C><s>`</s>-<e>`</e></C>写法:</p>\n\n<QUOTE><i>&gt; </i><p>使用竖杠<C><s>`</s>|<e>`</e></C>下划线<C><s>`</s>-<e>`</e></C>写法</p></QUOTE>\n\n<H3><s>### </s>语法：</H3>\n\n<CODE lang=\"lua\"><s>```lua</s><i>\n</i>  |队列1|队列2|队列3|队列4|\n  |---|----|----|---|\n  |行列A1|行列B1|行列C1|行列D1|\n  |行列A2|行列B1|行列C1|行列D1|\n  |行列A3|行列B1|行列C1|行列D1|<i>\n</i><e>```</e></CODE>\n\n\n<TABLE><THEAD><TR><i>| </i><TH align=\"left\">队列1</TH><i>  | </i><TH align=\"left\">队列2</TH><i>  | </i><TH align=\"left\">队列3</TH><i>  | </i><TH align=\"left\">队列4</TH><i>  |</i></TR></THEAD><i>\n| :----- | :----- | :----- | :----- |</i>\n<TBODY><TR><i>| </i><TD align=\"left\">行列A1</TD><i> | </i><TD align=\"left\">行列B1</TD><i> | </i><TD align=\"left\">行列C1</TD><i> | </i><TD align=\"left\">行列D1</TD><i> |</i></TR>\n<TR><i>| </i><TD align=\"left\">行列A2</TD><i> | </i><TD align=\"left\">行列B1</TD><i> | </i><TD align=\"left\">行列C1</TD><i> | </i><TD align=\"left\">行列D1</TD><i> |</i></TR>\n<TR><i>| </i><TD align=\"left\">行列A3</TD><i> | </i><TD align=\"left\">行列B1</TD><i> | </i><TD align=\"left\">行列C1</TD><i> | </i><TD align=\"left\">行列D1</TD><i> |</i></TR></TBODY></TABLE>\n\n\n<H2><s>## </s>14 待办事项:</H2>\n\n<QUOTE><i>&gt; </i><p>要创建代办事项，前缀列表项<C><s>`</s>[ ]<e>`</e></C>。要将任务标记为完成，请使用<C><s>`</s>[x]<e>`</e></C></p></QUOTE>\n\n<LIST><LI><s>- </s>没打勾</LI></LIST>\n\n<p>-</p> \n\n  <p>打勾</p>\n\n  <LIST><LI><s>-  </s>下一行</LI></LIST>\n\n<p>—</p>\n\n<LIST type=\"decimal\"><LI><s>1.  </s>列表<br/>\n    <IMG alt=\"img\" src=\"https://imgoss.gitzaai.com/2021-03-23/1616493257-887200-snipaste-2021-03-23-17-53-22.png\"><s>![</s>img<e>](https://imgoss.gitzaai.com/2021-03-23/1616493257-887200-snipaste-2021-03-23-17-53-22.png)</e></IMG><br/>\n    代码如下</LI></LIST>\n\n<CODE lang=\"yaml\"><s>```yaml</s><i>\n</i>- [x] 没打勾\n- [ ] 打勾\n  - [x] 下一行\n\n---\n\n1. [ ] 列表<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>15 删除线:</H2>\n\n<H3><s>### </s>语法：</H3>\n\n<CODE lang=\"undefined\"><s>```undefined</s><i>\n</i>~~删除线文字效果~~<i>\n</i><e>```</e></CODE>\n\n<H3><s>### </s>效果:</H3>\n\n<p><DEL><s>~~</s>删除线文字效果<e>~~</e></DEL></p>\n\n<p>##16 Flarum 特有的折叠文字内容</p>\n\n<CODE lang=\"markdown\"><s>```markdown</s><i>\n</i>&gt;!折叠文字内容<i>\n</i><e>```</e></CODE>\n\n<H3><s>### </s>这是效果演示</H3>\n\n<SPOILER><i>&gt;!</i><p>折叠文字内容</p></SPOILER></r>','2023-12-27 14:44:34',1,NULL,NULL,'127.0.0.1',0,1,0,0),(8,8,1,'2023-12-27 14:16:58',1,'comment','<r><H1><s># </s>网站更新日志</H1>\n\n<H2><s>## </s>2023年12月25日</H2>\n\n<LIST><LI><s>- </s>由于失误操作导致网站全部崩溃，进行修复。</LI></LIST>\n\n<H2><s>## </s>2023年12月26日</H2>\n\n<LIST><LI><s>- </s>安装完本体网站。</LI></LIST>\n\n<p>参考教程</p>\n\n<QUOTE><i>&gt; </i><LIST type=\"decimal\"><LI><s>1. </s><URL url=\"https://forum.gitzaai.com/d/81-2022%E5%B9%B4%E5%AE%9D%E5%A1%94-linux-%E9%9D%A2%E6%9D%BF%E5%AE%89%E8%A3%85-flarum-v16/2\">https://forum.gitzaai.com/d/81-2022%E5%B9%B4%E5%AE%9D%E5%A1%94-linux-%E9%9D%A2%E6%9D%BF%E5%AE%89%E8%A3%85-flarum-v16/2</URL></LI>\n<i>&gt; </i><LI><s>2. </s><URL url=\"https://forum.gitzaai.com/d/78-%E4%BD%BF%E7%94%A8-flarum-%E5%B8%B8%E7%94%A8%E5%88%B0%E7%9A%84%E7%9F%A5%E8%AF%86/2\">https://forum.gitzaai.com/d/78-%E4%BD%BF%E7%94%A8-flarum-%E5%B8%B8%E7%94%A8%E5%88%B0%E7%9A%84%E7%9F%A5%E8%AF%86/2</URL></LI></LIST></QUOTE>\n\n<LIST><LI><s>- </s>安装插件，并编写脚本文件，进行二次重新安装。</LI>\n<LI><s>- </s>当日晚上再次崩溃，继续进行修复。</LI></LIST>\n\n<H2><s>## </s>2023年12月27日</H2>\n\n<LIST><LI><s>- </s>更换主题，替换原 <C><s>`</s>OYO<e>`</e></C> ，现使用 <C><s>`</s>Fluent<e>`</e></C> 。</LI>\n<LI><s>- </s>更换全站字体</LI> </LIST>\n\n<p>参考教程：<URL url=\"https://forum.gitzaai.com/d/99-flarum%E4%BD%BF%E7%94%A8%E8%87%AA%E5%AE%9A%E4%B9%89%E5%AD%97%E4%BD%93%E9%9C%9E%E9%B9%9C%E6%96%87%E6%A5%B7%E7%89%88\">https://forum.gitzaai.com/d/99-flarum%E4%BD%BF%E7%94%A8%E8%87%AA%E5%AE%9A%E4%B9%89%E5%AD%97%E4%BD%93%E9%9C%9E%E9%B9%9C%E6%96%87%E6%A5%B7%E7%89%88</URL></p>\n\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i> /* 字体 */\nbody {\n    font-family: San Francisco, Helvetica Neue, LXGW WenKai Screen, Arial, sans-serif;\n  }\n  \n  h1, h2, h3, h4, .TagsLabel, .Button, .DiscussionListItem-count, .item-discussion-views {\n    font-family: San Francisco, Helvetica Neue, LXGW WenKai Screen, Arial, sans-serif;\n  }<i>\n</i><e>```</e></CODE>\n\n<LIST><LI><s>- </s>去除顶部关闭横幅按钮</LI></LIST>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 取消欢迎关闭按钮 */\n.Hero-close{\n	display:none;\n}<i>\n</i><e>```</e></CODE>\n\n<LIST><LI><s>- </s>完成网站https部署</LI></LIST>\n\n<CODE lang=\"shell\"><s>```shell</s><i>\n</i>sudo certbot certonly -d *.foreseestudioblog.top -d foreseestudioblog.top --manual --preferred-challenges dns --server https://acme-v02.api.letsencrypt.org/directory<i>\n</i><e>```</e></CODE>\n\n<p>参考教程：<URL url=\"https://cloud.tencent.com/developer/article/2088187\">https://cloud.tencent.com/developer/article/2088187</URL></p>\n\n<LIST><LI><s>- </s>编写脚本列表，并整理未来规划。</LI>\n<LI><s>- </s>完善部分拓展，并备份源码及数据库。</LI>\n<LI><s>- </s>优化中文搜索功能，对数据库进行整理。</LI></LIST>\n\n<p>参考教程：<URL url=\"https://discuss.flarum.org.cn/d/1216\">https://discuss.flarum.org.cn/d/1216</URL></p>\n\n<LIST><LI><s>- </s>跟新Link功能的链接。</LI></LIST>\n\n<H2><s>## </s>2023年12月28日</H2>\n\n<LIST><LI><s>- </s><p>更新俄语语言包，进一步推进论坛国际化。</p></LI>\n<LI><s>- </s><p>移除原手机 UI 适配器，更换新的为 <C><s>`</s>Mobile tab<e>`</e></C> 进一步优化使用体验。</p></LI>\n<LI><s>- </s><p>添加 <C><s>`</s>Mercury<e>`</e></C> 插件，以方便管理插件更新。</p></LI>\n<LI><s>- </s><p>修改文章标签，添加标签，进一步美化文章。</p></LI>\n<LI><s>- </s><p>顶部横条实现手机端不显示，不再影响手机端搜索框位置错位的情况。</p></LI>\n<LI><s>- </s><p>顶部搜索重写css样式，确保手机端显示不错位。</p></LI>\n<LI><s>- </s><p>添加违规词监测功能。</p></LI>\n<LI><s>- </s><p>使用 <C><s>`</s>Mercury<e>`</e></C> 插件管理拓展更新。</p></LI>\n<LI><s>- </s><p>完成SEO搜索优化</p>\n\n  <LIST><LI><s>- </s><p>优化关键词</p></LI>\n  <LI><s>- </s><p>bing搜索</p></LI>\n  <LI><s>- </s><p>goole搜索</p></LI>\n  <LI><s>- </s><p>检查正反搜索均可用</p></LI></LIST></LI></LIST>\n\n<H2><s>## </s>2023年12月29日</H2>\n\n<LIST><LI><s>- </s><p>添加回到顶部功能。</p> </LI>\n\n<LI><s>- </s><p>编写论坛社区规范。</p></LI>\n\n<LI><s>- </s><p>重写cookie同意。</p></LI>\n\n<LI><s>- </s><p>服务器添加微软雅黑字体。</p>\n  <LIST><LI><s>- </s>教程：<URL url=\"https://blog.csdn.net/ljn398431/article/details/102580188\">https://blog.csdn.net/ljn398431/article/details/102580188</URL></LI></LIST></LI>\n  \n<LI><s>- </s><p>关闭部分插件</p>\n  <LIST><LI><s>- </s>关闭投票插件<C><s>`</s>FoF Polls<e>`</e></C></LI>\n  <LI><s>- </s>关闭<C><s>`</s>Pusher<e>`</e></C>插件</LI></LIST></LI>\n  \n<LI><s>- </s><p>弃用部分插件</p>\n  <LIST><LI><s>- </s><STRONG><s>**</s>足迹<e>**</e></STRONG>(Discussion views)：<C><s>`</s>composer remove michaelbelgium/flarum-discussion-views<e>`</e></C></LI>\n  <LI><s>- </s><STRONG><s>**</s>FoF HTML Errors<e>**</e></STRONG>：<C><s>`</s>composer remove fof/html-errors<e>`</e></C></LI></LIST></LI>\n\n<LI><s>- </s><p>更新新的插件：</p>\n  <LIST><LI><s>- </s><STRONG><s>**</s>Font Awesome 6<e>**</e></STRONG>：<C><s>`</s>composer require blomstra/fontawesome:\"*\"<e>`</e></C></LI>\n  <LI><s>- </s><STRONG><s>**</s>Auto More<e>**</e></STRONG>：<C><s>`</s>composer require katosdev/automore<e>`</e></C></LI></LIST></LI></LIST>\n  <br/>\n<H2><s>## </s>2023年12月30日</H2>\n\n  <LIST><LI><s>- </s><p>弃用部分插件</p>\n    <LIST><LI><s>- </s>Font Awesome：<C><s>` </s>composer remove blomstra/fontawesome<e>`</e></C></LI>\n    <LI><s>- </s>当它进入视图时自动单击“加载更多”按钮<C><s>`</s>composer remove katosdev/automore<e>`</e></C></LI></LIST></LI>\n\n<LI><s>- </s><p>新增插件</p></LI>\n  <LI><s>- </s><p>Markdown Paste：<C><s>`</s>composer require yohtozze/markdown-paste<e>`</e></C></p></LI>\n  <LI><s>- </s><p>邮件美化：<C><s>`</s>composer require fof/pretty-mail<e>`</e></C></p></LI>\n  <LI><s>- </s><p>目录：<C><s>`</s>composer require tohsakarat/table-of-content<e>`</e></C></p></LI></LIST>\n\n<QUOTE><i>&gt; </i><p>注意：即日起，本论坛开始投入运行！备份！备份！备份！</p></QUOTE>\n</r>','2023-12-30 16:16:42',1,NULL,NULL,'127.0.0.1',0,1,0,0),(9,1,2,'2023-12-27 14:36:11',1,'discussionTagged','[[1],[2]]',NULL,NULL,NULL,NULL,NULL,0,1,0,0),(10,3,2,'2023-12-27 14:42:00',1,'discussionTagged','[[1],[2]]',NULL,NULL,NULL,NULL,NULL,0,1,0,0),(11,8,2,'2023-12-27 14:58:58',1,'discussionRenamed','[\"\\u7f51\\u7ad9\\u66f4\\u65b0\\u65e5\\u5fd7\",\"\\u66f4\\u65b0\\u65e5\\u5fd7\"]',NULL,NULL,NULL,NULL,NULL,0,1,0,0),(12,2,2,'2023-12-27 15:00:40',1,'discussionSuperStickied','{\"stickiest\":true}',NULL,NULL,NULL,NULL,NULL,0,1,0,0),(13,9,1,'2023-12-27 15:04:07',1,'comment','<r><H1><s># </s>整理composer安装版本的python脚本<e> </e></H1>\n\n<QUOTE><i>&gt;</i><p>脚本实现的功能是去除composer安装命令后的版本号</p></QUOTE>\n\n<CODE lang=\"python\"><s>```python</s><i>\n</i>def remove_version_numbers(commands):\n    \"\"\"\n Remove version numbers from composer require commands.\n\n Args:\n commands (list of str): List of composer require commands.\n\n Returns:\n list of str: Commands with version numbers removed.\n \"\"\"\n    cleaned_commands = []\n    for command in commands:\n        # Split the command by space and remove any part that starts with \'^\'\n        parts = [part for part in command.split() if not part.startswith(\'^\')]\n        cleaned_command = \' \'.join(parts)\n        cleaned_commands.append(cleaned_command)\n\n    return cleaned_commands\n\n\ndef main():\n    print(\"请输入您的 Composer 命令，每行一个。输入 \'END\' 来结束输入：\")\n    user_input = []\n    while True:\n        line = input()\n        if line == \"END\":\n            break\n        user_input.append(line)\n\n    # 移除版本号\n    cleaned_commands = remove_version_numbers(user_input)\n    print(\"\\n处理后的命令：\")\n    for command in cleaned_commands:\n        print(command)\n\n\nif __name__ == \"__main__\":\n    main()<i>\n\n</i><e>```</e></CODE></r>',NULL,NULL,NULL,NULL,'127.0.0.1',0,1,0,0),(14,10,1,'2023-12-28 04:59:48',2,'comment','<r><p>无论你们将来决定什么，世界都需要你们的活力以及激情，你的焦虑终将褪去，不要害怕冒险，忽略那些流言蜚语。历史不会掌握在一个人手里，但是如果真的有那么一天，一定要记住那一刻，要知道，你可以成为那个人，你应该成为那个人，你一定要成为那个人！ ——Tim Cook在乔治华盛顿大学演讲</p>\n\n<p>LOGO来历 LOGO<br/>\nNEW-LOGO</p>\n\n<p>​ LOGO以极简作为设计理念，将代码和人工智能技术充分结合，展现出一种现代化且科技感十足的形象。LOGO采用了简洁的几何形状，以表达我们对简洁、高效的追求。在LOGO的中心，融入了一个由代码组成的图形，象征着我们的技术实力和创新能力。这个图形不仅代表了代码的力量，也代表了我们与人工智能的紧密联系。​ LOGO的主要颜色是鲜明的蓝色，这是一种代表着智慧和未来的颜色。蓝色的选择体现了我们对科技和革新的执着追求，同时也传递了我们对用户体验的关注和承诺。​ 通过这样一个极简设计的LOGO，我们希望能够形象地展示我们作为一家技术驱动的公司所代表的价值。我们致力于将人工智能技术融入到日常生活中，为用户带来便利和智能化的体验。同时，我们也将继续不断创新和进步，为未来的科技发展贡献力量。</p>\n\n<p>团队简介 Team Briefing<br/>\n​ 先知科技工作室(FORESEE STUDIO)是一家领先的人工智能信息研发团队，成立于2021年3月，专注于研究、开发和应用创新的人工智能技术。我们的团队由一群充满激情和专业知识的工程师和设计师组成，致力于将人工智能技术融入各行业的实际应用。</p>\n\n<p>​ 我们通过不断探索和创新，提供高质量的人工智能解决方案，帮助企业和组织获得先进的智能化工具和服务。我们的技术涵盖机器学习、计算机视觉、AI绘画、大语言模型等多个领域。</p>\n\n<p>智能未来提供的解决方案包括但不限于：</p>\n\n<p>1.起重设备智能监测预警集成系统：</p>\n\n<p>运用人工智能、云计算、工业智能识别等技术，通过平台+硬件的方式，为起重设备制作的智能监测预警集成系统。本系统采用了先进的无线传输技术和云计算技术技术，能够将起重设备的数据远程传输到云端服务器，并可以通过多端进行实时查看和管理，实现了对起重设备的远程监测和智能化管理。</p>\n\n<p>产品覆盖了塔式起重机、桥式起重机、门式起重机、汽车吊车、履带吊车等多种类型的起重设备，能够实现对起重设备的载荷、高度、幅度、速度、倾斜角度、风速、温度等参数的精确测量和显示，以及对超限、碰撞、断电、故障等异常情况的实时报警和记录。</p>\n\n<p>在应用过程中实现“人防+技防”的生命周期安全管理效果，为客户提供高效、安全、可靠的起重设备智能监测服务，帮助客户提高起重设备的使用效率和寿命，降低运行成本和维护费用，保障工程进度和质量，减少人员伤亡和经济损失。</p>\n\n<p>2.GATAIT：生成式人工智能文本与图像结合技术（技术细节暂且保密）</p>\n\n<p>子品牌LOGO<br/>\n图为起重设备智能监测预警集成系统项目的宣传LOGO<br/>\n&lt;img src=”<URL url=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img/202307272053290.png\">https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img/202307272053290.png</URL>” alt=”新LOGO(竖版-白底)” style=”zoom: 70%;/&gt;</p>\n\n<p>图为GATAIT的宣传LOGO（暂定）<br/>\nLOGO</p>\n\n<p>知识产权<br/>\n软件著作权</p>\n	\n<p>作品著作权</p>\n\n<p>查新报告</p>\n	\n<i>	</i>\n<p>报告中指出：委托方的技术在所查的国内文献范围内，未见其它相同或类似报道，本项目具有新颖性。</p>\n\n<p>所获殊荣</p>\n	\n<p>合作伙伴<br/>\n01 江苏普达思信息科技有限公司</p>\n	\n<p>02 南京康易视信息科技有限公司</p>\n	\n<p>03 南京栖瑞科技技术服务有限公司</p>\n	</r>',NULL,NULL,NULL,NULL,'127.0.0.1',0,1,1,1),(15,11,1,'2023-12-28 05:40:45',2,'comment','<r><H1><s># </s>Foresee Studio来袭，公众号内容大调整！</H1>\n\n<HR>----</HR>\n\n<H2><s>## </s>01 公 告 CN</H2>\n\n<p>亲爱的读者：</p>\n\n<p>  感谢大家一直以来对我们公众号的支持和关注！我们的团队一直在努力为大家提供有价值的内容和良好的阅读体验。</p>\n\n<p>  在这里，我们要通知大家一些业务变动的消息，希望能得到大家的理解和支持。</p>\n\n<p>  自2023年7月3日起，因项目需求变动，原先知科技工作室改名为Foresee Studio，原公众号简介随业务需求变动。我们将对公众号的内容进行优化和调整，以更好地满足读者的需求。</p>\n\n<p>  我们希望听到更多您对于我们公众号的意见和建议。如果有任何想法或者对我们的业务变动有疑问，欢迎通过以下途径与我们联系：</p>\n\n<LIST><LI><s>- </s>微信公众号：Foresee Studio</LI>\n<LI><s>- </s>邮箱：<EMAIL email=\"Foresee-Studio@outlook.com\">Foresee-Studio@outlook.com</EMAIL></LI></LIST>\n\n<p>  感谢大家的支持和理解！我们将努力不懈，为大家提供更好的阅读体验和内容。</p>\n\n<p>祝好！</p>\n\n<p>Foresee Studio</p>\n\n<p>2023年7月2日</p>\n\n<H2><s>## </s>02 Notice EN</H2>\n\n<p>Dear readers,</p>\n\n<p>  Thank you for your continuous support and attention to our official account!</p>\n\n<p>  Our team has been working hard to provide valuable content and a pleasant reading experience for all of you.</p>\n\n<p>  We would like to inform you about some changes in our business operations, and we hope to gain your understanding and support.</p>\n\n<p>  Starting from July 2nd, 2023, due to changes in project requirements, Zhi Technology Studio, formerly known as, will be renamed as Foresee Studio, along with necessary adjustments to our official account’s introduction.</p>\n\n<p>  We will be optimizing and adjusting the content of our account to better meet the needs of our readers.We would love to hear more of your thoughts and suggestions regarding our official account.</p>\n\n<p>  If you have any ideas or questions about our business changes, please feel free to contact us through the following channels:</p>\n\n<LIST><LI><s>- </s>WeChat: Foresee</LI>\n<LI><s>- </s>StudioEmail: <EMAIL email=\"Foresee-Studio@outlook.com\">Foresee-Studio@outlook.com</EMAIL></LI></LIST>\n\n<p>  Thank you for your support and understanding! We will continue to strive and provide you with a better reading experience and content.</p>\n\n<p>Best regards,</p>\n\n<p>Foresee Studio</p>\n\n<p>July 2, 2023.</p></r>','2023-12-28 05:44:46',2,NULL,NULL,'127.0.0.1',0,1,1,1),(16,12,1,'2023-12-28 05:53:08',2,'comment','<r><H2><s>## </s>乔布斯的人生启示录</H2>\n\n<p><BILIBILI bvid=\"1UQ4y147ka\"><URL url=\"https://www.bilibili.com/video/BV1UQ4y147ka?t=60.9\">https://www.bilibili.com/video/BV1UQ4y147ka?t=60.9</URL></BILIBILI></p>\n\n<QUOTE><i>&gt; </i><p>我们生来就是为了在宇宙中留下印记。<br/>\n<i>&gt; </i>We\'re here to put a dent in the universe.<br/>\n<i>&gt; </i>—— 乔布斯 Steve Jobs</p></QUOTE>\n\n<p><IMG alt=\"IMG_9517\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9517.JPG\"><s>![</s>IMG_9517<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9517.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>Thank you!</p></QUOTE>\n\n<p>感谢大家！</p>\n\n<p><IMG alt=\"IMG_9518\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9518.JPG\"><s>![</s>IMG_9518<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9518.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>I am honored to be with you today at your commencement from one of the finest universities in the world. Truth be told, I never graduated from college, and this is the closest I\'ve ever gotten to a college graduation. Today I want to tell you three stories from my life. That\'s it. No big deal. Just three stories.</p></QUOTE>\n\n<p>我今天很荣幸能和你们一起参加毕业典礼，斯坦福大学是世界上最好的大学之一。我从来没有从大学中毕业。说实话,今天也许是在我的生命中离大学毕业最近的一天了。今天我想向你们讲述我生活中的三个故事。不是什么大不了的事情,只是三个故事而已。</p>\n\n<HR>---</HR>\n\n<H2><s>## </s>第一个故事是关于如何把生命中的点点滴滴串连起来</H2>\n\n<H2><s>## </s>The first story is about connecting the dots.</H2>\n\n<QUOTE><i>&gt; </i><p>I dropped out of Reed College after the first 6 months, but then stayed around as a drop-in for another 18 months or so before I really quit. So why did I drop out？</p></QUOTE>\n\n<p>我在Reed大学读了六个月之后就退学了,但是在十八个月以后——我真正的作出退学决定之前,我还经常去学校。我为什么要退学呢？</p>\n\n<QUOTE><i>&gt; </i><p>It started before I was born. My biological mother was a young, unwed college graduate student, and she decided to put me up for adoption. She felt very strongly that I should be adopted by college graduates, so everything was all set for me to be adopted at birth by a lawyer and his wife. Except that when I popped out they decided at the last minute that they really wanted a girl.</p></QUOTE>\n\n<p>故事从我出生的时候讲起。我的亲生母亲是一个年轻的,没有结婚的大学毕业生。她决定让别人收养我, 她十分想让我被大学毕业生收养。所以在我出生的时候，她已经做好了一切的准备工作，能使得我被一个律师和他的妻子所收养。但是她没有料到,当我出生之后, 律师夫妇突然决定他们想要一个女孩。</p>\n\n<QUOTE><i>&gt; </i><p>So my parents, who were on a waiting list, got a call in the middle of the night asking: \"We have an unexpected baby boy; do you want him？\" They said: \"Of course.\" My biological mother later found out that my mother had never graduated from college and that my father had never graduated from high school. She refused to sign the final adoption papers. She only relented a few months later when my parents promised that I would go to college. This was a start in my life.</p></QUOTE>\n\n<p>所以我的生养父母(他们还在我亲生父母的观察名单上)突然在半夜接到了一个电话:“我们现在这儿有一个不小心生出来的男婴,你们想要他吗？”他们回答道:“当然!”但是我亲生母亲随后发现，我的养母从来没有上过大学,我的父亲甚至从没有读过高中。她拒绝签这个收养合同。几个月以后,当我的父母答应她一定要让我上大学的时候,她才勉强同意。这是我人生的开始。</p>\n\n<QUOTE><i>&gt; </i><p>And 17 years later I did go to college. But I naively chose a college that was almost as expensive as Stanford, and all of my working-class parents\' savings were being spent on my college tuition. After six months, I couldn\'t see the value in it. I had no idea what I wanted to do with my life and no idea how college was going to help me figure it out.</p></QUOTE>\n\n<p>在十七岁那年,我真的上了大学。但是我很愚蠢的选择了一个几乎和你们斯坦福大学一样贵的学校, 我父母还处于蓝领阶层，他们几乎把所有积蓄都花在了我的学费上面。在六个月后, 我已经看不到其中的价值所在。我不知道我想要在生命中做什么,我也不知道大学能帮助我找到怎样的答案。</p>\n\n<QUOTE><i>&gt; </i><p>And here I was spending all of the money my parents had saved their entire life. So I decided to drop out and trust that it would all work out OK. It was pretty scary at the time, but looking back it was one of the best decisions I ever made. The minute I dropped out I could stop taking the required classes that didn\'t interest me, and begin dropping in on the ones that looked far more interesting.</p></QUOTE>\n\n<p>而我在这里上学，几乎花光了父母一辈子的积蓄。所以我决定退学,并且相信一切都会好起来的。当时我十分害怕, 但是现在回想一下，退学是我做过最正确的决定之一。退学的那一刻起, 我终于可以不必去读那些令我提不起丝毫兴趣的课程了，我可以去听那些看起来更有趣的课程。</p>\n\n<p><IMG alt=\"IMG_9520\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9520.JPG\"><s>![</s>IMG_9520<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9520.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>It wasn\'t all romantic. I didn\'t have a dorm room, so I slept on the floor in friends\' rooms, I returned coke bottles for the 5¢ deposits to buy food with, and I would walk the 7 miles across town every Sunday night to get one good meal a week at the Hare Krishna temple. I loved it. And much of what I stumbled into by following my curiosity and intuition turned out to be priceless later on. Let me give you one example:</p></QUOTE>\n\n<p>但是这并不是那么浪漫。我失去了我的宿舍,所以我只能在朋友房间的地板上面睡觉,我去捡5美分的可乐瓶子，仅仅为了填饱肚子, 在星期天的晚上,我需要走七英里的路程，穿过这个城市到Hare Krishna寺庙(注：位于纽约Brooklyn下城),只是为了能吃上饭——这个星期唯一一顿好一点的饭。但是我喜欢这样。我跟着我的直觉和好奇心走, 遇到的很多东西,此后被证明是无价之宝。让我给你们举一个例子吧：</p>\n\n<QUOTE><i>&gt; </i><p>Reed College at that time offered perhaps the best calligraphy instruction in the country. Throughout the campus every poster, every label on every drawer, was beautifully hand calligraphed. Because I had dropped out and didn\'t have to take the normal classes, I decided to take a calligraphy class to learn how to do this.</p></QUOTE>\n\n<p>Reed大学在那时提供也许是全美最好的美术字课程。在这个大学里面的每个海报, 每个抽屉的标签上面全都是漂亮的美术字。因为我退学了, 没有受到正规的训练, 所以我决定去参加这个课程，去学学怎样写出漂亮的美术字。</p>\n\n<QUOTE><i>&gt; </i><p>I learned about serif and san serif typefaces, about varying the amount of space between different letter combinations, about what makes great typography great. It was beautiful, historical, artistically subtle in a way that science can\'t capture, and I found it fascinating.</p></QUOTE>\n\n<p>我学到了san serif 和serif字体, 我学会了怎么样在不同的字母组合之中改变空格的长度, 还有怎么样才能作出最棒的印刷式样。那是一种科学永远不能捕捉到的、美丽的、真实的艺术精妙, 我发现那实在是太美妙了。</p>\n\n<QUOTE><i>&gt; </i><p>None of this had even a hope of any practical application in my life. But ten years later, when we were designing the first Macintosh computer, it all came back to me. And we designed it all into the Mac. It was the first computer with beautiful typography. If I had never dropped in on that single course in college, the Mac would have never had multiple typefaces or proportionally spaced fonts.</p></QUOTE>\n\n<p>当时看来，这些东西好像对我的人生来说没有任何实用价值，但是十年之后,当我们在设计第一台Macintosh电脑的时候,它一下子浮现了出来。我们将这些东西全部设计进了Mac。那是第一台使用了漂亮的印刷字体的电脑。</p>\n\n<QUOTE><i>&gt; </i><p>And since Windows just copied the Mac, its likely that no personal computer would have them. If I had never dropped out, I would have never dropped in on this calligraphy class, and personal computers might not have the wonderful typography that they do. Of course it was impossible to connect the dots looking forward when I was in college. But it was very, very clear looking backwards ten years later.</p></QUOTE>\n\n<p>如果我当时没有退学, 就不会有机会去参加这个我感兴趣的美术字课程, Mac就不会有这么多丰富的字体，以及赏心悦目的字体间距。那么现在个人电脑就不会有现在这么美妙的字型了。如果我没有退学，没有旁听这门书法课，也许所有电脑都不会有如此美丽的印刷体。当然在大学的时候，我不可能预见到它们之间的联系,但是当我十年后回顾这一切的时候,一切都非常明了。</p>\n\n<QUOTE><i>&gt; </i><p>Again, you can\'t connect the dots looking forward; you can only connect them looking backwards. So you have to trust that the dots will somehow connect in your future. You have to trust in something - your gut, destiny, life, karma, whatever. This approach has never let me down, and it has made all the difference in my life.</p></QUOTE>\n\n<p><STRONG><s>**</s>再次强调，没人可以未卜先知，事与事间的因和果，往往只在回首时显现。你得相信，因和果会在未来生活中联系起来。人总要有些信仰才行，直觉也好，命运也罢，因果轮回，不管什么，去相信因与果的联系，会给你信心去跟从自己的意愿，哪怕离经叛道，也绝不止步，只有这样，才能有所成就。<e>**</e></STRONG></p>\n\n<H2><s>## </s>我的第二个故事是关于爱和损失的</H2>\n\n<H2><s>## </s>My second story is about love and loss.</H2>\n\n<p><IMG alt=\"IMG_9521\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9521.JPG\"><s>![</s>IMG_9521<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9521.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>I was lucky – I found what I loved to do early in life. Woz and I started Apple in my parents garage when I was 20. We worked hard, and in 10 years Apple had grown from just the two of us in a garage into a billion company with over 4000 employees. We had just released our finest creation - the Macintosh - a year earlier, and I had just turned 30.</p></QUOTE>\n\n<p>我非常幸运, 因为我在很早的时候就找到了我钟爱的东西。Woz和我在二十岁的时候就在父母的车库里面开创了苹果公司。我们工作得很努力, 十年之后, 这个公司从那两个车库中的穷光蛋发展到了超过四千名的雇员、价值超过二十亿的大公司。在公司成立的第九年,我们刚刚发布了最好的产品,那就是 Macintosh。我也快要到三十岁了。</p>\n\n<p><IMG alt=\"IMG_9523\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9523.JPG\"><s>![</s>IMG_9523<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9523.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>And then I got fired. How can you get fired from a company you started？Well, as Apple grew we hired someone who I thought was very talented to run the company with me, and for the first year or so things went well. But then our visions of the future began to diverge and eventually we had a falling out. When we did, our Board of Directors sided with him. So at 30 I was out. And very publicly out. What had been the focus of my entire adult life was gone, and it was devastating.</p></QUOTE>\n\n<p>在那一年, 我被炒了鱿鱼。你怎么可能被你自己创立的公司炒了鱿鱼呢？嗯,在苹果快速成长的时候，我们雇用了一个很有天分的家伙和我一起管理这个公司, 在最初的几年,公司运转的很好。但是后来我们对未来的看法发生了分歧, 最终我们吵了起来。当争吵不可开交的时候, 董事会站在了他的那一边。所以在三十岁的时候, 我被炒了。在这么多人的眼皮下我被炒了。在而立之年，我生命的全部支柱离自己远去, 这真是毁灭性的打击。</p>\n\n<QUOTE><i>&gt; </i><p>I really didn\'t know what to do for a few months. I felt that I had let the previous generation of entrepreneurs down - that I had dropped the baton as it was being passed to me. I met with David Packard and Bob Noyce and tried to apologize for screwing up so badly.</p></QUOTE>\n\n<p>在最初的几个月里，我真是不知道该做些什么。我把从前的创业激情给丢了, 我觉得自己让与我一同创业的人都很沮丧。我和David Pack和Bob Boyce见面，并试图向他们道歉。</p>\n\n<p><IMG alt=\"IMG_9525\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9525.JPG\"><s>![</s>IMG_9525<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9525.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>I was a very public failure, and I even thought about running away from the valley. But something slowly began to dawn on me – I still loved what I did. The turn of events at Apple had not changed that one bit. I had been rejected, but I was still in love. And so I decided to start over.</p></QUOTE>\n\n<p>我把事情弄得糟糕透顶了。但是我渐渐发现了曙光, 我仍然喜爱我从事的这些东西。苹果公司发生的这些事情丝毫的没有改变这些, 一点也没有。我被驱逐了,但是我仍然钟爱它。所以我决定从头再来。</p>\n\n<QUOTE><i>&gt; </i><p>I didn\'t see it then, but it turned out that getting fired from Apple was the best thing that could have ever happened to me. The heaviness of being successful was replaced by the lightness of being a beginner again, less sure about everything. It freed me to enter one of the most creative periods of my life.</p></QUOTE>\n\n<p>我当时没有觉察, 但是事后证明, 从苹果公司被炒是我这辈子发生的最棒的事情。因为，作为一个成功者的沉重感觉被作为一个创业者的轻松感觉所重新代替: 对任何事情都不那么特别看重。这让我觉得如此自由, 进入了我生命中最有创造力的一个阶段。</p>\n\n<QUOTE><i>&gt; </i><p>During the next five years, I started a company named NeXT, another company named Pixar, and fell in love with an amazing woman who would become my wife. Pixar went on to create the worlds first computer animated feature film, Toy Story, and is now the most successful animation studio in the world.</p></QUOTE>\n\n<p>在接下来的五年里, 我创立了一个名叫NeXT的公司, 还有一个叫Pixar的公司, 然后和一个后来成为我妻子的优雅女人相识。Pixar 制作了世界上第一个用电脑制作的动画电影——“玩具总动员”,Pixar现在也是世界上最成功的电脑制作工作室。</p>\n\n<QUOTE><i>&gt; </i><p>In a remarkable turn of events, Apple bought NeXT, I returned to Apple, and the technology we developed at NeXT is at the heart of Apple\'s current renaissance. And Laurene and I have a wonderful family together.</p></QUOTE>\n\n<p>在后来的一系列运转中,Apple收购了NeXT, 然后我又回到了Apple公司。我们在NeXT发展的技术在Apple的复兴之中发挥了关键的作用。我还和Laurence 一起建立了一个幸福的家庭。</p>\n\n<p><IMG alt=\"IMG_9527\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9527.JPG\"><s>![</s>IMG_9527<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9527.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>I\'m pretty sure none of this would have happened if I hadn\'t been fired from Apple. It was awful tasting medicine, but I guess the patient needed it. Sometimes life hits you in the head with a brick. Don\'t lose faith. I\'m convinced that the only thing that kept me going was that I loved what I did. You\'ve got to find what you love. And that is as true for your work as it is for your lovers. Your work is going to fill a large part of your life, and the only way to be truly satisfied is to do what you believe is great work. And the only way to do great work is to love what you do. If you haven\'t found it yet, keep looking. Don\'t settle. As with all matters of the heart, you\'ll know when you find it. And, like any great relationship, it just gets better and better as the years roll on. So keep looking until you find it. Don\'t settle.</p></QUOTE>\n\n<p>我可以非常肯定,如果我不被Apple开除的话, 这其中一件事情也不会发生的。这个良药的味道实在是太苦了,但是我想病人需要这个药。<STRONG><s>**</s>有时候生活会给你迎头一击，不要灰心丧气。我坚信，唯一可以让我坚持下去的，就是我对自己事业的热爱。你必须去寻找自己所爱，无论是工作还是爱情，都是如此。工作是生活中很主要的部分，真正获得满足感，就必须做你相信是有价值的工作。要做有价值的事业，你就必须热爱你做的事业，如果你还没找到，千万不要放弃，要继续寻找，只要倾听你的心声，当你真的发现时你就会感到，就像任何伟大的感情关系一样，岁月的更迭只会让这份情愈发深刻，所以千万不要放弃，要继续寻找。<e>**</e></STRONG></p>\n\n<H2><s>## </s>我的第三个故事是关于死亡的</H2>\n\n<H2><s>## </s>My third story is about death.</H2>\n\n<p><IMG alt=\"IMG_9529\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9529.JPG\"><s>![</s>IMG_9529<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9529.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>When I was 17, I read a quote that went something like: \"If you live each day as if it was your last, someday you\'ll most certainly be right.\" It made an impression on me, and since then, for the past 33 years, I have looked in the mirror every morning and asked myself: \"If today were the last day of my life, would I want to do what I am about to do today？\" And whenever the answer has been \"No\" for too many days in a row, I know I need to change something.</p></QUOTE>\n\n<p>当我十七岁的时候, 我读到了一句话:“如果你把每一天都当作生命中最后一天去生活的话,那么有一天你会发现你是正确的。”这句话给我留下了深刻的印象。从那时开始,过了33 年,我在每天早晨都会对着镜子问自己:“如果今天是我生命中的最后一天, 你会不会完成你今天想做的事情呢？”当答案连续很多次被给予“不是”的时候, 我知道自己需要改变某些事情了。</p>\n\n<QUOTE><i>&gt; </i><p>Remembering that I\'ll be dead soon is the most important tool I\'ve ever encountered to help me make the big choices in life. Because almost everything – all external expectations, all pride, all fear of embarrassment or failure - these things just fall away in the face of death, leaving only what is truly important. Remembering that you are going to die is the best way I know to avoid the trap of thinking you have something to lose. You are already naked. There is no reason not to follow your heart.</p></QUOTE>\n\n<p>提醒自己人的生命有限，令我一生都受益非常，令我能在人生重大问题上做出抉择。因为一切的一切，一切追求，一切荣耀，一切惶恐，一些挫折，在死亡面前都会显得微不足道 ，剩下的才是最重要的事情。记住自己总会死去是避免自己被种种担心所羁绊的最好方法，既然将一无所有，还有什么理由不追随自己的内心。</p>\n\n<QUOTE><i>&gt; </i><p>About a year ago I was diagnosed with cancer. I had a scan at 7:30 in the morning, and it clearly showed a tumor on my pancreas. I didn\'t even know what a pancreas was. The doctors told me this was almost certainly a type of cancer that is incurable, and that I should expect to live no longer than three to six months. My doctor advised me to go home and get my affairs in order, which is doctor\'s code for prepare to die. It means to try to tell your kids everything you thought you\'d have the next 10 years to tell them in just a few months. It means to make sure everything is buttoned up so that it will be as easy as possible for your family. It means to say your goodbyes.</p></QUOTE>\n\n<p>大概一年以前, 我被诊断出癌症。我在早晨七点半做了一个检查, 检查清楚的显示在我的胰腺有一个肿瘤。我当时都不知道胰腺是什么东西。医生告诉我那很可能是一种无法治愈的癌症, 我还有三到六个月的时间活在这个世界上。我的医生叫我回家, 然后整理好我的一切, 那就是医生准备死亡的程序。那意味着你将要把未来十年对你小孩说的话在几个月里面说完.;那意味着把每件事情都搞定, 让你的家人会尽可能轻松的生活;那意味着你要说“再见了”。</p>\n\n<QUOTE><i>&gt; </i><p>I lived with that diagnosis all day. Later that evening I had a biopsy, where they stuck an endoscope down my throat, through my stomach and into my intestines, put a needle into my pancreas and got a few cells from the tumor. I was sedated, but my wife, who was there, told me that when they viewed the cells under a microscope the doctors started crying because it turned out to be a very rare form of pancreatic cancer that is curable with surgery. I had the surgery and I\'m fine now.</p></QUOTE>\n\n<p>我整天和那个诊断书一起生活。后来有一天早上我作了一个活切片检查，医生将一个内窥镜从我的喉咙伸进去,通过我的胃, 然后进入我的肠子, 用一根针在我的胰腺上的肿瘤上取了几个细胞。我当时很镇静,因为我被注射了镇定剂。但是我的妻子在那里, 后来告诉我，当医生在显微镜地下观察这些细胞的时候他们开始尖叫, 因为这些细胞最后竟然是一种非常罕见的可以用手术治愈的胰腺癌症。我做了这个手术, 现在我痊愈了。</p>\n\n<QUOTE><i>&gt; </i><p>This was the closest I\'ve been to facing death, and I hope its the closest I get for a few more decades. Having lived through it, I can now say this to you with a bit more certainty than when death was a useful but purely intellectual concept:</p></QUOTE>\n\n<p>那是我最接近死亡的时候, 我还希望这也是以后的几十年最接近的一次。从死亡线上又活了过来, 死亡对我来说，只是一个有用但是纯粹是知识上的概念的时候，我可以更肯定一点地对你们说：</p>\n\n<p><IMG alt=\"IMG_9532\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9532.JPG\"><s>![</s>IMG_9532<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9532.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>No one wants to die. Even people who want to go to heaven don\'t want to die to get there. And yet death is the destination we all share. No one has ever escaped it. And that is as it should be, because Death is very likely the single best invention of Life. It is Life\'s change agent. It clears out the old to make way for the new. Right now the new is you, but someday not too long from now, you will gradually become the old and be cleared away. Sorry to be so dramatic, but it is quite true.</p></QUOTE>\n\n<p>没有人愿意死, 即使人们想上天堂, 人们也不会为了去那里而死。但是死亡是我们每个人共同的终点。从来没有人能够逃脱它。也应该如此。因为死亡就是生命中最好的一个发明。它将旧的清除以便给新的让路。你们现在是新的, 但是从现在开始不久以后, 你们将会逐渐的变成旧的然后被清除。我很抱歉这很戏剧性, 但是这十分的真实。</p>\n\n<p><IMG alt=\"IMG_9533\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9533.JPG\"><s>![</s>IMG_9533<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9533.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>Your time is limited, so don\'t waste it living someone else\'s life. Don\'t be trapped by dogma - which is living with the results of other people\'s thinking. Don\'t let the noise of other\'s opinions drown out your own inner voice. And most important, have the courage to follow your heart and intuition. They somehow already know what you truly want to become. Everything else is secondary.</p></QUOTE>\n\n<p><STRONG><s>**</s>人生有限，所以不要把时间浪费在重复其他人的生活上;不要被教条束缚，那只是根据别人的思维结果而生活，不要让他人的喧嚣纷繁，淹没了自己内心的声音。最重要的是，你要有勇气去跟随你的直觉和心灵，因为它们在某种程度上已经知道你想要成为什么样子，所有其他的事情都是次要的。<e>**</e></STRONG></p>\n\n<HR>------</HR>\n\n<p><IMG alt=\"IMG_9534\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9534.JPG\"><s>![</s>IMG_9534<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9534.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>When I was young, there was an amazing publication called The Whole Earth Catalog, which was one of the bibles of my generation. It was created by a fellow named Stewart Brand not far from here in Menlo Park, and he brought it to life with his poetic touch. This was in the late 1960\'s, before personal computers and desktop publishing, so it was all made with typewriters, scissors, and polaroid cameras. It was sort of like Google in paperback form, 35 years before Google came along: it was idealistic, and overflowing with neat tools and great notions.</p></QUOTE>\n\n  <p>在我年轻的时候，有本很棒的叫全球目录的杂志。被我们那代人奉为经典。它是由斯图尔特·布兰德在这附近的Menlo公园创办的。他把自己的文艺气质融汇其中。那是六十年代后期。那时还没有个人电脑。全用打字机，剪刀和宝丽来照相机。它就好比是三十五年前的简装版的谷歌。充满理想主义色彩。该书简洁实用，见解独到。</p>\n\n<p><IMG alt=\"IMG_9535\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9535.JPG\"><s>![</s>IMG_9535<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/IMG_9535.JPG)</e></IMG></p>\n\n<QUOTE><i>&gt; </i><p>Stewart and his team put out several issues of The Whole Earth Catalog, and then when it had run its course, they put out a final issue. It was the mid-1970s, and I was your age. On the back cover of their final issue was a photograph of an early morning country road, the kind you might find yourself hitchhiking on if you were so adventurous. Beneath it were the words: \"Stay Hungry. Stay Foolish.\" It was their farewell message as they signed off. Stay Hungry. Stay Foolish. And I have always wished that for myself. And now, as you graduate to begin anew, I wish that for you.</p>\n\n<i>&gt; </i><p><STRONG><s>**</s>Stay Hungry. Stay Foolish.<e>**</e></STRONG></p>\n\n<i>&gt; </i><p>Thank you all very much.</p></QUOTE>\n\n<p>斯图尔特团队出版了几期的全球目录。当它后来要停刊的时候，他们出来最后一版。那是七十年代中期，我就像你们这么大。杂志最后一期的封底上，是一幅清晨乡村公路的照片。是那种搭车旅行玩冒险时会遇到的村路，照片下面有这样一段话：求知若渴，虚心若愚。这是他们停刊的告别语。求知若渴，虚心若愚。我一直以此激励自己。在你们即将毕业开始崭新旅程的时刻，我希望你们也能做到：</p>\n\n<p><STRONG><s>**</s>求知若渴，虚心若愚。<e>**</e></STRONG></p>\n\n<p>谢谢大家！</p></r>','2023-12-28 06:26:27',2,NULL,NULL,'127.0.0.1',0,1,0,0),(17,13,1,'2023-12-28 08:07:56',1,'comment','<r>\n\n<H2><s>## </s>彩色横条手机端显示错位，影响页面布局</H2>\n\n<H3><s>### </s>问题描述</H3>\n\n<p>原彩色横条在PC端显示正常，但手机端显示错位，如图所示：</p>\n\n<p><IMG alt=\"image-20231228150431160\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281504219.png\"><s>![</s>image-20231228150431160<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281504219.png)</e></IMG></p>\n\n<p>原代码如下：</p>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 首页顶部条 */\n.IndexPage-toolbar::after {\n    content: \"唯愿公平如大水滚滚 | 使公义如江河滔滔\";\n    padding: 10px;\n    color: #ffffff;\n    border-radius: 50px;\n    text-align: center;\n    font-size: 16px;\n    background: linear-gradient(135deg, #29c7ac, #6699ff);\n    display: block;\n    margin: 5px 0;\n}<i>\n</i><e>```</e></CODE>\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i><p><STRONG><s>**</s>⚠警告：请备份所有数据再进行操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<LIST><LI><s>- </s>为了让彩色条在手机显示时隐藏，使用CSS的媒体查询（Media Query）。媒体查询允许您根据不同的屏幕尺寸应用不同的样式规则。通常，手机屏幕的宽度小于768像素。因此，添加一个媒体查询来隐藏彩色条，当屏幕宽度小于768像素时。</LI>\n<LI><s>- </s>在下述这段代码中，<C><s>`</s>.IndexPage-toolbar::after<e>`</e></C> 的样式在屏幕宽度大于768像素时保持不变。但是，当屏幕宽度小于或等于768像素时（即在手机屏幕上），<C><s>`</s>.IndexPage-toolbar::after<e>`</e></C> 的 <C><s>`</s>display<e>`</e></C> 属性被设置为 <C><s>`</s>none<e>`</e></C>，这意味着这个元素将会被隐藏。</LI>\n<LI><s>- </s>可以根据需要调整媒体查询中的 <C><s>`</s>max-width<e>`</e></C> 值以适应不同尺寸的手机屏幕。</LI></LIST>\n\n<p>更新后代码如下：</p>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 首页顶部条 */\n.IndexPage-toolbar::after {\n    content: \"唯愿公平如大水滚滚 | 使公义如江河滔滔\";\n    padding: 10px;\n    color: #ffffff;\n    border-radius: 50px;\n    text-align: center;\n    font-size: 16px;\n    background: linear-gradient(135deg, #29c7ac, #6699ff);\n    display: block;\n    margin: 5px 0;\n}\n\n/* 在手机屏幕上隐藏顶部彩色条 */\n@media (max-width: 768px) {\n    .IndexPage-toolbar::after {\n        display: none;\n    }\n}<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>表格布局美化</H2>\n\n<H3><s>### </s>问题描述</H3>\n\n<p>原表格样式间距太大，手机端无法适配。</p>\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i><p><STRONG><s>**</s>⚠警告：请备份所有数据再进行操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>固定布局<e>**</e></STRONG>：列宽固定，不随内容自动调整。</LI>\n<LI><s>- </s><STRONG><s>**</s>内容断行<e>**</e></STRONG>：允许内容在单元格内断行，防止溢出。</LI>\n<LI><s>- </s><STRONG><s>**</s>边框样式<e>**</e></STRONG>：单元格边框统一，颜色一致。</LI>\n<LI><s>- </s><STRONG><s>**</s>隔行变色<e>**</e></STRONG>：表格的每个偶数行和表头背景色设置为浅灰色，增强可读性。</LI>\n<LI><s>- </s><STRONG><s>**</s>表头加粗<e>**</e></STRONG>：表头文字加粗，突出显示。</LI>\n<LI><s>- </s><STRONG><s>**</s>内外边距调整<e>**</e></STRONG>：优化表格和单元格的内外边距，使布局更加紧凑。</LI></LIST>\n\n<p>更新后代码如下：</p>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 表格美化 */\ntable {\n    table-layout:fixed;\n    padding: 0;\n    word-break: break-all;\n    border-collapse: collapse;\n    margin: 0.8em 0;\n    width: 100%;\n}\ntable tr {\n    border: 1px solid #dfe2e5;\n    margin: 0;\n    padding: 0;\n}\ntable tr:nth-child(2n), thead {\n    background-color: #f8f8f8;\n}\ntable th {\n    font-weight: bold;\n    border: 1px solid #dfe2e5;\n    border-bottom: 0;\n    margin: 0;\n    padding: 6px 13px;\n    width: auto ! important;\n}\ntable td {\n    border: 1px solid #dfe2e5;\n    margin: 0;\n    padding: 6px 13px;\n}\ntable th:first-child, table td:first-child {\n    margin-top: 0;\n}\ntable th:last-child, table td:last-child {\n    margin-bottom: 0;\n}<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>字体美化</H2>\n\n<H3><s>### </s>问题描述</H3>\n\n<LIST><LI><s>- </s>需要更换字体</LI>\n<LI><s>- </s>需要保证字体可以适配全部设备</LI>\n<LI><s>- </s>在调试时部分设备字体出现乱码情况</LI></LIST>\n\n<p>如图所示：</p>\n\n<p><IMG alt=\"image-20231228152034896\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281520970.png\"><s>![</s>image-20231228152034896<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281520970.png)</e></IMG></p>\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i><p><STRONG><s>**</s>⚠警告：请备份所有数据再进行操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<LIST><LI><s>- </s>先添加js代码：打开 Flarum 「管理后台」，在 「外观」的 「自定义页眉」（<STRONG><s>**</s>Custom Header<e>**</e></STRONG>）加入如下代码：</LI></LIST>\n\n<CODE lang=\"javascript\"><s>```javascript</s><i>\n</i>&lt;link href=\"https://cdn.staticfile.org/lxgw-wenkai-screen-webfont/1.7.0/lxgwwenkaiscreen.css\" rel=\"stylesheet\"&gt;<i>\n</i><e>```</e></CODE>\n\n<LIST><LI><s>- </s>在「自定义样式CSS」 （<STRONG><s>**</s>Custom Styles<e>**</e></STRONG>）加入如下代码：</LI></LIST>\n\n<QUOTE><i>&gt; </i><p>注意：这里基本适配所有的终端设备字体，请根据自己的需求进行修改。</p></QUOTE>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 字体美化 - 添加苹果设备字体和通用备选字体 */\nbody {\n  font-family: \'LXGW WenKai Screen\', \'Times New Roman\', \'Times\', \'Georgia\', serif;\n}\n\nh1, h2, h3, h4, .TagsLabel, .Button, .DiscussionListItem-count, .item-discussion-views {\n  font-family: \'LXGW WenKai Screen\', \'Arial\', \'Helvetica Neue\', \'San Francisco\', sans-serif;\n}<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>取消欢迎关闭按钮</H2>\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i> <p><STRONG><s>**</s>⚠警告：请备份所有数据再进行操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>/* 取消欢迎关闭按钮 */\n.Hero-close{\n	display:none;\n}<i>\n</i><e>```</e></CODE>\n\n<H2><s>## </s>字体美化</H2>\n\n<H3><s>### </s>问题描述</H3>\n\n<LIST><LI><s>- </s>昵称过长、Link数量过多等原因导致搜索框错位，影响观感。</LI></LIST>\n\n<p>如图所示：</p>\n\n<p><IMG alt=\"image-20231228155706852\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281557898.png\"><s>![</s>image-20231228155706852<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312281557898.png)</e></IMG></p>\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i><p><STRONG><s>**</s>⚠警告：请备份所有数据再进行操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<LIST><LI><s>- </s>在「自定义样式CSS」 （<STRONG><s>**</s>Custom Styles<e>**</e></STRONG>）加入如下代码：</LI></LIST>\n\n<CODE lang=\"css\"><s>```css</s><i>\n</i>@media (min-width: 768px) and (max-width: 1099px) {\n  .Header-primary .Header-controls {\n    max-width: 200px;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n  }\n  .Header-primary:after {\n    content: \" &gt; \";\n    margin-left: 20px;\n  }\n\n  .Header-primary:hover {\n    padding-right: 30px;\n    padding-bottom: 20px;\n  }\n  .Header-primary:hover .Header-controls {\n    transition: max-width 1s;\n    max-width: 1000px;\n    overflow: unset;\n    animation: delay-overflow-unset 1s;\n  }\n  @keyframes delay-overflow-unset {\n    from {\n      overflow: hidden;\n    }\n    to {\n      overflow: unset;\n    }\n  }\n  .Header-primary:hover:after {\n    content: \"\";\n  }\n\n  .Header-primary:hover + .Header-secondary {\n    white-space: nowrap;\n    overflow: hidden;\n    margin-right: 20px;\n    float: unset;\n  }\n}\n\n.Header-secondary .item-session button {\n  max-width: 140px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}<i>\n</i><e>```</e></CODE></r>',NULL,NULL,NULL,NULL,'127.0.0.1',0,1,0,0),(18,14,1,'2023-12-28 08:08:38',1,'comment','<r><H2><s>## </s>安装extiverse/mercury时报错</H2>\n\n<H3><s>### </s>问题描述</H3>\n\n<LIST><LI><s>- </s><p>作者在安装 <STRONG><s>**</s>Flarum<e>**</e></STRONG> 的插件 <C><s>`</s>extiverse/mercury<e>`</e></C> 时报错，内容如下图所示</p>\n\n  <p><IMG alt=\"image-20231228093444489\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312280934558.png\"><s>![</s>image-20231228093444489<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312280934558.png)</e></IMG></p></LI></LIST>\n\n\n\n<H3><s>### </s>解决方案</H3>\n\n<QUOTE><i>&gt; </i><p><STRONG><s>**</s>⚠警告：请备份所有数据再进行接下来的操作，此操作可能会导致网站不可用！<e>**</e></STRONG></p></QUOTE>\n\n<LIST type=\"decimal\"><LI><s>1. </s><STRONG><s>**</s>报错原因<e>**</e></STRONG>：主要问题是在安装过程中解决依赖关系。具体来说，<C><s>`</s>extiverse/mercury<e>`</e></C> 包与你项目当前状态或相互之间存在依赖冲突。\n   <LIST><LI><s>- </s><C><s>`</s>extiverse/mercury<e>`</e></C> 需要 <C><s>`</s>extiverse/api-client<e>`</e></C>，而这个包在不同版本中对 <C><s>`</s>guzzlehttp/guzzle<e>`</e></C> 包的要求不同。</LI>\n   <LI><s>- </s><C><s>`</s>extiverse/api-client<e>`</e></C> 的不同版本要求 <C><s>`</s>guzzlehttp/guzzle<e>`</e></C> 的版本为 <C><s>`</s>7.3.*<e>`</e></C>、<C><s>`</s>7.4.*<e>`</e></C> 或 <C><s>`</s>7.5.*<e>`</e></C>，但你的项目当前固定在另一个版本的 <C><s>`</s>guzzlehttp/guzzle<e>`</e></C>（7.8.1）。这导致了冲突，因为 Composer 无法同时满足这些版本要求。</LI></LIST></LI>\n<LI><s>2. </s><STRONG><s>**</s>解决方案建议<e>**</e></STRONG>：Composer 建议使用 <C><s>`</s>--with-all-dependencies<e>`</e></C>（<C><s>`</s>-W<e>`</e></C>）选项。这个选项允许 Composer 尝试通过考虑当前特定版本锁定的包的更新、降级和移除来解决这些冲突。这意味着 Composer 将尝试调整所有依赖关系。</LI>\n<LI><s>3. </s>结果如图所示：</LI></LIST>\n\n<p><IMG alt=\"QQ截图20231228094306\" src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312280943423.png\"><s>![</s>QQ截图20231228094306<e>](https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312280943423.png)</e></IMG></p></r>',NULL,NULL,NULL,NULL,'127.0.0.1',0,1,0,0),(19,15,1,'2023-12-29 17:34:24',1,'comment','<r><H1><s># </s>论坛社区规范</H1>\n\n<p>欢迎来到我们的社区！为了维护一个健康、积极的交流环境，我们制定了以下社区规范。请您仔细阅读并遵守这些规则，以确保每位成员都能享受到一个友好、尊重的讨论空间。</p>\n\n<H2><s>## </s>1. 尊重和礼貌</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>尊重他人<e>**</e></STRONG>：请尊重所有社区成员，无论他们的意见如何。</LI>\n<LI><s>- </s><STRONG><s>**</s>禁止歧视<e>**</e></STRONG>：严禁任何形式的种族、性别、性取向、宗教或文化歧视。</LI>\n<LI><s>- </s><STRONG><s>**</s>文明交流<e>**</e></STRONG>：在发表意见时，请保持文明和专业，避免使用侮辱性语言。</LI></LIST>\n\n<H2><s>## </s>2. 内容规范</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>相关性<e>**</e></STRONG>：确保您的帖子与论坛主题或讨论线索相关。</LI>\n<LI><s>- </s><STRONG><s>**</s>禁止非法内容<e>**</e></STRONG>：禁止发布任何非法、淫秽、暴力或侵犯他人版权的内容。</LI>\n<LI><s>- </s><STRONG><s>**</s>版权遵守<e>**</e></STRONG>：分享内容时，请尊重版权和知识产权。</LI>\n<LI><s>- </s><STRONG><s>**</s>广告限制<e>**</e></STRONG>：未经许可，不得发布广告或促销信息。</LI></LIST>\n\n<H2><s>## </s>3. 隐私和安全</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>保护隐私<e>**</e></STRONG>：不得公开他人的个人信息，包括但不限于地址、电话号码或电子邮件地址。</LI>\n<LI><s>- </s><STRONG><s>**</s>账户安全<e>**</e></STRONG>：保护您的账户信息，不得共享给他人。</LI></LIST>\n\n<H2><s>## </s>4. 发帖和回复</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>清晰准确<e>**</e></STRONG>：发帖时，请确保标题和内容清晰、准确。</LI>\n<LI><s>- </s><STRONG><s>**</s>禁止重复发帖<e>**</e></STRONG>：避免重复发布相同或极其相似的内容。</LI>\n<LI><s>- </s><STRONG><s>**</s>建设性反馈<e>**</e></STRONG>：回复他人时，请提供建设性和有帮助的反馈。</LI></LIST>\n\n<H2><s>## </s>5. 管理与违规处理</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>遵守版主决定<e>**</e></STRONG>：版主有权移除违反社区规范的内容，并对违规者采取必要措施。</LI>\n<LI><s>- </s><STRONG><s>**</s>违规后果<e>**</e></STRONG>：严重或持续违规可能导致禁言、账户暂停或永久封禁。</LI></LIST>\n\n<H2><s>## </s>6. 变更和通知</H2>\n\n<LIST><LI><s>- </s><STRONG><s>**</s>规范更新<e>**</e></STRONG>：我们可能会不时更新社区规范，以反映社区的变化和需求。</LI>\n<LI><s>- </s><STRONG><s>**</s>遵守最新规范<e>**</e></STRONG>：成员应定期查阅社区规范，确保遵守最新版本。</LI></LIST>\n\n<p>我们感谢您的加入和支持，并期待您的积极参与！一起努力，让我们的论坛社区成为一个充满活力、尊重和友好的交流平台。</p></r>',NULL,NULL,NULL,NULL,'127.0.0.1',0,1,0,0),(20,15,2,'2023-12-29 17:36:13',1,'discussionSuperStickied','{\"stickiest\":true}',NULL,NULL,NULL,NULL,NULL,0,1,0,0),(22,17,1,'2023-12-31 07:54:58',1,'comment','<r><H1><s># </s> 《窄门》读书笔记</H1>\n<CENTER><s>[center]</s><p><IMG src=\"https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312172257626.png\"><s>[img]</s>https://typora-img-1301299232.cos.ap-shanghai.myqcloud.com/img2/202312172257626.png<e>[/img]</e></IMG></p><e>[/center]</e></CENTER>\n\n<TABLE><THEAD><TR><i>| </i><TH align=\"center\">基础</TH><i> |              </i><TH align=\"center\">信息</TH><i>               |</i></TR></THEAD><i>\n| :--: | :-----------------------------: |</i>\n<TBODY><TR><i>| </i><TD align=\"center\">书名</TD><i> |            </i><TD align=\"center\">《窄门》</TD><i>             |</i></TR>\n<TR><i>| </i><TD align=\"center\">作者</TD><i> |         </i><TD align=\"center\">[法]安德烈·纪德</TD><i>         |</i></TR>\n<TR><i>| </i><TD align=\"center\">ISBN</TD><i> |        </i><TD align=\"center\">978-7-201-14152-7</TD><i>        |</i></TR>\n<TR><i>| </i><TD align=\"center\">分类</TD><i> | </i><TD align=\"center\">文学-外国文学-精品小说-情感小说</TD><i> |</i></TR></TBODY></TABLE>\n\n<QUOTE><i>&gt; </i><p>你们要努力进窄门。— —《路加福音》十三章 二十四节</p></QUOTE>\n\n<p>在法国文学的星空中，安德烈·纪德以其独特的光芒绽放着色彩。这位法国文学巨匠不仅在文学史上留下了不可磨灭的印记，还以其独特的文学视角和深邃的人性探索而闻名。在《窄门》中，纪德以精致的笔触勾勒出一幅爱与痛苦交织的画卷，体现了他对复杂情感的精准捕捉和在道德及宗教议题上的深刻思考。他的敏锐心理洞察力和精湛文笔揭示了人性的多面性和内心深处的冲突，使《窄门》成为一部值得细细品味的文学杰作。</p>\n\n<p>《窄门》围绕主人公杰罗姆和他的表妹阿莉莎的复杂爱情故事展开。这是一段始于青涩少年时期的爱恋，随着时间的流逝，两人的情感逐渐深化，但也日益充满了挑战和矛盾。杰罗姆对阿莉莎的爱充满热情和坚定，然而阿莉莎却因为对宗教的深深虔诚和对精神纯洁的追求而不断与这段感情保持距离。她坚信，只有舍弃世俗的爱情，才能获得灵魂的净化和救赎。这种信仰让她在爱情与信仰之间进行了痛苦的抉择，最终选择了后者。</p>\n\n<p>随着故事的发展，杰罗姆和阿莉莎的关系变得愈发复杂。他们在情感的拉扯和宗教信仰的冲突中不断挣扎。这段关系的复杂性在于它不仅仅是一段普通的恋爱故事，更是一场关于信仰、自我牺牲与个人欲望之间冲突的深刻探讨。纪德巧妙地利用杰罗姆和阿莉莎的故事，展现了爱情的本质和生命的道德选择。两人在情感的纠缠和信仰的冲突中不断挣扎，直至阿莉莎作出了一个重大决定，这不仅决定了她和杰罗姆的命运，也深刻体现了个人牺牲与追求之间的复杂关系。</p>\n\n<QUOTE><i>&gt; </i><p>关于爱情，不缓情。互相拉扯以让彼此过窄门，可最后谁也没到达彼岸，尽殉道在门前，不是为上帝，尽是为爱情。即便只能书信交流，不在一起才是最理想，因为窄门只允许通过一人。</p></QUOTE>\n\n<p>《窄门》描绘的是一种非常柏拉图式的爱情，即一个关于不可企及的爱、深藏的欲望和终究无法逾越的界限的故事。故事以杰罗姆和阿莉莎的情感纠葛为核心，展示了他们的爱情之美丽而痛苦，是一条充满了不确定性和内心挣扎的无法到达的道路。通过这段故事，纪德探讨了爱情的本质、牺牲的意义以及个人信仰与人性欲望之间的冲突，为我们呈现了一幅人性深处的复杂画面。</p>\n\n<p>在书中，安德烈·纪德展现了其独特的文学才华，通过精湛的文学手法和风格来增强故事的情感深度和内涵。他的笔触细腻而深刻，运用了富有象征意义的语言和心理描写，将读者引入一个充满复杂情感和道德探讨的世界。其对角色心理的描写尤为细腻。作者深入挖掘了杰罗姆和阿莉莎的内心世界，展现了他们在爱情、信仰和自我牺牲之间的矛盾和挣扎。通过内心独白和详尽的情感描述，让我们不仅看到人物角色的行为，更能感受到他们的情感波动和心理变化。</p>\n\n<QUOTE><i>&gt; </i><p>“我爱你，但你不要爱我。”<br/>\n<i>&gt; </i>“你爱我时，我会把这份爱狠狠推开，你不爱我时，我又独自哭泣。”<br/>\n<i>&gt; </i>“你在我身边时，让我的心支离破碎；但远离你时，我又不能成活。”</p></QUOTE>\n\n<p>在沉浸于《窄门》的篇章中，我被书中所描绘的深邃主题和细腻的情感所深深打动，以至于在阅读过程中不自觉地泪流满面。这是一种何等矛盾的爱情啊！它引发了我深深的思考：<STRONG><s>**</s>柏拉图式的爱情，究竟值不值得我们去追求？<e>**</e></STRONG> 这样的爱情强调心灵的相通与情感的纯净，通常远离肉体层面的关联。在小说中，主角间的爱情超越了物质和身体的限制，转而成为了一种深刻的精神连接。追求这样的爱情可能意味着个体需放弃某些欲望和需求，以保持心灵的纯洁和高尚。</p>\n	\n<p><STRONG><s>**</s>柏拉图式的爱情通常要求高度的自制力和道德准则，这在现代社会中可能显得尤为困难。在一个“快餐式”的时代，这种对精神连接的坚持可能显得格外孤独和艰难。这种爱情形式，虽然高尚且纯净，却可能导致内心的挣扎和孤独。因此，在现实生活中，柏拉图式的爱情往往难以持久，因为它在很大程度上忽视了人类情感的多元性和复杂性，与人的本能和情感需求产生冲突。<e>**</e></STRONG></p>\n	\n<p>这种爱情的追求，就如同书中的故事一样，是一段对理想的不懈追求，同时也是对现实的持续挑战。在这样的爱情中，两个灵魂的纯粹连接仿佛超越了时间和空间的束缚，创造出一种非凡的和谐与理解。这种深层次的精神共鸣可能带来极大的心灵满足和精神上的提升。<STRONG><s>**</s>然而，它也可能让人忽略了人类作为生物本能的一部分——对于感官的需求和情感的直接表达。<e>**</e></STRONG></p>\n	\n<p>尽管如此，柏拉图式的爱情在某些方面提供了对传统爱情的有趣反思。它挑战了我们对爱情的常规理解，提醒我们审视内心的需求和欲望。<STRONG><s>**</s>在这种爱情观念中，最纯粹的爱被视为一种灵魂的结合，而非仅仅是身体的结合。<e>**</e></STRONG>《窄门》以其独特的方式展示了这种爱情的美丽与痛苦，让我对爱情的本质有了更深的思考和理解。</p>\n	\n<p>《窄门》的故事，就如同它的名字，是对生命最深层次的探索和挑战。它不仅是对爱情的一种深刻剖析，更是对人性、信仰和生命意义的深入思考。纪德通过这部作品，引领我们走进了一个复杂而深邃的心灵世界，让我们在思考爱情的真谛的同时，也审视自己的内心和生活。</p>\n	\n<p>在这个充满挑战和选择的世界里，《窄门》如一束灯塔之光，照亮了理想与现实、精神与肉体、牺牲与满足之间微妙而复杂的关系。它不仅是一部文学作品，更是一次心灵的旅程，一次对人类最深处情感和欲望的探索。《窄门》的故事和主题，就像它引用的《路加福音》中的话语一样，提醒着我们：生命中最真挚和深刻的东西，往往需要我们努力寻找，勇敢地穿越那些窄窄的门扉。</p>\n\n<HR>------</HR>\n\n<p>本文发表：</p>\n\n<p>知乎：<URL url=\"https://zhuanlan.zhihu.com/p/672741551\">https://zhuanlan.zhihu.com/p/672741551</URL></p>\n\n<p>Foresee Studio论坛:<URL url=\"https://www.foreseestudioblog.top/d/17\">https://www.foreseestudioblog.top/d/17</URL></p>\n\n<p>Github:<URL url=\"https://www.draper-crypto.top/2023/12/17/LaPorteetroite/\">https://www.draper-crypto.top/2023/12/17/LaPorteetroite/</URL></p></r>','2023-12-31 08:41:24',1,NULL,NULL,'127.0.0.1',0,1,0,0),(23,18,1,'2023-12-31 08:16:24',1,'comment','<r>\n<H1><s># </s>随笔03-2023届新生入学分享会</H1>\n\n<QUOTE><i>&gt; </i><p>由于文章是发表在公网上，部分内容已经修改校对，学校名、人名等已隐去。</p></QUOTE>\n\n<p>各位同学大家下午好：</p>\n\n<p>首先，我非常感谢你们的班主任可以给我这个机会，来他的班级与大家一起学习、交流和探讨。</p>\n\n<p>在开始今天的分享前，我斗胆猜测一下今天在座各位在听的时候可能会有这三类心态：第一类，不顾一屑型，认为我懂得比你多，你的观点我一句都不想听。第二类，虚心听取型，承认自己的能力有待提升，认为今天的分享会有一定收获。第三类，一切否认型，认为你说的都是错的，我认为的就一定是对的。</p>\n\n<p>产生这些心理当然都是正常的，没有真正意义上的对错，苏格拉底说过：“对于你懂的东西，你才会真正地认同。对于你不懂的东西，你不可能真正地认同。” 而什么是“懂的”东西呢？就是如康德所说的：“人类的原初设计”，也就是你的基于你的价值观所塑造的思想。</p>\n\n<p>2019年的今天，我和在座的各位一样对未知的校园生活充满恐惧、期待、懊悔等等心理。恐惧新的环境，期待新的生活，懊悔自己没有去到心仪的学校等等。说实话当时我的内心也是如此，这是我第一次离开家，来到新的群体与一群素未谋面的同学、室友相处。</p>\n\n<p>在入住到一个陌生的环境中，人的本性是警觉的，你的不安会让你放大别人的缺点，你可能看着你的上铺不洗澡感到难过，你可能闻到你旁边的下铺脚太臭太臭，总之你会觉得很多与自己不合的地方。而我们每个人都生活在偏见之中，我们有出身的偏见、种族的偏见、地域的偏见、性别的偏见，而我们需要做的是在各种偏见中寻找一种平衡之道，在各种对立的利益中寻找出一种合乎中道的恰如其分。</p>\n\n<p>我先自我介绍一下，我是20XX年的时候来到学校的，最早我是电子工程系应用电子技术专业的一名学生，第一年的我加入了电子创新实验室参加各类比赛，随后由于一些原因，我在2021年转入了信息工程系，在班一年后加入了软件技术工作室参加各类比赛。在校期间，我加入过社团、校学生会、自管会、校卫队、创新创业协会等等组织。所以我想来这里讲讲我自己的想法和一些观点。</p>\n\n<p>这些观点，是我自己4年实践经验总结出来，加上我拥有自己独立的创新创业工作室，带过三年创新创业团队，在此期间我有幸与各路领导、专家和风险投资人进行过研究和探讨。接下来我有几个观点供大家参考，可能不成熟，讲得不对，贻笑大方，但是大家姑且一听，觉得没道理，忘了就是。</p>\n\n\n\n<p><STRONG><s>**</s>第一个观点：形成良性的竞争关系，不要把时间浪费在无意义的小心思上。<e>**</e></STRONG></p>\n\n<p>你觉得你能力强、学习好那就展现出来给大家看，在我在校这么长时间我认为是金子总会发光这句话是错误的，金子是会发光，但深埋于地下没有人会去主动挖掘你，哪怕你是被一块破抹布盖住，只要没有人将这块抹布拿下，你都不会有发光的那一天。其次永远不要把心思放在研究这些小心思上，你的那些小心思只会浪费你自己的时间。举个简单的例子，你觉得你的班长能力不行，不要想着用什么小手段来把他搞下去，你应该去想我需要学习什么，掌握什么，通过哪些努力去达成这个目标，从而获得竞争班长的资格。</p>\n\n<p>举个例子，比如你现在想和你现在的班长进行竞争，你认为你的能力可以胜任班长这个职位，那你就去通过日常工作去体现你的能力，去获得竞选班长的资格，而不是我看这个班长不顺眼，找两个同学晚上去宿舍恐吓他，亦或是反抗班长正常管理工作，进而通过小心思把他“搞下去”。</p>\n\n<p>当然，这里不是让大家不要有小心思，古语有言：害人之心不可有，防人之心不可无。</p>\n\n<p><STRONG><s>**</s>第二个观点：学会向上社交，眼光要长远。<e>**</e></STRONG></p>\n\n<p>刚刚我们提到了抹布盖金子这个话题，在初入校园的时候，大家基本都是那个埋在地下的金子，但我们需要在各式各样的平台里展现自己，主动的去寻找这个揭开抹布的人，用我们通俗的讲法就是寻贵人。抓住每一个与贵人接触的机会，抓住每一个遇见贵人的机会。</p>\n\n<p>实践是检验真理的唯一标准，光说不做假把式。举个例子，我们在日常生活中去哪里寻找贵人？常见的方式有，如参加行业协会举办的活动、峰会、开放的各类大会，与各类领导产生交集，亦或是交流的机会。</p>\n\n<p>日常学习、生活过程中目光要长远，我常在我工作室内部强调三个观念，第一个是未来观，要有未来的眼光，想清楚自己有什么，要什么，放弃什么，第二个观念是全局观，如何顾全大局，当你有一个目标或者一个想法时，通过什么方式，需要学习什么去实现它。最后一个是全球观，你的眼观有多长远就能决定你做多大的事情，你的眼光看的是班级，那么就只能做一个班级的事情，眼光看的是一个市你就只能做一个市的事情，眼光看的是全球那就能做全球的事情。</p>\n\n<p>阿里巴巴的创始人马云先生，以其非凡的远见和坚韧的决心，为当代商业界树立了一座不朽的丰碑。他的那句名言“让天下没有难做的生意，为中小企业服务”，不仅勾画了一个商业的宏大愿景，而且揭示了他对于未来商业格局的深入洞察。</p>\n\n<p>马云先生明白，要想为中小企业服务，单单依赖传统的商业模式是远远不够的。这触发了他创建淘宝这样的电商平台，以满足消费者和商家的多样化需求，打破了地域和时间的限制，让买与卖变得前所未有地简单。但仅有电商平台还不够，交易的便捷性和安全性同样重要。因此，支付宝应运而生，使得数字支付成为了大众的日常选择。再后来，为了满足消费者更多元的金融需求，花呗等金融工具也相继问世，使得消费和融资都变得触手可及。</p>\n\n<p>初时，阿里巴巴的服务仅局限于小范围，但随着业务的壮大和完善，它逐渐向全省、全国乃至全球扩展。这都得益于马云先生的长远眼光。他并不满足于仅是在中国市场的成功，他的目标是建立一家全球化的公司，让更多人受益于这一创新商业模式。</p>\n\n<p>最终，阿里巴巴走向了世界，成为了国际商业的巨头。这一切都证明了一个道理：有远见的眼光，加之坚持不懈的努力，即使面对困难和挑战，也能创造出伟大的成就。</p>\n\n<p><STRONG><s>**</s>第三个观点：职校不是终点，而是新的起点。<e>**</e></STRONG></p>\n\n<p>职业学校，在许多人的传统观念中，进入职校可能意味着学术道路的某种“结束”。但实际上，职校为学生提供了另一条重要的职业和技能成长之路。是的，有些同学可能会觉得，来到职校就意味着可以放松对学习的要求，可以沉迷于各种娱乐活动，过上悠闲的日子。这种思维陷阱恰恰说明了他们没有真正理解职校的真正价值。</p>\n\n<p>当然，职校的环境确实更为宽松，没有过于严格的纪律要求，没有无休止的考试压力。但这并不意味着你可以对学习持有敷衍态度。因为在这里，更重要的是培养自主学习和自我管理的能力。如果你不珍惜在职校的时光，不去努力提高自己，那么，这段时间将会成为你人生中的一个遗憾。</p>\n\n<p><STRONG><s>**</s>第四个观点：保持阅读，养成看书的好习惯。<e>**</e></STRONG></p>\n\n<p>儿时的我，可能和你们许多人一样，认为看书是这个世界上最痛苦的事情。每当家长或老师提及“读书”，那种沉闷的感觉和逃避的心情总会油然而生。在我的记忆里，书是长篇累牍的文字堆砌，是无休止的任务和考试，是被迫接受的知识填充。</p>\n\n<p>然而，随着岁月的流逝，我的视角发生了变化。或许是因为生活中经历的多了，或是因为对世界的好奇心逐渐增长，我开始慢慢地认识到阅读的魅力和重要性。书籍不再是沉闷的教科书，而是一扇通向外部世界的窗口，一个了解人性、探索历史、体验文化和启迪思维的工具。我们因为无知而去阅读，而我们越阅读，我们越承认自己是无知的。就是苏格拉底所说的承认自己的无知乃是开启智慧的大门。这个世界不缺聪明的人，这个世界缺的是有智慧的人。</p>\n\n<p>那么我们应该阅读什么书呢？卡夫卡说：“一本书就像一把利斧劈开我们冰封的内心”。我们的阅读永远不要只读自己喜欢读的，我们要读挑战我们的书籍。如果一本书不能挑战我们，我们为什么要读它？我们如何走出自己的狭隘和偏见？</p>\n\n<p><STRONG><s>**</s>第五个观点：遵纪守法，做法治之光<e>**</e></STRONG></p>\n\n<p>在日常生活中，我们常常听到“遵纪守法”的叮嘱，这四个字似乎已经成为了一个口号，被反复强调而逐渐失去了它的真实含义。但其实，它代表的不仅仅是一种行为准则，更是一种对于社会责任和公共道德的坚守。</p>\n\n<p>法律是维护社会正义和公平的基石，是调解社会矛盾、维护社会秩序的重要手段。任何人都应当对法律产生天生的敬畏。这并不仅仅是因为它是法定的要求，更重要的是，每一次遵守法律，都是对社会秩序和公共利益的维护，都是对自己和他人权益的尊重。遵纪守法并不意味着生活在严格的规条之中，无法自由呼吸。相反，真正的法治意味着每个人都在法律的庇护下享有公平和自由。当我们都能自觉地遵循这一准则，社会才能够更加和谐、秩序井然。</p>\n\n<p>作为年轻一代，我们更应该树立起遵纪守法的典范，成为法治的推动者和守护者。因为只有当每一个个体都尊重并维护法律时，整个社会才能够真正走向文明与进步。</p>\n\n<p>罗翔老师曾说：“我一直觉得，自己所得的一切皆非所配，很多的荣光不过是草船借箭，众人将不该有的荣誉投射于你。一个朋友说，一瓶饮料，便利店里卖3块钱，大饭店卖30块钱，一个人的价值取决于他所在的位置。但在我看来，一个人真正的价值在于即便他处于高位，成为了30块钱的水，而他也有自知之明，能够知道自己本来就是便利店那3块钱的水，甚至成本连3块钱都到不了。”任何人所拥有的一切，与浩瀚无际的宇宙相比，可谓沧海一粟，微不足道。从历史长河看，不管我们拥有什么，拥有多少，拥有多久，都不过是拥有极其微小的瞬间。</p>\n\n<p>生活的真谛并非在于我们追求多少成就，拥有多少物质，而在于我们如何去体验、去感悟这一过程。在这条道路上，每一个观点、每一次选择，都是我们对世界的认知和对自己的定义。登高不傲，居低不怨，保持谦卑，追寻智慧，在使命中寻找意义，对抗虚无与虚荣。</p></r>','2023-12-31 08:18:10',1,NULL,NULL,'127.0.0.1',0,1,0,0),(24,19,1,'2023-12-31 08:43:46',1,'comment','<r><H2><s>## </s>BBCode</H2>\n\n<HR>----</HR>\n\n<LIST type=\"decimal\"><LI><s>1. </s><p>加粗：<C><s>`</s>[b]加粗[/b]<e>`</e></C></p></LI>\n\n<LI><s>2.  </s><p>斜体：<C><s>`</s>[i]加粗[/i]<e>`</e></C></p></LI>\n\n<LI><s>3.  </s><p>下划线：<C><s>`</s>[u]下划线[/u]<e>`</e></C></p></LI>\n\n<LI><s>4.  </s><p>删除线：<C><s>`</s>[s]删除线[/s]<e>`</e></C></p></LI>\n\n<LI><s>5. </s><p>超链接：<C><s>`</s>[url=https://bbs.csur.fun]超链接[/url]<e>`</e></C></p></LI>\n\n<LI><s>6.  </s><p>居中对齐（可与其他code结合，如img：<C><s>`</s>[center]居中对齐[/center]<e>`</e></C></p></LI>\n \n<LI><s>7.  </s><p>文字大小20px：<C><s>`</s>[size=20]文字大小20px[/size]<e>`</e></C></p></LI>\n\n<LI><s>8.  </s><p>可调节显示大小的图片：<C><s>`</s>[img width=100]https://i.loli.net/2019/12/20/aiDuP8brdqZSL6M.png[/img]<e>`</e></C></p></LI>\n\n<LI><s>9.  </s><p>全尺寸语法高亮代码框：<C><s>`</s>[code lang=javascript]&lt;&lt;script async=\"\" src=\"//busuanzi.ibruce.info/busuanzi/2.3/busuanzi.pure.mini.js\"&gt;&lt;/script&gt;&gt;[/code]<e>`</e></C></p></LI></LIST>\n\n<p><DEL><s>~~</s>10.  音频：<e>~~</e></DEL></p>\n    <br/>\n<LIST start=\"11\" type=\"decimal\"><LI><s>11.  </s><p>视频直链：<C><s>`</s>[https://awk.tw/video/opera\\_new.mp4](https://awk.tw/video/opera_new.mp4)]<e>`</e></C></p></LI>\n    \n<LI><s>12.  </s><p>更多基本核心 BBCodes：</p>\n<CODE lang=\"text\"><s>```text</s><i>\n</i>[b], [i], [u], [s], [url], [img], [email], [code], [quote], [list], [del], [color], [center], [size], [*]\n```   \n\n## BBBBCode\n--------------------------------------------------------------------------------------\n\n* * *\n\n#### 1\\. 提示\n\n    [tooltip=\"像这样！\" placement=\"right\"]提示[/tooltip]\n\n效果→ 提示\n\n（对于其中的“placement”您可以使用 “up”“down”“left”“right”来改变提示框出现的相对位置）\n\n#### 2\\. 折叠内容\n\n    [spoiler=\"你发现了这个秘密咯！\"]点击此处查看惊喜[/spoiler]\n\n（如果您省略了“spoiler=”部分，将显示默认标题“展示更多”）\n\n#### 3\\. 高斯模糊嘿嘿内容\n\n    [blur]这里是我不想让你看的嘿咻内容。[/blur]\n\n（鼠标移动到云团上以显示内容，鼠标移开还原。）\n\n这里是我不想让你看的嘿咻内容。\n\n#### 4\\. 黑幕（Steam 风格）\n\n    [steam_spoiler]类Steam风格黑幕[/steam_spoiler]\n\n类Steam风格黑幕\n\n![GIF.gif](https://i.loli.net/2020/01/07/OA8G5ZXwMfhvpS3.gif)\n\n#### 5\\. 手风琴\n\n    [accordion header=\"第一步\"]这里写第一步内容[/accordion]\n    [accordion header=\"第二部\"]这里写第二部内容[/accordion]\n\n这里写第一步内容 这里写第二部内容\n\n#### 6\\. 聊天对话框\n\n    [chat-a=\"明天期末考试\" who=\"小明\"]\n    [chat-b=\"我知道\" who=\"我\"]\n    [chat-a=\"一看你就没复习！\" who=\"小明\"]\n    [space][/space]  ← 用于换行\n    <br/>\n\n\\[chat-a=\"明天期末考试\" who=\"小明\"\\] \\[chat-b=\"我知道\" who=\"我\"\\] \\[chat-a=\"一看你就没复习！\" who=\"小明\"\\]\n\n#### 7\\. 动态标记\n\n    [action]要放寒假了[/action]\n\n要放寒假了\n\n#### 8\\. 弹窗\n\n    [pop button=\"紧急通知\" title=\"阿伟死了\" content=\"阿伟已经死了很多次了。\"]\n\n\\[pop button=\"紧急通知\" title=\"阿伟死了\" content=\"阿伟已经死了很多次了。\"\\]\n\n#### 9\\. 字体颜色\n\n    [red]红字[/red] ... 其他支持的颜色： [orange], [yellow], [green], [blue], [purple]\n\n红字\n\n    [color=aquamarine]青色[/color] ... [color=颜色名称] 或十六进制颜色代码 [color=#FFFFF]\n\n青色\n\n#### 10\\. 荧光笔\n\n    [hl]神笔马良天下无敌[/hl] ... 注意是 hl，小写字母L，不是数字 h1\n\n神笔马良天下无敌\n\n#### 11\\. HTML 键盘标记\n\n    请敲击 [kbd]SHIFT[/kbd] 键以升天。\n\n请敲击 SHIFT 键以升天。\n\n#### 12\\. 音频\n\n    支持mp3.ogg,m4a,wav,flac 等格式\n    [audio mp3=\"song.mp3\" ogg=\"song.ogg\"]\n    [audio mp3=\"song.mp3\"]\n    [audio ogg=\"song.ogg\"]\n    [audio m4a=\"song.m4a\"]\n    [audio wav=\"song.wav\"]\n    [audio flac=\"song.flac\"]\n    [audio webm=\"song.webm\"]\n    [audio mp3=\"song.mp3\" width=\"50\"]\n    <br/>\n\n\\[audio mp3=\"https://bbs.csur.fun/assets/files/2020-01-07/黑暗骑士.mp3\"\\]\n\n#### 13\\. 背景色\n\n    [background=red]红色背景[/background]\n\n红色背景\n\n#### 14\\. 表格\n\n    [table]\n      [thead]\n        [tr]\n          [th]版本号[/th] [th]更新日期[/th] [th]变化[/th] [th]备注[/th]\n        [/tr]\n      [/thead]\n      [tbody]\n        [tr]\n          [td rowspan=2]0.2.2[/td] [td rowspan=2]2020-1-5[/td] [td align=center]Added[/td]\n        [/tr]\n        [tr]\n          [td colspan=2] [list]捐赠页面全新上线，[url=https://csur.fun/donate/ title=捐赠页面]请我们喝杯[url] ?[/list] [/td]\n        [/tr]\n      [/tbody]\n    [/table]\n    <br/>\n    效果 ↓\n    <br/>\n\n版本号 更新日期 变化 备注 0.2.2 2020-1-5 Added\n\n*   捐赠页面全新上线，[请我们喝杯![☕](https://cdn.jsdelivr.net/gh/twitter/twemoji@14/assets/72x72/2615.png)\\[url\\] ?](https://csur.fun/donate/ \"捐赠页面\")\n    <br/>\n\n#### 15\\. 字体\n\n    [font=Serif]字体：Serif 123abcABC[/font]\n\n字体：Serif 123abcABC  <br/>\n字体：Roboto 123abcABC\n\n#### 16\\. 提醒和通知\n\n**基本通知提醒：**\n\n    [AWARNING] 这是一个 警告测试 [/AWARNING]\n\n这是一个 警告测试\n\n    [ASUCCESS] 所有警报已解除！ [/ASUCCESS]\n\n所有警报已解除！\n\n    [AINFO] 有时您只想提供一般信息，让伙计们知道一切安好，无须担心。 [/AINFO]\n\n有时您只想提供一般信息，让伙计们知道一切安好，无须担心。\n\n    [ABASIC] 最基础的警告框，毫无特色。 [/ABASIC]\n\n最基础的警告框，毫无特色。\n\n    [ACUSTOM]red,white,black,自定义警告框[/ACUSTOM]\n\nred,white,black,自定义警告框\n\n**多彩风格、自定义多彩风格的通知**\n\n    [berror] 这是一个错误警告，您哪都做错了。 [/berror]\n\n这是一个错误警告，您哪都做错了。\n\n    [cerror]#555,#ffecec,#f5aca6,错误,自定义警告框。[/cerror]\n\n#555,#ffecec,#f5aca6,错误,自定义警告框。\n\n    [bsuccess] 所有错误已被解决 [/bsuccess]\n\n所有错误已被解决\n\n    [csuccess]#555,#e9ffd9,#a6ca8a,成功,恭喜你脱单啦！[/csuccess]\n\n#555,#e9ffd9,#a6ca8a,成功,恭喜你脱单啦！\n\n    [bwarning] 你要再继续的话，可以戳瞎自己的眼睛了。 [/bwarning]\n\n你要再继续的话，可以戳瞎自己的眼睛了。\n\n    [cwarning]#555,#fff8c4,#f2c779,亚麻嘚,感觉我不会再快乐了，快乐跟我也没关系了，喝一点牛奶 milk。[/cwarning]\n\n#555,#fff8c4,#f2c779,亚麻嘚,感觉我不会再快乐了，快乐跟我也没关系了，喝一点牛奶 milk。\n\n    [bnotice] 不要接受陌生蜀黍的抱抱。 [/bnotice]\n\n不要接受陌生蜀黍的抱抱。\n\n    [cnotice]#555,#e3f7fc,#8ed9f6,注意,我要变形了！[/cnotice]\n\n#555,#e3f7fc,#8ed9f6,注意,我要变形了！\n\n**其他BBCode格式： - 感谢JoshyPHP的帮助和专业知识。**\n\n    [BCUSTOM]title=测试测试 font=SlateBlue gb=WHITE border=SlateBlue[/BCUSTOM]\n\n\\[BCUSTOM\\]title=测试测试 font=SlateBlue gb=WHITE border=SlateBlue\\[/BCUSTOM\\]\n\n    [derror title=警告 错误 font=red bg=white border=red] 测试测试 [/derror]\n\n测试测试\n\n    [dsuccess title=警告 成功 font=green bg=white border=green] 测试测试 [/dsuccess]\n\n测试测试\n\n    [dwarning title=警告 危险 font=darkorange bg=white border=darkorange] 测试测试 [/dwarning]\n\n测试测试\n\n    [dnotice title=警告 注意 font=teal bg=white border=teal] 测试测试 [/dnotice]\n\n测试测试\n\n#### 17\\. 选项卡\n\n**① 选项卡页**\n\n    [tabs]\n        [tab=\"你好\" active=\"ANYTHING\"] 我不好，你才好。 [/tab]\n        [tab=\"我不好\"] 我很好，你才不好。 [/tab]\n    [/tabs]\n    <br/>\n\n我不好，你才好。\n\n我很好，你才不好。\n\n**②单选控件**\n\n    问：爱我吗？\n    [tab=\" 爱\" active=\"[ANYTHING]\"]你的钱[/tab]\n    [tab name=\" 不爱\"] 请你吃八爷 [/tab]\n    <br/>\n\n问：爱我吗？\n\n你的钱\n\n请你吃八爷\n\n#### 18\\. FontAwesome 字体\n\n**字重**\n\n*   `[fas]` : solid\n*   `[far]` : regular\n*   `[fal]`: light\n*   `[fab]`: brand\n\n    I like [fa]train[/fa] !\n    <br/>\n\nI like train !\n\n#### 19\\. Comic Sans\n\n`[COMIC]Hello world[/COMIC]`  <br/>\nHello world</CODE></LI></LIST></r>','2023-12-31 08:52:13',1,NULL,NULL,'127.0.0.1',0,1,0,0);
/*!40000 ALTER TABLE `posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `push_subscriptions`
--

DROP TABLE IF EXISTS `push_subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `push_subscriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `vapid_public_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `keys` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `last_used` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `push_subscriptions_user_id_foreign` (`user_id`),
  CONSTRAINT `push_subscriptions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `push_subscriptions`
--

LOCK TABLES `push_subscriptions` WRITE;
/*!40000 ALTER TABLE `push_subscriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `push_subscriptions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `registration_tokens`
--

DROP TABLE IF EXISTS `registration_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `registration_tokens` (
  `token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_attributes` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `registration_tokens`
--

LOCK TABLES `registration_tokens` WRITE;
/*!40000 ALTER TABLE `registration_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `registration_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES ('allow_hide_own_posts','reply'),('allow_post_editing','reply'),('allow_renaming','10'),('allow_sign_up','1'),('askvortsov-checklist.cross_out_completed_items','1'),('custom_footer','<footer>\n    <div class=\"site-footer\" style=\"text-align: center; line-height: 1;\">\n        <div style=\"color: rgb(137, 137, 140); font-size:0.9em;\" class=\"footer-container rm-link-color\">\n            <p>\n                <span id=\"copyright_span\">Foresee Studio论坛&nbsp;&copy;&nbsp;2023-2024</span>\n            </p> \n            <p>\n                <a id=\"prot_span\">社区规范</a>\n                <span class=\"mx-2\">|</span>\n                <a id=\"rept_span\" href=\"mailto:jlstudioemail@163.com\">违法和不良信息举报</a>\n                <span class=\"mx-2\">|</span>\n                <a id=\"stats\" href=\"https://stats.uptimerobot.com/QAL8xc6m8y\" target=\"_blank\">状态</a>\n            </p>\n            <p>\n                <span id=\"team_span\">Powered by&nbsp;<a href=\"https://foreseestudio.top/\">Foresee Studio Project Team</a></span>\n            </p>\n        </div>\n    </div>\n</footer>'),('custom_header','<script async src=\"/assets/fireworks.js\"></script>'),('custom_less','/* 首页顶部条 */\n.IndexPage-toolbar::after {\n  content: \"唯愿公平如大水滚滚 | 使公义如江河滔滔\";\n  padding: 10px;\n  color: #ffffff;\n  border-radius: 50px;\n  text-align: center;\n  font-size: 16px;\n  background: linear-gradient(135deg, #29c7ac, #6699ff);\n  display: block;\n  margin: 5px 0;\n}\n\n/* 在手机屏幕上隐藏顶部彩色条 */\n@media (max-width: 768px) {\n  .IndexPage-toolbar::after {\n    display: none;\n  }\n}\n\n/* 表格美化 */\ntable {\n  table-layout: fixed;\n  padding: 0;\n  word-break: break-all;\n  border-collapse: collapse;\n  margin: 0.8em 0;\n  width: 100%;\n}\n\ntable tr {\n  border: 1px solid #dfe2e5;\n  margin: 0;\n  padding: 0;\n}\n\ntable tr:nth-child(2n),\nthead {\n  background-color: #f8f8f8;\n}\n\ntable th {\n  font-weight: bold;\n  border: 1px solid #dfe2e5;\n  border-bottom: 0;\n  margin: 0;\n  padding: 6px 13px;\n  width: auto ! important;\n}\n\ntable td {\n  border: 1px solid #dfe2e5;\n  margin: 0;\n  padding: 6px 13px;\n}\n\ntable th:first-child,\ntable td:first-child {\n  margin-top: 0;\n}\n\ntable th:last-child,\ntable td:last-child {\n  margin-bottom: 0;\n}\n\n/* 字体美化 */\nbody {\n  font-family: \"SF Pro SC\", \"SF Pro Text\", \"SF Pro Icons\", \"PingFang SC\", \"Helvetica Neue\", \"Helvetica\", \"Arial\", sans-serif;\n}\n\nh1,\nh2,\nh3,\nh4,\n.TagsLabel,\n.Button,\n.DiscussionListItem-count,\n.item-discussion-views {\n  font-family: \"SF Pro SC\", \"SF Pro Text\", \"SF Pro Icons\", \"PingFang SC\", \"Helvetica Neue\", \"Helvetica\", \"Arial\", sans-serif;\n}\n\n\n/* 取消欢迎关闭按钮 */\n.Hero-close {\n  display: none;\n}\n\n/* navigation */\n/* Update the value of max-width according to the width of Header-primary and Header-secondary */\n/* 根据 Header-primary 和 Header-secondary 的宽度，修改 max-width 的大小。header 里东西很多时，max-width 改成更大一些 */\n@media (min-width: 768px) and (max-width: 1099px) {\n  .Header-primary .Header-controls {\n    max-width: 200px;\n    white-space: nowrap;\n    overflow: hidden;\n    text-overflow: ellipsis;\n  }\n\n  .Header-primary:after {\n    content: \" > \";\n    margin-left: 20px;\n  }\n\n  .Header-primary:hover {\n    padding-right: 30px;\n    padding-bottom: 20px;\n  }\n\n  .Header-primary:hover .Header-controls {\n    transition: max-width 1s;\n    max-width: 1000px;\n    overflow: unset;\n    animation: delay-overflow-unset 1s;\n  }\n\n  @keyframes delay-overflow-unset {\n    from {\n      overflow: hidden;\n    }\n\n    to {\n      overflow: unset;\n    }\n  }\n\n  .Header-primary:hover:after {\n    content: \"\";\n  }\n\n  .Header-primary:hover+.Header-secondary {\n    white-space: nowrap;\n    overflow: hidden;\n    margin-right: 20px;\n    float: unset;\n  }\n}\n\n.Header-secondary .item-session button {\n  max-width: 140px;\n  overflow: hidden;\n  text-overflow: ellipsis;\n}'),('default_locale','zh-Hans'),('default_route','/all'),('display_name_driver','nickname'),('extensions_enabled','[\"flarum-flags\",\"flarum-tags\",\"flarum-approval\",\"flarum-suspend\",\"flarum-mentions\",\"flarum-subscriptions\",\"flarum-lock\",\"flarum-sticky\",\"ianm-level-ranks\",\"fof-user-directory\",\"fof-follow-tags\",\"v17development-blog\",\"flarum-markdown\",\"zequeen-acgembed-remastered\",\"yohtozze-markdown-paste\",\"v17development-seo\",\"tohsakarat-table-of-content\",\"the-turk-stickiest\",\"the-turk-mathren\",\"the-turk-flamoji\",\"sycho-profile-cover\",\"ramesh-dada-download-button\",\"pipecraft-id-slug\",\"nearata-tags-color-generator\",\"nearata-signup-confirm-password\",\"nearata-cakeday\",\"justoverclock-thread-read-time\",\"justoverclock-christmas-snow-effect\",\"imeepo-more-bbcode\",\"ianm-synopsis\",\"ianm-log-viewer\",\"fof-user-bio\",\"fof-terms\",\"fof-subscribed\",\"fof-socialprofile\",\"fof-sitemap\",\"fof-share-social\",\"fof-profile-image-crop\",\"fof-pretty-mail\",\"fof-nightmode\",\"fof-moderator-notes\",\"fof-links\",\"fof-linguist\",\"fof-github-autolink\",\"fof-frontpage\",\"fof-filter\",\"fof-drafts\",\"fof-doorman\",\"fof-cookie-consent\",\"fof-best-answer\",\"flarumtr-mobile-search\",\"flarum-statistics\",\"flarum-nicknames\",\"flarum-likes\",\"flarum-lang-russian\",\"flarum-lang-english\",\"flarum-lang-chinese-simplified\",\"flarum-emoji\",\"flarum-bbcode\",\"ffans-clipboardjs\",\"extiverse-mercury\",\"darkle-fancybox\",\"dalez-fluent-flarum\",\"clarkwinkelmann-first-post-approval\",\"clarkwinkelmann-discussion-bookmarks\",\"clarkwinkelmann-circle-groups\",\"clarkwinkelmann-author-change\",\"becod-backtotop\",\"askvortsov-markdown-tables\",\"askvortsov-checklist\",\"askvortsov-article-series\",\"acpl-mobile-tab\"]'),('extiverse-mercury.token','eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiZjVmMTk1OTc0NjRkMTk4MmI2YjI5ODAzYzViMDZkMjFjMTMwYTJhYzRlNTEwMmIwNzYyMTQxMTg4YjY5OGQ0NjY2YWRiMmNkYzQyZWJlMWUiLCJpYXQiOjE3MDM3MzAzODcuOTEwOTEyLCJuYmYiOjE3MDM3MzAzODcuOTEwOTE0LCJleHAiOjE3MzUzNTI3ODcuOTA0Nzc1LCJzdWIiOiIzMTExIiwic2NvcGVzIjpbImFwaTpyZWFkIl19.Pl6xBQnXXjnuaC8BcBdW37ZWjGBSsi7HZmPSSzzK92cD9W_bcGGYfGc2vfI3mC6uF_C4OYvNiCLMiozAywqeCu4gvsxY7rnZ6Jfc9JJSqte0aZIuGyW4xBEDI4Cb3d-eBWBxYduogkhrim4qWEP3chxdsPpb0nComvnemBaKRQEWcDRsbKQL6qWwjdZNlLilyvB_j_rfx03Y-rEExuLb-vTQTyUN09BlejXkODZToo-r0KcSUsG3A3qSWQqCptgEkFMsaE8dPNxPX7ESfSiPU8qhOKPaqlZxiP9ZtM7F1-DTtbuufREZm3kQ7jVtn1HS3JVki6demwnR7-V4slCnHEq_9m2HNyBkYK_5BxhASiCa3dENN12CWcQBkmgxK0n_F6wTtQ6bJ8373D--n-s1_Yv3uiZLrEKppyhO4GW_w9TPyS-mx71JE673M8yW5yWyywmEIJUc-0gjcqoMdcVGyjfjj-0xxpCkxilwiU-fy_Ku2kZOIpvyeoViovIM3k7IonTYOxIxbbzVAczsquyBGCATs0oe4yRngvFBFS7HqNUsCv6GciH9Hfd4yFUgUutHrJXvVoZF9HoeN3u2NQmLlrS1J0lXZUFzAUi4HWZfdfX7sQAb7zhb5UsXVjd8uFiHdAdyseJOVQ2ic_CMO8qIx_o09u3wYOq5iu8g7CJPQy8'),('extiverse-mercury.updates-required','4'),('favicon_path','favicon-ojrqx2wm.png'),('ffans-clipboardjs.is_copy_enable','1'),('ffans-clipboardjs.is_show_codeLang','1'),('ffans-clipboardjs.theme_name','github'),('flarum-markdown.mdarea','1'),('flarum-mentions.allow_username_format','1'),('flarum-tags.max_primary_tags','3'),('flarum-tags.max_secondary_tags','3'),('flarum-tags.min_primary_tags','1'),('flarum-tags.min_secondary_tags','0'),('fof-best-answer.enabled-tags','[]'),('fof-best-answer.remind-tags','[]'),('fof-best-answer.show_filter_dropdown','1'),('fof-cookie-consent.backgroundColor','#2b2b2b'),('fof-cookie-consent.buttonBackgroundColor','#178e99'),('fof-cookie-consent.buttonText','I Accept'),('fof-cookie-consent.buttonTextColor','#ffffff'),('fof-cookie-consent.ccTheme','edgeless'),('fof-cookie-consent.consentText','This website uses cookies to improve browsing experience and forum functionality, and to analyze website traffic. For details, please see our privacy policy. You can accept cookies or customize them in settings.'),('fof-cookie-consent.learnMoreLinkText','Learn More'),('fof-cookie-consent.learnMoreLinkUrl','https://www.foreseestudioblog.top/d/2'),('fof-cookie-consent.textColor','#ffffff'),('fof-doorman.allowPublic','1'),('fof-filter.autoDeletePosts',''),('fof-filter.autoMergePosts',''),('fof-filter.censors','[\"\\/\\u963f\\u6241\\u63a8\\u7ffb\\/i\",\"\\/\\u963f\\u5bbe\\/i\",\"\\/\\u963f\\u8cd3\\/i\",\"\\/\\u6328\\u4e86\\u4e00\\u70ae\\/i\",\"\\/\\u7231\\u6db2\\u6a2a\\u6d41\\/i\",\"\\/\\u5b89\\u8857\\u9006\\/i\",\"\\/\\u5b89\\u5c40\\u529e\\u516c\\u697c\\/i\",\"\\/\\u5b89\\u5c40\\u8c6a\\u534e\\/i\",\"\\/\\u5b89\\u95e8\\u4e8b\\/i\",\"\\/\\u5b89\\u7720\\u85e5\\/i\",\"\\/\\u6848\\u7684\\u51c6\\u786e\\/i\",\"\\/\\u516b\\u4e5d\\u6c11\\/i\",\"\\/\\u516b\\u4e5d\\u5b66\\/i\",\"\\/\\u516b\\u4e5d\\u653f\\u6cbb\\/i\",\"\\/\\u628a\\u75c5\\u4eba\\u6574\\/i\",\"\\/\\u628a\\u9093\\u5c0f\\u5e73\\/i\",\"\\/\\u628a\\u5b66\\u751f\\u6574\\/i\",\"\\/\\u7f62\\u5de5\\u95e8\\/i\",\"\\/\\u767d\\u9ec4\\u7259\\u7b7e\\/i\",\"\\/\\u8d25\\u57f9\\u8bad\\/i\",\"\\/\\u529e\\u672c\\u79d1\\/i\",\"\\/\\u529e\\u7406\\u672c\\u79d1\\/i\",\"\\/\\u529e\\u7406\\u5404\\u79cd\\/i\",\"\\/\\u529e\\u7406\\u7968\\u636e\\/i\",\"\\/\\u529e\\u7406\\u6587\\u51ed\\/i\",\"\\/\\u529e\\u7406\\u771f\\u5b9e\\/i\",\"\\/\\u529e\\u7406\\u8bc1\\u4e66\\/i\",\"\\/\\u529e\\u7406\\u8d44\\u683c\\/i\",\"\\/\\u529e\\u6587\\u51ed\\/i\",\"\\/\\u529e\\u6014\\/i\",\"\\/\\u529e\\u8bc1\\/i\",\"\\/\\u534a\\u523a\\u5200\\/i\",\"\\/\\u8fa6\\u6bd5\\u4e1a\\/i\",\"\\/\\u8fa6\\u8b49\\/i\",\"\\/\\u8c24\\u7f6a\\u83b7\\u5211\\/i\",\"\\/\\u78c5\\u89e3\\u7801\\u5668\\/i\",\"\\/\\u78c5\\u9065\\u63a7\\u5668\\/i\",\"\\/\\u5b9d\\u5728\\u7518\\u8083\\u4fee\\/i\",\"\\/\\u4fdd\\u8fc7\\u7b54\\u6848\\/i\",\"\\/\\u62a5\\u590d\\u6267\\u6cd5\\/i\",\"\\/\\u7206\\u53d1\\u9a9a\\/i\",\"\\/\\u5317\\u7701\\u59d4\\u95e8\\/i\",\"\\/\\u88ab\\u6253\\u6b7b\\/i\",\"\\/\\u88ab\\u6307\\u6284\\u88ad\\/i\",\"\\/\\u88ab\\u4e2d\\u5171\\/i\",\"\\/\\u672c\\u516c\\u53f8\\u62c5\\/i\",\"\\/\\u672c\\u65e0\\u7801\\/i\",\"\\/\\u6bd5\\u4e1a\\u8b49\\/i\",\"\\/\\u53d8\\u724c\\u7edd\\/i\",\"\\/\\u8fa9\\u8bcd\\u4e0e\\u68a6\\/i\",\"\\/\\u51b0\\u6bd2\\/i\",\"\\/\\u51b0\\u706b\\u6bd2\\/i\",\"\\/\\u51b0\\u706b\\u4f73\\/i\",\"\\/\\u51b0\\u706b\\u4e5d\\u91cd\\/i\",\"\\/\\u51b0\\u706b\\u6f2b\\/i\",\"\\/\\u51b0\\u6deb\\u4f20\\/i\",\"\\/\\u51b0\\u5728\\u706b\\u4e0a\\/i\",\"\\/\\u6ce2\\u63a8\\u9f99\\/i\",\"\\/\\u535a\\u5f69\\u5a31\\/i\",\"\\/\\u535a\\u4f1a\\u6682\\u505c\\/i\",\"\\/\\u535a\\u56ed\\u533a\\u4f2a\\/i\",\"\\/\\u4e0d\\u67e5\\u90fd\\/i\",\"\\/\\u4e0d\\u67e5\\u5168\\/i\",\"\\/\\u4e0d\\u601d\\u56db\\u5316\\/i\",\"\\/\\u5e03\\u5356\\u6deb\\u5973\\/i\",\"\\/\\u90e8\\u5fd9\\u7ec4\\u9601\\/i\",\"\\/\\u90e8\\u662f\\u8fd9\\u6837\\/i\",\"\\/\\u624d\\u77e5\\u9053\\u53ea\\u751f\\/i\",\"\\/\\u8d22\\u4f17\\u79d1\\u6280\\/i\",\"\\/\\u91c7\\u82b1\\u5802\\/i\",\"\\/\\u8e29\\u8e0f\\u4e8b\\/i\",\"\\/\\u82cd\\u5c71\\u5170\\/i\",\"\\/\\u82cd\\u8747\\u6c34\\/i\",\"\\/\\u85cf\\u6625\\u9601\\/i\",\"\\/\\u85cf\\u7368\\/i\",\"\\/\\u64cd\\u4e86\\u5ac2\\/i\",\"\\/\\u64cd\\u5ac2\\u5b50\\/i\",\"\\/\\u7b56\\u6ca1\\u6709\\u4e0d\\/i\",\"\\/\\u63d2\\u5c41\\u5c41\\/i\",\"\\/\\u5bdf\\u8c61\\u8682\\/i\",\"\\/\\u62c6\\u8fc1\\u706d\\/i\",\"\\/\\u8f66\\u724c\\u9690\\/i\",\"\\/\\u6210\\u4eba\\u7535\\/i\",\"\\/\\u6210\\u4eba\\u5361\\u901a\\/i\",\"\\/\\u6210\\u4eba\\u804a\\/i\",\"\\/\\u6210\\u4eba\\u7247\\/i\",\"\\/\\u6210\\u4eba\\u89c6\\/i\",\"\\/\\u6210\\u4eba\\u56fe\\/i\",\"\\/\\u6210\\u4eba\\u6587\\/i\",\"\\/\\u6210\\u4eba\\u5c0f\\/i\",\"\\/\\u57ce\\u7ba1\\u706d\\/i\",\"\\/\\u60e9\\u516c\\u5b89\\/i\",\"\\/\\u60e9\\u8d2a\\u96be\\/i\",\"\\/\\u5145\\u6c14\\u5a03\\/i\",\"\\/\\u51b2\\u51c9\\u6b7b\\/i\",\"\\/\\u62bd\\u7740\\u5927\\u4e2d\\/i\",\"\\/\\u62bd\\u7740\\u8299\\u84c9\\/i\",\"\\/\\u51fa\\u6210\\u7ee9\\u4ed8\\/i\",\"\\/\\u51fa\\u552e\\u53d1\\u7968\\/i\",\"\\/\\u51fa\\u552e\\u519b\\/i\",\"\\/\\u7a7f\\u900f\\u4eea\\u5668\\/i\",\"\\/\\u6625\\u6c34\\u6a2a\\u6ea2\\/i\",\"\\/\\u7eaf\\u5ea6\\u767d\\/i\",\"\\/\\u7eaf\\u5ea6\\u9ec4\\/i\",\"\\/\\u6b21\\u901a\\u8fc7\\u8003\\/i\",\"\\/\\u50ac\\u7720\\u6c34\\/i\",\"\\/\\u50ac\\u60c5\\u7c89\\/i\",\"\\/\\u50ac\\u60c5\\u836f\\/i\",\"\\/\\u50ac\\u60c5\\u85e5\\/i\",\"\\/\\u632b\\u4ed1\\/i\",\"\\/\\u8fbe\\u6bd5\\u4e1a\\u8bc1\\/i\",\"\\/\\u7b54\\u6848\\u5305\\/i\",\"\\/\\u7b54\\u6848\\u63d0\\u4f9b\\/i\",\"\\/\\u6253\\u6807\\u8bed\\/i\",\"\\/\\u6253\\u9519\\u95e8\\/i\",\"\\/\\u6253\\u98de\\u673a\\u4e13\\/i\",\"\\/\\u6253\\u6b7b\\u7ecf\\u8fc7\\/i\",\"\\/\\u6253\\u6b7b\\u4eba\\/i\",\"\\/\\u6253\\u7838\\u529e\\u516c\\/i\",\"\\/\\u5927\\u9e21\\u5df4\\/i\",\"\\/\\u5927\\u96de\\u5df4\\/i\",\"\\/\\u5927\\u7eaa\\u5143\\/i\",\"\\/\\u5927\\u63ed\\u9732\\/i\",\"\\/\\u5927\\u5976\\u5b50\\/i\",\"\\/\\u5927\\u6279\\u8d2a\\u5b98\\/i\",\"\\/\\u5927\\u8089\\u68d2\\/i\",\"\\/\\u5927\\u5634\\u6b4c\\/i\",\"\\/\\u4ee3\\u529e\\u53d1\\u7968\\/i\",\"\\/\\u4ee3\\u529e\\u5404\\/i\",\"\\/\\u4ee3\\u529e\\u6587\\/i\",\"\\/\\u4ee3\\u529e\\u5b66\\/i\",\"\\/\\u4ee3\\u529e\\u5236\\/i\",\"\\/\\u4ee3\\u8fa6\\/i\",\"\\/\\u4ee3\\u8868\\u70e6\\/i\",\"\\/\\u4ee3\\u958b\\/i\",\"\\/\\u4ee3\\u8003\\/i\",\"\\/\\u4ee3\\u7406\\u53d1\\u7968\\/i\",\"\\/\\u4ee3\\u7406\\u7968\\u636e\\/i\",\"\\/\\u4ee3\\u60a8\\u8003\\/i\",\"\\/\\u4ee3\\u60a8\\u8003\\/i\",\"\\/\\u4ee3\\u5199\\u6bd5\\/i\",\"\\/\\u4ee3\\u5199\\u8bba\\/i\",\"\\/\\u4ee3\\u5b55\\/i\",\"\\/\\u8d37\\u529e\\/i\",\"\\/\\u8d37\\u501f\\u6b3e\\/i\",\"\\/\\u8d37\\u5f00\\/i\",\"\\/\\u6234\\u6d77\\u9759\\/i\",\"\\/\\u5f53\\u4ee3\\u4e03\\u6574\\/i\",\"\\/\\u5f53\\u5b98\\u8981\\u7cbe\\/i\",\"\\/\\u5f53\\u5b98\\u5728\\u4e8e\\/i\",\"\\/\\u515a\\u7684\\u5b98\\/i\",\"\\/\\u515a\\u540e\\u840e\\/i\",\"\\/\\u515a\\u524d\\u5e72\\u52b2\\/i\",\"\\/\\u5200\\u67b6\\u4fdd\\u5b89\\/i\",\"\\/\\u5bfc\\u7684\\u60c5\\u4eba\\/i\",\"\\/\\u5bfc\\u53eb\\u5931\\/i\",\"\\/\\u5bfc\\u4eba\\u7684\\u6700\\/i\",\"\\/\\u5bfc\\u4eba\\u6700\\/i\",\"\\/\\u5bfc\\u5c0f\\u5546\\/i\",\"\\/\\u5230\\u82b1\\u5fc3\\/i\",\"\\/\\u5f97\\u8d22\\u517c\\/i\",\"\\/\\u7684\\u540c\\u4fee\\/i\",\"\\/\\u706f\\u8349\\u548c\\/i\",\"\\/\\u7b49\\u7ea7\\u8b49\\/i\",\"\\/\\u7b49\\u5c41\\u6c11\\/i\",\"\\/\\u7b49\\u4eba\\u8001\\u767e\\/i\",\"\\/\\u7b49\\u4eba\\u662f\\u8001\\/i\",\"\\/\\u7b49\\u4eba\\u624b\\u672f\\/i\",\"\\/\\u9093\\u7237\\u7237\\u8f6c\\/i\",\"\\/\\u9093\\u7389\\u5a07\\/i\",\"\\/\\u5730\\u4ea7\\u4e4b\\u6b4c\\/i\",\"\\/\\u5730\\u4e0b\\u5148\\u70c8\\/i\",\"\\/\\u5730\\u9707\\u54e5\\/i\",\"\\/\\u5e1d\\u56fd\\u4e4b\\u68a6\\/i\",\"\\/\\u9012\\u7eb8\\u6b7b\\/i\",\"\\/\\u70b9\\u6570\\u4f18\\u60e0\\/i\",\"\\/\\u7535\\u72d7\\/i\",\"\\/\\u7535\\u8bdd\\u76d1\\/i\",\"\\/\\u7535\\u9e21\\/i\",\"\\/\\u7538\\u679c\\u6562\\/i\",\"\\/\\u8776\\u821e\\u6309\\/i\",\"\\/\\u4e01\\u9999\\u793e\\/i\",\"\\/\\u4e01\\u5b50\\u9716\\/i\",\"\\/\\u9876\\u82b1\\u5fc3\\/i\",\"\\/\\u4e1c\\u5317\\u72ec\\u7acb\\/i\",\"\\/\\u4e1c\\u590d\\u6d3b\\/i\",\"\\/\\u4e1c\\u4eac\\u70ed\\/i\",\"\\/\\u6771\\u4eac\\u71b1\\/i\",\"\\/\\u6d1e\\u5c0f\\u53e3\\u7d27\\/i\",\"\\/\\u90fd\\u5f53\\u8b66\\/i\",\"\\/\\u90fd\\u5f53\\u5c0f\\u59d0\\/i\",\"\\/\\u90fd\\u8fdb\\u4e2d\\u592e\\/i\",\"\\/\\u6bd2\\u86c7\\u94bb\\/i\",\"\\/\\u72ec\\u7acb\\u53f0\\u6e7e\\/i\",\"\\/\\u8d4c\\u7403\\u7f51\\/i\",\"\\/\\u77ed\\u4fe1\\u622a\\/i\",\"\\/\\u5bf9\\u65e5\\u5f3a\\u786c\\/i\",\"\\/\\u591a\\u7f8e\\u5eb7\\/i\",\"\\/\\u8eb2\\u732b\\u732b\\/i\",\"\\/\\u4fc4\\u7f85\\u65af\\/i\",\"\\/\\u6076\\u52bf\\u529b\\u64cd\\/i\",\"\\/\\u6076\\u52bf\\u529b\\u63d2\\/i\",\"\\/\\u6069\\u6c1f\\u70f7\\/i\",\"\\/\\u513f\\u56ed\\u60e8\\/i\",\"\\/\\u513f\\u56ed\\u780d\\/i\",\"\\/\\u513f\\u56ed\\u6740\\/i\",\"\\/\\u513f\\u56ed\\u51f6\\/i\",\"\\/\\u4e8c\\u5976\\u5927\\/i\",\"\\/\\u53d1\\u724c\\u7edd\\/i\",\"\\/\\u53d1\\u7968\\u51fa\\/i\",\"\\/\\u53d1\\u7968\\u4ee3\\/i\",\"\\/\\u53d1\\u7968\\u9500\\/i\",\"\\/\\u767c\\u7968\\/i\",\"\\/\\u6cd5\\u8f66\\u4ed1\\/i\",\"\\/\\u6cd5\\u4f26\\u529f\\/i\",\"\\/\\u6cd5\\u8f6e\\/i\",\"\\/\\u6cd5\\u8f6e\\u4f5b\\/i\",\"\\/\\u6cd5\\u7ef4\\u6743\\/i\",\"\\/\\u6cd5\\u4e00\\u8f6e\\/i\",\"\\/\\u6cd5\\u9662\\u7ed9\\u5e9f\\/i\",\"\\/\\u6cd5\\u6b63\\u4e7e\\/i\",\"\\/\\u53cd\\u6d4b\\u901f\\u96f7\\/i\",\"\\/\\u53cd\\u96f7\\u8fbe\\u6d4b\\/i\",\"\\/\\u53cd\\u5c4f\\u853d\\/i\",\"\\/\\u8303\\u71d5\\u743c\\/i\",\"\\/\\u65b9\\u8ff7\\u9999\\/i\",\"\\/\\u9632\\u7535\\u5b50\\u773c\\/i\",\"\\/\\u9632\\u8eab\\u836f\\u6c34\\/i\",\"\\/\\u623f\\u8d37\\u7ed9\\u5e9f\\/i\",\"\\/\\u4eff\\u771f\\u67aa\\/i\",\"\\/\\u4eff\\u771f\\u8bc1\\/i\",\"\\/\\u8bfd\\u8c24\\u7f6a\\/i\",\"\\/\\u8d39\\u79c1\\u670d\\/i\",\"\\/\\u5c01\\u9501\\u6d88\\/i\",\"\\/\\u4f5b\\u540c\\u4fee\\/i\",\"\\/\\u592b\\u59bb\\u4ea4\\u6362\\/i\",\"\\/\\u798f\\u5c14\\u9a6c\\u6797\\/i\",\"\\/\\u798f\\u5a03\\u7684\\u9810\\/i\",\"\\/\\u798f\\u5a03\\u982d\\u4e0a\\/i\",\"\\/\\u798f\\u9999\\u5df4\\/i\",\"\\/\\u5e9c\\u5305\\u5e87\\/i\",\"\\/\\u5e9c\\u96c6\\u4e2d\\u9886\\/i\",\"\\/\\u5987\\u9500\\u9b42\\/i\",\"\\/\\u9644\\u9001\\u67aa\\/i\",\"\\/\\u590d\\u5370\\u4ef6\\u751f\\/i\",\"\\/\\u590d\\u5370\\u4ef6\\u5236\\/i\",\"\\/\\u5bcc\\u6c11\\u7a77\\/i\",\"\\/\\u5bcc\\u5a46\\u7ed9\\u5e9f\\/i\",\"\\/\\u6539\\u53f7\\u8f6f\\u4ef6\\/i\",\"\\/\\u611f\\u6251\\u514b\\/i\",\"\\/\\u5188\\u672c\\u771f\\/i\",\"\\/\\u809b\\u4ea4\\/i\",\"\\/\\u809b\\u95e8\\u662f\\u90bb\\/i\",\"\\/\\u5ca1\\u672c\\u771f\\/i\",\"\\/\\u94a2\\u9488\\u72d7\\/i\",\"\\/\\u94a2\\u73e0\\u67aa\\/i\",\"\\/\\u6e2f\\u6fb3\\u535a\\u7403\\/i\",\"\\/\\u6e2f\\u99ac\\u6703\\/i\",\"\\/\\u6e2f\\u946b\\u83ef\\/i\",\"\\/\\u9ad8\\u5c31\\u5728\\u653f\\/i\",\"\\/\\u9ad8\\u8003\\u9ed1\\/i\",\"\\/\\u9ad8\\u83ba\\u83ba\\/i\",\"\\/\\u641e\\u5a9b\\u4ea4\\/i\",\"\\/\\u544a\\u957f\\u671f\\/i\",\"\\/\\u544a\\u6d0b\\u72b6\\/i\",\"\\/\\u683c\\u8bc1\\u8003\\u8bd5\\/i\",\"\\/\\u5404\\u7c7b\\u8003\\u8bd5\\/i\",\"\\/\\u5404\\u7c7b\\u6587\\u51ed\\/i\",\"\\/\\u8ddf\\u8e2a\\u5668\\/i\",\"\\/\\u5de5\\u7a0b\\u541e\\u5f97\\/i\",\"\\/\\u5de5\\u529b\\u4eba\\/i\",\"\\/\\u516c\\u5b89\\u9519\\u6253\\/i\",\"\\/\\u516c\\u5b89\\u7f51\\u76d1\\/i\",\"\\/\\u516c\\u5f00\\u5c0f\\u59d0\\/i\",\"\\/\\u653b\\u5b98\\u5c0f\\u59d0\\/i\",\"\\/\\u5171\\u72d7\\/i\",\"\\/\\u5171\\u738b\\u50a8\\/i\",\"\\/\\u72d7\\u7cae\\/i\",\"\\/\\u72d7\\u5c41\\u4e13\\u5bb6\\/i\",\"\\/\\u9f13\\u52a8\\u4e00\\u4e9b\\/i\",\"\\/\\u4e56\\u4e56\\u7c89\\/i\",\"\\/\\u5b98\\u5546\\u52fe\\/i\",\"\\/\\u5b98\\u4e5f\\u4e0d\\u5bb9\\/i\",\"\\/\\u5b98\\u56e0\\u53d1\\u5e16\\/i\",\"\\/\\u5149\\u5b66\\u771f\\u9898\\/i\",\"\\/\\u8dea\\u771f\\u76f8\\/i\",\"\\/\\u6eda\\u5706\\u5927\\u4e73\\/i\",\"\\/\\u56fd\\u9645\\u6295\\u6ce8\\/i\",\"\\/\\u56fd\\u5bb6\\u5993\\/i\",\"\\/\\u56fd\\u5bb6\\u8f6f\\u5f31\\/i\",\"\\/\\u56fd\\u5bb6\\u541e\\u5f97\\/i\",\"\\/\\u56fd\\u5e93\\u6298\\/i\",\"\\/\\u56fd\\u4e00\\u4e5d\\u4e94\\u4e03\\/i\",\"\\/\\u570b\\u5167\\u7f8e\\/i\",\"\\/\\u54c8\\u836f\\u76f4\\u9500\\/i\",\"\\/\\u6d77\\u8bbf\\u6c11\\/i\",\"\\/\\u8c6a\\u5708\\u94b1\\/i\",\"\\/\\u53f7\\u5c4f\\u853d\\u5668\\/i\",\"\\/\\u548c\\u72d7\\u4ea4\\/i\",\"\\/\\u548c\\u72d7\\u6027\\/i\",\"\\/\\u548c\\u72d7\\u505a\\/i\",\"\\/\\u9ed1\\u706b\\u836f\\u7684\\/i\",\"\\/\\u7ea2\\u8272\\u6050\\u6016\\/i\",\"\\/\\u7ea2\\u5916\\u900f\\u89c6\\/i\",\"\\/\\u7d05\\u8272\\u6050\\/i\",\"\\/\\u80e1\\u6c5f\\u5185\\u6597\\/i\",\"\\/\\u80e1\\u7d27\\u5957\\/i\",\"\\/\\u80e1\\u9326\\u6fe4\\/i\",\"\\/\\u80e1\\u9002\\u773c\\/i\",\"\\/\\u80e1\\u8000\\u90a6\\/i\",\"\\/\\u6e56\\u6deb\\u5a18\\/i\",\"\\/\\u864e\\u5934\\u730e\\/i\",\"\\/\\u534e\\u56fd\\u950b\\/i\",\"\\/\\u534e\\u95e8\\u5f00\\/i\",\"\\/\\u5316\\u5b66\\u626b\\u76f2\\/i\",\"\\/\\u5212\\u8001\\u516c\\/i\",\"\\/\\u8fd8\\u4f1a\\u5439\\u8427\\/i\",\"\\/\\u8fd8\\u770b\\u9526\\u6d9b\\/i\",\"\\/\\u73af\\u7403\\u8bc1\\u4ef6\\/i\",\"\\/\\u6362\\u59bb\\/i\",\"\\/\\u7687\\u51a0\\u6295\\u6ce8\\/i\",\"\\/\\u9ec4\\u51b0\\/i\",\"\\/\\u6d51\\u5706\\u8c6a\\u4e73\\/i\",\"\\/\\u6d3b\\u4e0d\\u8d77\\/i\",\"\\/\\u706b\\u8f66\\u4e5f\\u75af\\/i\",\"\\/\\u673a\\u5b9a\\u4f4d\\u5668\\/i\",\"\\/\\u673a\\u53f7\\u5b9a\\/i\",\"\\/\\u673a\\u53f7\\u536b\\/i\",\"\\/\\u673a\\u5361\\u5bc6\\/i\",\"\\/\\u673a\\u5c4f\\u853d\\u5668\\/i\",\"\\/\\u57fa\\u672c\\u9760\\u543c\\/i\",\"\\/\\u7ee9\\u8fc7\\u540e\\u4ed8\\/i\",\"\\/\\u6fc0\\u60c5\\u7535\\/i\",\"\\/\\u6fc0\\u60c5\\u77ed\\/i\",\"\\/\\u6fc0\\u60c5\\u59b9\\/i\",\"\\/\\u6fc0\\u60c5\\u70ae\\/i\",\"\\/\\u7ea7\\u529e\\u7406\\/i\",\"\\/\\u7ea7\\u7b54\\u6848\\/i\",\"\\/\\u6025\\u9700\\u5ad6\\/i\",\"\\/\\u96c6\\u4f53\\u6253\\u7838\\/i\",\"\\/\\u96c6\\u4f53\\u8150\\/i\",\"\\/\\u6324\\u4e73\\u6c41\\/i\",\"\\/\\u64e0\\u4e73\\u6c41\\/i\",\"\\/\\u4f73\\u9759\\u5b89\\u5b9a\\/i\",\"\\/\\u5bb6\\u4e00\\u6837\\u9971\\/i\",\"\\/\\u5bb6\\u5c5e\\u88ab\\u6253\\/i\",\"\\/\\u7532\\u866b\\u8df3\\/i\",\"\\/\\u7532\\u6d41\\u4e86\\/i\",\"\\/\\u5978\\u6210\\u763e\\/i\",\"\\/\\u517c\\u804c\\u4e0a\\u95e8\\/i\",\"\\/\\u76d1\\u542c\\u5668\\/i\",\"\\/\\u76d1\\u542c\\u738b\\/i\",\"\\/\\u7b80\\u6613\\u70b8\\/i\",\"\\/\\u6c5f\\u80e1\\u5185\\u6597\\/i\",\"\\/\\u6c5f\\u592a\\u4e0a\\/i\",\"\\/\\u6c5f\\u7cfb\\u4eba\\/i\",\"\\/\\u6c5f\\u8d3c\\u6c11\\/i\",\"\\/\\u7586\\u7368\\/i\",\"\\/\\u848b\\u5f66\\u6c38\\/i\",\"\\/\\u53eb\\u81ea\\u6170\\/i\",\"\\/\\u63ed\\u8d2a\\u96be\\/i\",\"\\/\\u59d0\\u5305\\u591c\\/i\",\"\\/\\u59d0\\u670d\\u52a1\\/i\",\"\\/\\u59d0\\u517c\\u804c\\/i\",\"\\/\\u59d0\\u4e0a\\u95e8\\/i\",\"\\/\\u91d1\\u624e\\u91d1\\/i\",\"\\/\\u91d1\\u949f\\u6c14\\/i\",\"\\/\\u6d25\\u5927\\u5730\\u9707\\/i\",\"\\/\\u6d25\\u5730\\u9707\\/i\",\"\\/\\u8fdb\\u6765\\u7684\\u7f6a\\/i\",\"\\/\\u4eac\\u5730\\u9707\\/i\",\"\\/\\u4eac\\u8981\\u5730\\u9707\\/i\",\"\\/\\u7ecf\\u5178\\u8c0e\\u8a00\\/i\",\"\\/\\u7cbe\\u5b50\\u5c04\\u5728\\/i\",\"\\/\\u8b66\\u5bdf\\u88ab\\/i\",\"\\/\\u8b66\\u5bdf\\u7684\\u5e4c\\/i\",\"\\/\\u8b66\\u5bdf\\u6bb4\\u6253\\/i\",\"\\/\\u8b66\\u5bdf\\u8bf4\\u4fdd\\/i\",\"\\/\\u8b66\\u8f66\\u96f7\\u8fbe\\/i\",\"\\/\\u8b66\\u65b9\\u5305\\u5e87\\/i\",\"\\/\\u8b66\\u7528\\u54c1\\/i\",\"\\/\\u5f84\\u6b65\\u67aa\\/i\",\"\\/\\u656c\\u8bf7\\u5fcd\\/i\",\"\\/\\u7a76\\u751f\\u7b54\\u6848\\/i\",\"\\/\\u4e5d\\u9f99\\u8bba\\u575b\\/i\",\"\\/\\u4e5d\\u8bc4\\u5171\\/i\",\"\\/\\u9152\\u8c61\\u559d\\u6c64\\/i\",\"\\/\\u9152\\u50cf\\u559d\\u6c64\\/i\",\"\\/\\u5c31\\u7231\\u63d2\\/i\",\"\\/\\u5c31\\u8981\\u8272\\/i\",\"\\/\\u4e3e\\u56fd\\u4f53\\/i\",\"\\/\\u5de8\\u4e73\\/i\",\"\\/\\u636e\\u8bf4\\u5168\\u6c11\\/i\",\"\\/\\u7edd\\u98df\\u58f0\\/i\",\"\\/\\u519b\\u957f\\u53d1\\u5a01\\/i\",\"\\/\\u519b\\u523a\\/i\",\"\\/\\u519b\\u54c1\\u7279\\/i\",\"\\/\\u519b\\u7528\\u624b\\/i\",\"\\/\\u5f00\\u9093\\u9009\\/i\",\"\\/\\u5f00\\u9501\\u5de5\\u5177\\/i\",\"\\/\\u958b\\u78bc\\/i\",\"\\/\\u958b\\u7968\\/i\",\"\\/\\u780d\\u6740\\u5e7c\\/i\",\"\\/\\u780d\\u4f24\\u513f\\/i\",\"\\/\\u5eb7\\u6ca1\\u6709\\u4e0d\\/i\",\"\\/\\u5eb7\\u8df3\\u697c\\/i\",\"\\/\\u8003\\u7b54\\u6848\\/i\",\"\\/\\u8003\\u540e\\u4ed8\\u6b3e\\/i\",\"\\/\\u8003\\u673a\\u6784\\/i\",\"\\/\\u8003\\u8003\\u9093\\/i\",\"\\/\\u8003\\u8054\\u76df\\/i\",\"\\/\\u8003\\u524d\\u7b54\\/i\",\"\\/\\u8003\\u524d\\u7b54\\u6848\\/i\",\"\\/\\u8003\\u524d\\u4ed8\\/i\",\"\\/\\u8003\\u8bbe\\u5907\\/i\",\"\\/\\u8003\\u8bd5\\u5305\\u8fc7\\/i\",\"\\/\\u8003\\u8bd5\\u4fdd\\/i\",\"\\/\\u8003\\u8bd5\\u7b54\\u6848\\/i\",\"\\/\\u8003\\u8bd5\\u673a\\u6784\\/i\",\"\\/\\u8003\\u8bd5\\u8054\\u76df\\/i\",\"\\/\\u8003\\u8bd5\\u67aa\\/i\",\"\\/\\u8003\\u7814\\u8003\\u4e2d\\/i\",\"\\/\\u8003\\u4e2d\\u7b54\\u6848\\/i\",\"\\/\\u78d5\\u5f70\\/i\",\"\\/\\u514b\\u5206\\u6790\\/i\",\"\\/\\u514b\\u5343\\u672f\\/i\",\"\\/\\u514b\\u900f\\u89c6\\/i\",\"\\/\\u7a7a\\u548c\\u96c5\\u5178\\/i\",\"\\/\\u5b54\\u6444\\u50cf\\/i\",\"\\/\\u63a7\\u8bc9\\u4e16\\u535a\\/i\",\"\\/\\u63a7\\u5236\\u5a92\\/i\",\"\\/\\u53e3\\u624b\\u67aa\\/i\",\"\\/\\u9ab7\\u9ac5\\u6b7b\\/i\",\"\\/\\u5feb\\u901f\\u529e\\/i\",\"\\/\\u77ff\\u96be\\u4e0d\\u516c\\/i\",\"\\/\\u62c9\\u767b\\u8bf4\\/i\",\"\\/\\u62c9\\u5f00\\u6c34\\u6676\\/i\",\"\\/\\u6765\\u798f\\u730e\\/i\",\"\\/\\u62e6\\u622a\\u5668\\/i\",\"\\/\\u72fc\\u5168\\u90e8\\u8dea\\/i\",\"\\/\\u6d6a\\u7a74\\/i\",\"\\/\\u8001\\u864e\\u673a\\/i\",\"\\/\\u96f7\\u4eba\\u5973\\u5b98\\/i\",\"\\/\\u7c7b\\u51c6\\u786e\\u7b54\\/i\",\"\\/\\u9ece\\u9633\\u5e73\\/i\",\"\\/\\u674e\\u6d2a\\u5fd7\\/i\",\"\\/\\u674e\\u548f\\u66f0\\/i\",\"\\/\\u7406\\u5404\\u79cd\\u8bc1\\/i\",\"\\/\\u7406\\u662f\\u5f71\\u5e1d\\/i\",\"\\/\\u7406\\u8bc1\\u4ef6\\/i\",\"\\/\\u7406\\u505a\\u5e10\\u62a5\\/i\",\"\\/\\u529b\\u9a97\\u4e2d\\u592e\\/i\",\"\\/\\u529b\\u6708\\u897f\\/i\",\"\\/\\u4e3d\\u5a9b\\u79bb\\/i\",\"\\/\\u5229\\u4ed6\\u6797\\/i\",\"\\/\\u8fde\\u53d1\\u624b\\/i\",\"\\/\\u806f\\u7e6b\\u96fb\\/i\",\"\\/\\u70bc\\u5927\\u6cd5\\/i\",\"\\/\\u4e24\\u5cb8\\u624d\\u5b50\\/i\",\"\\/\\u4e24\\u4f1a\\u4ee3\\/i\",\"\\/\\u4e24\\u4f1a\\u53c8\\u4e09\\/i\",\"\\/\\u804a\\u89c6\\u9891\\/i\",\"\\/\\u804a\\u658b\\u8273\\/i\",\"\\/\\u4e86\\u4ef6\\u6e14\\u888d\\/i\",\"\\/\\u730e\\u597d\\u5e2e\\u624b\\/i\",\"\\/\\u730e\\u67aa\\u9500\\/i\",\"\\/\\u730e\\u69cd\\/i\",\"\\/\\u7375\\u69cd\\/i\",\"\\/\\u9886\\u571f\\u62ff\\/i\",\"\\/\\u6d41\\u8840\\u4e8b\\/i\",\"\\/\\u516d\\u5408\\u5f69\\/i\",\"\\/\\u516d\\u6b7b\\/i\",\"\\/\\u516d\\u56db\\u4e8b\\/i\",\"\\/\\u516d\\u6708\\u8054\\u76df\\/i\",\"\\/\\u9f99\\u6e7e\\u4e8b\\u4ef6\\/i\",\"\\/\\u9686\\u624b\\u6307\\/i\",\"\\/\\u9646\\u5c01\\u9501\\/i\",\"\\/\\u9646\\u540c\\u4fee\\/i\",\"\\/\\u6c2f\\u80fa\\u916e\\/i\",\"\\/\\u4e71\\u5978\\/i\",\"\\/\\u4e71\\u4f26\\u7c7b\\/i\",\"\\/\\u4e71\\u4f26\\u5c0f\\/i\",\"\\/\\u4e82\\u502b\\/i\",\"\\/\\u4f26\\u7406\\u5927\\/i\",\"\\/\\u4f26\\u7406\\u7535\\u5f71\\/i\",\"\\/\\u4f26\\u7406\\u6bdb\\/i\",\"\\/\\u4f26\\u7406\\u7247\\/i\",\"\\/\\u8f6e\\u529f\\/i\",\"\\/\\u8f6e\\u624b\\u67aa\\/i\",\"\\/\\u8bba\\u6587\\u4ee3\\/i\",\"\\/\\u7f57\\u65af\\u5c0f\\u59d0\\/i\",\"\\/\\u88f8\\u804a\\u7f51\\/i\",\"\\/\\u88f8\\u821e\\u89c6\\/i\",\"\\/\\u843d\\u971e\\u7f00\\/i\",\"\\/\\u9ebb\\u53e4\\/i\",\"\\/\\u9ebb\\u679c\\u914d\\/i\",\"\\/\\u9ebb\\u679c\\u4e38\\/i\",\"\\/\\u9ebb\\u5c06\\u900f\\/i\",\"\\/\\u9ebb\\u9189\\u72d7\\/i\",\"\\/\\u9ebb\\u9189\\u67aa\\/i\",\"\\/\\u9ebb\\u9189\\u69cd\\/i\",\"\\/\\u9ebb\\u9189\\u85e5\\/i\",\"\\/\\u87c6\\u53eb\\u4e13\\u5bb6\\/i\",\"\\/\\u5356\\u5730\\u8d22\\u653f\\/i\",\"\\/\\u5356\\u53d1\\u7968\\/i\",\"\\/\\u5356\\u94f6\\u884c\\u5361\\/i\",\"\\/\\u5356\\u81ea\\u8003\\/i\",\"\\/\\u6f2b\\u6b65\\u4e1d\\/i\",\"\\/\\u5fd9\\u7231\\u56fd\\/i\",\"\\/\\u732b\\u773c\\u5de5\\u5177\\/i\",\"\\/\\u6bdb\\u4e00\\u9c9c\\/i\",\"\\/\\u5a92\\u4f53\\u5c01\\u9501\\/i\",\"\\/\\u6bcf\\u5468\\u4e00\\u6b7b\\/i\",\"\\/\\u7f8e\\u8273\\u5c11\\u5987\\/i\",\"\\/\\u59b9\\u6309\\u6469\\/i\",\"\\/\\u59b9\\u4e0a\\u95e8\\/i\",\"\\/\\u95e8\\u6309\\u6469\\/i\",\"\\/\\u95e8\\u4fdd\\u5065\\/i\",\"\\/\\u9580\\u670d\\u52d9\\/i\",\"\\/\\u6c13\\u57f9\\u8bad\\/i\",\"\\/\\u8499\\u6c57\\u836f\\/i\",\"\\/\\u8ff7\\u5e7b\\u578b\\/i\",\"\\/\\u8ff7\\u5e7b\\u836f\\/i\",\"\\/\\u8ff7\\u5e7b\\u85e5\\/i\",\"\\/\\u8ff7\\u660f\\u53e3\\/i\",\"\\/\\u8ff7\\u660f\\u836f\\/i\",\"\\/\\u8ff7\\u660f\\u85e5\\/i\",\"\\/\\u8ff7\\u9b42\\u9999\\/i\",\"\\/\\u8ff7\\u9b42\\u836f\\/i\",\"\\/\\u8ff7\\u9b42\\u85e5\\/i\",\"\\/\\u8ff7\\u5978\\u836f\\/i\",\"\\/\\u8ff7\\u60c5\\u6c34\\/i\",\"\\/\\u8ff7\\u60c5\\u836f\\/i\",\"\\/\\u8ff7\\u85e5\\/i\",\"\\/\\u8c1c\\u5978\\u836f\\/i\",\"\\/\\u871c\\u7a74\\/i\",\"\\/\\u706d\\u7edd\\u7f6a\\/i\",\"\\/\\u6c11\\u50a8\\u5bb3\\/i\",\"\\/\\u6c11\\u4e5d\\u4ebf\\u5546\\/i\",\"\\/\\u6c11\\u6297\\u8bae\\/i\",\"\\/\\u660e\\u6167\\u7f51\\/i\",\"\\/\\u94ed\\u8bb0\\u5370\\u5c3c\\/i\",\"\\/\\u6469\\u5c0f\\u59d0\\/i\",\"\\/\\u6bcd\\u4e73\\u5bb6\\/i\",\"\\/\\u6728\\u9f50\\u9488\\/i\",\"\\/\\u5e55\\u6ca1\\u6709\\u4e0d\\/i\",\"\\/\\u5e55\\u524d\\u6232\\/i\",\"\\/\\u5185\\u5c04\\/i\",\"\\/\\u5357\\u5145\\u9488\\/i\",\"\\/\\u5ae9\\u7a74\\/i\",\"\\/\\u5ae9\\u9634\\/i\",\"\\/\\u6ce5\\u9a6c\\u4e4b\\u6b4c\\/i\",\"\\/\\u4f60\\u7684\\u897f\\u57df\\/i\",\"\\/\\u62df\\u6d9b\\u54e5\\/i\",\"\\/\\u5a18\\u4e24\\u817f\\u4e4b\\u95f4\\/i\",\"\\/\\u599e\\u4e0a\\u95e8\\/i\",\"\\/\\u6d53\\u7cbe\\/i\",\"\\/\\u6012\\u7684\\u5fd7\\u613f\\/i\",\"\\/\\u5973\\u88ab\\u4eba\\u5bb6\\u641e\\/i\",\"\\/\\u5973\\u6fc0\\u60c5\\/i\",\"\\/\\u5973\\u6280\\u5e08\\/i\",\"\\/\\u5973\\u4eba\\u548c\\u72d7\\/i\",\"\\/\\u5973\\u4efb\\u804c\\u540d\\/i\",\"\\/\\u5973\\u4e0a\\u95e8\\/i\",\"\\/\\u5973\\u512a\\/i\",\"\\/\\u9e25\\u4e4b\\u6b4c\\/i\",\"\\/\\u62cd\\u80a9\\u795e\\u836f\\/i\",\"\\/\\u62cd\\u80a9\\u578b\\/i\",\"\\/\\u724c\\u5206\\u6790\\/i\",\"\\/\\u724c\\u6280\\u7f51\\/i\",\"\\/\\u70ae\\u7684\\u5c0f\\u871c\\/i\",\"\\/\\u966a\\u8003\\u67aa\\/i\",\"\\/\\u914d\\u6709\\u6d88\\/i\",\"\\/\\u55b7\\u5c3f\\/i\",\"\\/\\u5ad6\\u4fc4\\u7f57\\/i\",\"\\/\\u5ad6\\u9e21\\/i\",\"\\/\\u5e73\\u60e8\\u6848\\/i\",\"\\/\\u5e73\\u53eb\\u5230\\u5e8a\\/i\",\"\\/\\u4ec6\\u4e0d\\u6015\\u996e\\/i\",\"\\/\\u666e\\u901a\\u560c\\/i\",\"\\/\\u671f\\u8d27\\u914d\\/i\",\"\\/\\u5947\\u8ff9\\u7684\\u9ec4\\/i\",\"\\/\\u5947\\u6deb\\u6563\\/i\",\"\\/\\u9a91\\u5355\\u8f66\\u51fa\\/i\",\"\\/\\u6c14\\u72d7\\/i\",\"\\/\\u6c14\\u67aa\\/i\",\"\\/\\u6c7d\\u72d7\\/i\",\"\\/\\u6c7d\\u67aa\\/i\",\"\\/\\u6c23\\u69cd\\/i\",\"\\/\\u94c5\\u5f39\\/i\",\"\\/\\u94b1\\u4e09\\u5b57\\u7ecf\\/i\",\"\\/\\u67aa\\u51fa\\u552e\\/i\",\"\\/\\u67aa\\u7684\\u53c2\\/i\",\"\\/\\u67aa\\u7684\\u5206\\/i\",\"\\/\\u67aa\\u7684\\u7ed3\\/i\",\"\\/\\u67aa\\u7684\\u5236\\/i\",\"\\/\\u67aa\\u8d27\\u5230\\/i\",\"\\/\\u67aa\\u51b3\\u5973\\u72af\\/i\",\"\\/\\u67aa\\u51b3\\u73b0\\u573a\\/i\",\"\\/\\u67aa\\u6a21\\/i\",\"\\/\\u67aa\\u624b\\u961f\\/i\",\"\\/\\u67aa\\u624b\\u7f51\\/i\",\"\\/\\u67aa\\u9500\\u552e\\/i\",\"\\/\\u67aa\\u68b0\\u5236\\/i\",\"\\/\\u67aa\\u5b50\\u5f39\\/i\",\"\\/\\u5f3a\\u6743\\u653f\\u5e9c\\/i\",\"\\/\\u5f3a\\u786c\\u53d1\\u8a00\\/i\",\"\\/\\u62a2\\u5176\\u706b\\u70ac\\/i\",\"\\/\\u5207\\u542c\\u5668\\/i\",\"\\/\\u7a83\\u542c\\u5668\\/i\",\"\\/\\u79bd\\u6d41\\u611f\\u4e86\\/i\",\"\\/\\u52e4\\u635e\\u81f4\\/i\",\"\\/\\u6c22\\u5f39\\u624b\\/i\",\"\\/\\u6e05\\u9664\\u8d1f\\u9762\\/i\",\"\\/\\u6e05\\u7d14\\u58c6\\/i\",\"\\/\\u60c5\\u804a\\u5929\\u5ba4\\/i\",\"\\/\\u60c5\\u59b9\\u59b9\\/i\",\"\\/\\u60c5\\u89c6\\u9891\\/i\",\"\\/\\u60c5\\u81ea\\u62cd\\/i\",\"\\/\\u6c30\\u5316\\u94be\\/i\",\"\\/\\u6c30\\u5316\\u94a0\\/i\",\"\\/\\u8bf7\\u96c6\\u4f1a\\/i\",\"\\/\\u8bf7\\u793a\\u5a01\\/i\",\"\\/\\u8bf7\\u613f\\/i\",\"\\/\\u743c\\u82b1\\u95ee\\/i\",\"\\/\\u533a\\u7684\\u96f7\\u4eba\\/i\",\"\\/\\u5a36\\u97e9\\u56fd\\/i\",\"\\/\\u5168\\u771f\\u8bc1\\/i\",\"\\/\\u7fa4\\u5978\\u66b4\\/i\",\"\\/\\u7fa4\\u8d77\\u6297\\u66b4\\/i\",\"\\/\\u7fa4\\u4f53\\u6027\\u4e8b\\/i\",\"\\/\\u7ed5\\u8fc7\\u5c01\\u9501\\/i\",\"\\/\\u60f9\\u7684\\u56fd\\/i\",\"\\/\\u4eba\\u6743\\u5f8b\\/i\",\"\\/\\u4eba\\u4f53\\u827a\\/i\",\"\\/\\u4eba\\u6e38\\u884c\\/i\",\"\\/\\u4eba\\u5728\\u4e91\\u4e0a\\/i\",\"\\/\\u4eba\\u771f\\u94b1\\/i\",\"\\/\\u8ba4\\u724c\\u7edd\\/i\",\"\\/\\u4efb\\u4e8e\\u65af\\u56fd\\/i\",\"\\/\\u67d4\\u80f8\\u7c89\\/i\",\"\\/\\u8089\\u6d1e\\/i\",\"\\/\\u8089\\u68cd\\/i\",\"\\/\\u5982\\u5395\\u6b7b\\/i\",\"\\/\\u4e73\\u4ea4\\/i\",\"\\/\\u8f6f\\u5f31\\u7684\\u56fd\\/i\",\"\\/\\u8d5b\\u540e\\u9a9a\\/i\",\"\\/\\u4e09\\u632b\\/i\",\"\\/\\u4e09\\u7ea7\\u7247\\/i\",\"\\/\\u4e09\\u79d2\\u5012\\/i\",\"\\/\\u4e09\\u7f51\\u53cb\\/i\",\"\\/\\u4e09\\u5511\\/i\",\"\\/\\u9a9a\\u5987\\/i\",\"\\/\\u9a9a\\u6d6a\\/i\",\"\\/\\u9a9a\\u7a74\\/i\",\"\\/\\u9a9a\\u5634\\/i\",\"\\/\\u626b\\u4e86\\u7237\\u7237\\/i\",\"\\/\\u8272\\u7535\\u5f71\\/i\",\"\\/\\u8272\\u59b9\\u59b9\\/i\",\"\\/\\u8272\\u89c6\\u9891\\/i\",\"\\/\\u8272\\u5c0f\\u8bf4\\/i\",\"\\/\\u6740\\u6307\\u5357\\/i\",\"\\/\\u5c71\\u6d89\\u9ed1\\/i\",\"\\/\\u717d\\u52a8\\u4e0d\\u660e\\/i\",\"\\/\\u717d\\u52a8\\u7fa4\\u4f17\\/i\",\"\\/\\u4e0a\\u95e8\\u6fc0\\/i\",\"\\/\\u70e7\\u516c\\u5b89\\u5c40\\/i\",\"\\/\\u70e7\\u74f6\\u7684\\/i\",\"\\/\\u97f6\\u5173\\u6597\\/i\",\"\\/\\u97f6\\u5173\\u73a9\\/i\",\"\\/\\u97f6\\u5173\\u65ed\\/i\",\"\\/\\u5c04\\u7f51\\u67aa\\/i\",\"\\/\\u6d89\\u5acc\\u6284\\u88ad\\/i\",\"\\/\\u6df1\\u5589\\u51b0\\/i\",\"\\/\\u795e\\u4e03\\u5047\\/i\",\"\\/\\u795e\\u97f5\\u827a\\u672f\\/i\",\"\\/\\u751f\\u88ab\\u780d\\/i\",\"\\/\\u751f\\u8e29\\u8e0f\\/i\",\"\\/\\u751f\\u8096\\u4e2d\\u7279\\/i\",\"\\/\\u5723\\u6218\\u4e0d\\u606f\\/i\",\"\\/\\u76db\\u884c\\u5728\\u821e\\/i\",\"\\/\\u5c38\\u535a\\/i\",\"\\/\\u5931\\u8eab\\u6c34\\/i\",\"\\/\\u5931\\u610f\\u836f\\/i\",\"\\/\\u72ee\\u5b50\\u65d7\\/i\",\"\\/\\u5341\\u516b\\u7b49\\/i\",\"\\/\\u5341\\u5927\\u8c0e\\/i\",\"\\/\\u5341\\u5927\\u7981\\/i\",\"\\/\\u5341\\u4e2a\\u9884\\u8a00\\/i\",\"\\/\\u5341\\u7c7b\\u4eba\\u4e0d\\/i\",\"\\/\\u5341\\u4e03\\u5927\\u5e55\\/i\",\"\\/\\u5b9e\\u6bd5\\u4e1a\\u8bc1\\/i\",\"\\/\\u5b9e\\u4f53\\u5a03\\/i\",\"\\/\\u5b9e\\u5b66\\u5386\\u6587\\/i\",\"\\/\\u58eb\\u5eb7\\u4e8b\\u4ef6\\/i\",\"\\/\\u5f0f\\u7c89\\u63a8\\/i\",\"\\/\\u89c6\\u89e3\\u5bc6\\/i\",\"\\/\\u662f\\u8eb2\\u732b\\/i\",\"\\/\\u624b\\u53d8\\u724c\\/i\",\"\\/\\u624b\\u7b54\\u6848\\/i\",\"\\/\\u624b\\u72d7\\/i\",\"\\/\\u624b\\u673a\\u8ddf\\/i\",\"\\/\\u624b\\u673a\\u76d1\\/i\",\"\\/\\u624b\\u673a\\u7a83\\/i\",\"\\/\\u624b\\u673a\\u8ffd\\/i\",\"\\/\\u624b\\u62c9\\u9e21\\/i\",\"\\/\\u624b\\u6728\\u4ed3\\/i\",\"\\/\\u624b\\u69cd\\/i\",\"\\/\\u5b88\\u6240\\u6b7b\\u6cd5\\/i\",\"\\/\\u517d\\u4ea4\\/i\",\"\\/\\u552e\\u6b65\\u67aa\\/i\",\"\\/\\u552e\\u7eaf\\u5ea6\\/i\",\"\\/\\u552e\\u5355\\u7ba1\\/i\",\"\\/\\u552e\\u5f39\\u7c27\\u5200\\/i\",\"\\/\\u552e\\u9632\\u8eab\\/i\",\"\\/\\u552e\\u72d7\\u5b50\\/i\",\"\\/\\u552e\\u864e\\u5934\\/i\",\"\\/\\u552e\\u706b\\u836f\\/i\",\"\\/\\u552e\\u5047\\u5e01\\/i\",\"\\/\\u552e\\u5065\\u536b\\/i\",\"\\/\\u552e\\u519b\\u7528\\/i\",\"\\/\\u552e\\u730e\\u67aa\\/i\",\"\\/\\u552e\\u6c2f\\u80fa\\/i\",\"\\/\\u552e\\u9ebb\\u9189\\/i\",\"\\/\\u552e\\u5192\\u540d\\/i\",\"\\/\\u552e\\u67aa\\u652f\\/i\",\"\\/\\u552e\\u70ed\\u6b66\\/i\",\"\\/\\u552e\\u4e09\\u68f1\\/i\",\"\\/\\u552e\\u624b\\u67aa\\/i\",\"\\/\\u552e\\u4e94\\u56db\\/i\",\"\\/\\u552e\\u4fe1\\u7528\\/i\",\"\\/\\u552e\\u4e00\\u5143\\u786c\\/i\",\"\\/\\u552e\\u5b50\\u5f39\\/i\",\"\\/\\u552e\\u5de6\\u8f6e\\/i\",\"\\/\\u4e66\\u529e\\u7406\\/i\",\"\\/\\u719f\\u5987\\/i\",\"\\/\\u672f\\u724c\\u5177\\/i\",\"\\/\\u53cc\\u7ba1\\u7acb\\/i\",\"\\/\\u53cc\\u7ba1\\u5e73\\/i\",\"\\/\\u6c34\\u960e\\u738b\\/i\",\"\\/\\u4e1d\\u62a4\\u58eb\\/i\",\"\\/\\u4e1d\\u60c5\\u4fa3\\/i\",\"\\/\\u4e1d\\u889c\\u4fdd\\/i\",\"\\/\\u4e1d\\u889c\\u604b\\/i\",\"\\/\\u4e1d\\u889c\\u7f8e\\/i\",\"\\/\\u4e1d\\u889c\\u59b9\\/i\",\"\\/\\u4e1d\\u889c\\u7f51\\/i\",\"\\/\\u4e1d\\u8db3\\u6309\\/i\",\"\\/\\u53f8\\u957f\\u671f\\u6709\\/i\",\"\\/\\u53f8\\u6cd5\\u9ed1\\/i\",\"\\/\\u79c1\\u623f\\u5199\\u771f\\/i\",\"\\/\\u6b7b\\u6cd5\\u5206\\u5e03\\/i\",\"\\/\\u6b7b\\u8981\\u89c1\\u6bdb\\/i\",\"\\/\\u56db\\u535a\\u4f1a\\/i\",\"\\/\\u56db\\u5927\\u626f\\/i\",\"\\/\\u4e2a\\u56db\\u5c0f\\u7801\\/i\",\"\\/\\u82cf\\u5bb6\\u5c6f\\u96c6\\/i\",\"\\/\\u8bc9\\u8bbc\\u96c6\\u56e2\\/i\",\"\\/\\u7d20\\u5973\\u5fc3\\/i\",\"\\/\\u901f\\u4ee3\\u529e\\/i\",\"\\/\\u901f\\u53d6\\u8bc1\\/i\",\"\\/\\u9178\\u7f9f\\u4e9a\\u80fa\\/i\",\"\\/\\u8e4b\\u7eb3\\u7a0e\\/i\",\"\\/\\u592a\\u738b\\u56db\\u795e\\/i\",\"\\/\\u6cf0\\u5174\\u5e7c\\/i\",\"\\/\\u6cf0\\u5174\\u9547\\u4e2d\\/i\",\"\\/\\u6cf0\\u5dde\\u5e7c\\/i\",\"\\/\\u8d2a\\u5b98\\u4e5f\\u8f9b\\/i\",\"\\/\\u63a2\\u6d4b\\u72d7\\/i\",\"\\/\\u6d9b\\u5171\\u4ea7\\/i\",\"\\/\\u6d9b\\u4e00\\u6837\\u80e1\\/i\",\"\\/\\u7279\\u5de5\\u8d44\\/i\",\"\\/\\u7279\\u7801\\/i\",\"\\/\\u7279\\u4e0a\\u95e8\\/i\",\"\\/\\u4f53\\u900f\\u89c6\\u955c\\/i\",\"\\/\\u66ff\\u8003\\/i\",\"\\/\\u66ff\\u4eba\\u4f53\\/i\",\"\\/\\u5929\\u671d\\u7279\\/i\",\"\\/\\u5929\\u9e45\\u4e4b\\u65c5\\/i\",\"\\/\\u5929\\u63a8\\u5e7f\\u6b4c\\/i\",\"\\/\\u7530\\u7f62\\u5de5\\/i\",\"\\/\\u7530\\u7530\\u6851\\/i\",\"\\/\\u7530\\u505c\\u5de5\\/i\",\"\\/\\u5ead\\u4fdd\\u517b\\/i\",\"\\/\\u5ead\\u5ba1\\u76f4\\u64ad\\/i\",\"\\/\\u901a\\u94a2\\u603b\\u7ecf\\/i\",\"\\/\\u5077\\u96fb\\u5668\\/i\",\"\\/\\u5077\\u8083\\u8d2a\\/i\",\"\\/\\u5077\\u542c\\u5668\\/i\",\"\\/\\u5077\\u5077\\u8d2a\\/i\",\"\\/\\u5934\\u53cc\\u7ba1\\/i\",\"\\/\\u900f\\u89c6\\u529f\\u80fd\\/i\",\"\\/\\u900f\\u89c6\\u955c\\/i\",\"\\/\\u900f\\u89c6\\u6251\\/i\",\"\\/\\u900f\\u89c6\\u5668\\/i\",\"\\/\\u900f\\u89c6\\u773c\\u955c\\/i\",\"\\/\\u900f\\u89c6\\u836f\\/i\",\"\\/\\u900f\\u89c6\\u4eea\\/i\",\"\\/\\u79c3\\u9e70\\u6c7d\\/i\",\"\\/\\u7a81\\u7834\\u5c01\\u9501\\/i\",\"\\/\\u7a81\\u7834\\u7f51\\u8def\\/i\",\"\\/\\u63a8\\u6cb9\\u6309\\/i\",\"\\/\\u8131\\u8863\\u8273\\/i\",\"\\/\\u74e6\\u65af\\u624b\\/i\",\"\\/\\u889c\\u6309\\u6469\\/i\",\"\\/\\u5916\\u900f\\u89c6\\u955c\\/i\",\"\\/\\u5916\\u56f4\\u8d4c\\u7403\\/i\",\"\\/\\u6e7e\\u7248\\u5047\\/i\",\"\\/\\u4e07\\u80fd\\u94a5\\u5319\\/i\",\"\\/\\u4e07\\u4eba\\u9a9a\\u52a8\\/i\",\"\\/\\u738b\\u7acb\\u519b\\/i\",\"\\/\\u738b\\u76ca\\u6848\\/i\",\"\\/\\u7f51\\u6c11\\u6848\\/i\",\"\\/\\u7f51\\u6c11\\u83b7\\u5211\\/i\",\"\\/\\u7f51\\u6c11\\u8bec\\/i\",\"\\/\\u5fae\\u578b\\u6444\\u50cf\\/i\",\"\\/\\u56f4\\u653b\\u8b66\\/i\",\"\\/\\u56f4\\u653b\\u4e0a\\u6d77\\/i\",\"\\/\\u7ef4\\u6c49\\u5458\\/i\",\"\\/\\u7ef4\\u6743\\u57fa\\/i\",\"\\/\\u7ef4\\u6743\\u4eba\\/i\",\"\\/\\u7ef4\\u6743\\u8c08\\/i\",\"\\/\\u59d4\\u5750\\u8239\\/i\",\"\\/\\u8c13\\u7684\\u548c\\u8c10\\/i\",\"\\/\\u6e29\\u5bb6\\u5821\\/i\",\"\\/\\u6e29\\u5207\\u65af\\u7279\\/i\",\"\\/\\u6e29\\u5f71\\u5e1d\\/i\",\"\\/\\u6eab\\u5bb6\\u5bf6\\/i\",\"\\/\\u761f\\u52a0\\u9971\\/i\",\"\\/\\u761f\\u5047\\u9971\\/i\",\"\\/\\u6587\\u51ed\\u8bc1\\/i\",\"\\/\\u6587\\u5f3a\\/i\",\"\\/\\u7eb9\\u4e86\\u6bdb\\/i\",\"\\/\\u95fb\\u88ab\\u63a7\\u5236\\/i\",\"\\/\\u95fb\\u5c01\\u9501\\/i\",\"\\/\\u74ee\\u5b89\\/i\",\"\\/\\u6211\\u7684\\u897f\\u57df\\/i\",\"\\/\\u6211\\u641e\\u53f0\\u72ec\\/i\",\"\\/\\u4e4c\\u8747\\u6c34\\/i\",\"\\/\\u65e0\\u803b\\u8bed\\u5f55\\/i\",\"\\/\\u65e0\\u7801\\u4e13\\/i\",\"\\/\\u4e94\\u5957\\u529f\\/i\",\"\\/\\u4e94\\u6708\\u5929\\/i\",\"\\/\\u5348\\u591c\\u7535\\/i\",\"\\/\\u5348\\u591c\\u6781\\/i\",\"\\/\\u6b66\\u8b66\\u66b4\\/i\",\"\\/\\u6b66\\u8b66\\u6bb4\\/i\",\"\\/\\u6b66\\u8b66\\u5df2\\u589e\\/i\",\"\\/\\u52a1\\u5458\\u7b54\\u6848\\/i\",\"\\/\\u52a1\\u5458\\u8003\\u8bd5\\/i\",\"\\/\\u96fe\\u578b\\u8ff7\\/i\",\"\\/\\u897f\\u85cf\\u9650\\/i\",\"\\/\\u897f\\u670d\\u8fdb\\u53bb\\/i\",\"\\/\\u5e0c\\u810f\\/i\",\"\\/\\u4e60\\u8fdb\\u5e73\\/i\",\"\\/\\u4e60\\u664b\\u5e73\\/i\",\"\\/\\u5e2d\\u590d\\u6d3b\\/i\",\"\\/\\u5e2d\\u4e34\\u7ec8\\u524d\\/i\",\"\\/\\u5e2d\\u6307\\u7740\\u62a4\\/i\",\"\\/\\u6d17\\u6fa1\\u6b7b\\/i\",\"\\/\\u559c\\u8d2a\\u8d43\\/i\",\"\\/\\u5148\\u70c8\\u7eb7\\u7eb7\\/i\",\"\\/\\u73b0\\u5927\\u5730\\u9707\\/i\",\"\\/\\u73b0\\u91d1\\u6295\\u6ce8\\/i\",\"\\/\\u7ebf\\u900f\\u89c6\\u955c\\/i\",\"\\/\\u9650\\u5236\\u8a00\\/i\",\"\\/\\u9677\\u5bb3\\u6848\\/i\",\"\\/\\u9677\\u5bb3\\u7f6a\\/i\",\"\\/\\u76f8\\u81ea\\u9996\\/i\",\"\\/\\u9999\\u6e2f\\u8bba\\u575b\\/i\",\"\\/\\u9999\\u6e2f\\u9a6c\\u4f1a\\/i\",\"\\/\\u9999\\u6e2f\\u4e00\\u7c7b\\/i\",\"\\/\\u9999\\u6e2f\\u603b\\u5f69\\/i\",\"\\/\\u785d\\u5316\\u7518\\/i\",\"\\/\\u5c0f\\u7a74\\/i\",\"\\/\\u6821\\u9a9a\\u4e71\\/i\",\"\\/\\u534f\\u6643\\u60a0\\/i\",\"\\/\\u5199\\u4e24\\u4f1a\\/i\",\"\\/\\u6cc4\\u6f0f\\u7684\\u5185\\/i\",\"\\/\\u65b0\\u5efa\\u6237\\/i\",\"\\/\\u65b0\\u7586\\u53db\\/i\",\"\\/\\u65b0\\u7586\\u9650\\/i\",\"\\/\\u65b0\\u91d1\\u74f6\\/i\",\"\\/\\u65b0\\u5510\\u4eba\\/i\",\"\\/\\u4fe1\\u8bbf\\u4e13\\u73ed\\/i\",\"\\/\\u4fe1\\u63a5\\u6536\\u5668\\/i\",\"\\/\\u5174\\u4e2d\\u5fc3\\u5e7c\\/i\",\"\\/\\u661f\\u4e0a\\u95e8\\/i\",\"\\/\\u884c\\u957f\\u738b\\u76ca\\/i\",\"\\/\\u5f62\\u900f\\u89c6\\u955c\\/i\",\"\\/\\u578b\\u624b\\u67aa\\/i\",\"\\/\\u59d3\\u5ffd\\u60a0\\/i\",\"\\/\\u5e78\\u8fd0\\u7801\\/i\",\"\\/\\u6027\\u7231\\u65e5\\/i\",\"\\/\\u6027\\u798f\\u60c5\\/i\",\"\\/\\u6027\\u611f\\u5c11\\/i\",\"\\/\\u6027\\u63a8\\u5e7f\\u6b4c\\/i\",\"\\/\\u80f8\\u4e3b\\u5e2d\\/i\",\"\\/\\u5f90\\u7389\\u5143\\/i\",\"\\/\\u5b66\\u9a9a\\u4e71\\/i\",\"\\/\\u5b66\\u4f4d\\u8b49\\/i\",\"\\/\\u5b78\\u751f\\u59b9\\/i\",\"\\/\\u4e2b\\u4e0e\\u738b\\u76ca\\/i\",\"\\/\\u70df\\u611f\\u5668\\/i\",\"\\/\\u4e25\\u6653\\u73b2\\/i\",\"\\/\\u8a00\\u88ab\\u52b3\\u6559\\/i\",\"\\/\\u8a00\\u8bba\\u7f6a\\/i\",\"\\/\\u76d0\\u9178\\u66f2\\/i\",\"\\/\\u989c\\u5c04\\/i\",\"\\/\\u6059\\u866b\\u75c5\\/i\",\"\\/\\u59da\\u660e\\u8fdb\\u53bb\\/i\",\"\\/\\u8981\\u4eba\\u6743\\/i\",\"\\/\\u8981\\u5c04\\u7cbe\\u4e86\\/i\",\"\\/\\u8981\\u5c04\\u4e86\\/i\",\"\\/\\u8981\\u6cc4\\u4e86\\/i\",\"\\/\\u591c\\u6fc0\\u60c5\\/i\",\"\\/\\u6db2\\u4f53\\u70b8\\/i\",\"\\/\\u4e00\\u5c0f\\u64ae\\u522b\\/i\",\"\\/\\u9057\\u60c5\\u4e66\\/i\",\"\\/\\u8681\\u529b\\u795e\\/i\",\"\\/\\u76ca\\u5173\\u6ce8\\u7ec4\\/i\",\"\\/\\u76ca\\u53d7\\u8d3f\\/i\",\"\\/\\u9634\\u95f4\\u6765\\u7535\\/i\",\"\\/\\u9670\\u5507\\/i\",\"\\/\\u9670\\u9053\\/i\",\"\\/\\u9670\\u6236\\/i\",\"\\/\\u6deb\\u9b54\\u821e\\/i\",\"\\/\\u6deb\\u60c5\\u5973\\/i\",\"\\/\\u6deb\\u8089\\/i\",\"\\/\\u6deb\\u9a37\\u59b9\\/i\",\"\\/\\u6deb\\u517d\\/i\",\"\\/\\u6deb\\u517d\\u5b66\\/i\",\"\\/\\u6deb\\u6c34\\/i\",\"\\/\\u6deb\\u7a74\\/i\",\"\\/\\u9690\\u5f62\\u8033\\/i\",\"\\/\\u9690\\u5f62\\u55b7\\u5242\\/i\",\"\\/\\u5e94\\u5b50\\u5f39\\/i\",\"\\/\\u5a74\\u513f\\u547d\\/i\",\"\\/\\u548f\\u5993\\/i\",\"\\/\\u7528\\u624b\\u67aa\\/i\",\"\\/\\u5e7d\\u8c37\\u4e09\\/i\",\"\\/\\u6e38\\u7cbe\\u4f51\\/i\",\"\\/\\u6709\\u5976\\u4e0d\\u4e00\\/i\",\"\\/\\u53f3\\u8f6c\\u662f\\u653f\\/i\",\"\\/\\u5e7c\\u9f7f\\u7c7b\\/i\",\"\\/\\u5a31\\u4e50\\u900f\\u89c6\\/i\",\"\\/\\u611a\\u6c11\\u540c\\/i\",\"\\/\\u611a\\u6c11\\u653f\\/i\",\"\\/\\u4e0e\\u72d7\\u6027\\/i\",\"\\/\\u7389\\u84b2\\u56e2\\/i\",\"\\/\\u80b2\\u90e8\\u5973\\u5b98\\/i\",\"\\/\\u51a4\\u6c11\\u5927\\/i\",\"\\/\\u9e33\\u9e2f\\u6d17\\/i\",\"\\/\\u56ed\\u60e8\\u6848\\/i\",\"\\/\\u56ed\\u53d1\\u751f\\u780d\\/i\",\"\\/\\u56ed\\u780d\\u6740\\/i\",\"\\/\\u56ed\\u51f6\\u6740\\/i\",\"\\/\\u56ed\\u8840\\u6848\\/i\",\"\\/\\u539f\\u4e00\\u4e5d\\u4e94\\u4e03\\/i\",\"\\/\\u539f\\u88c5\\u5f39\\/i\",\"\\/\\u8881\\u817e\\u98de\\/i\",\"\\/\\u6655\\u5012\\u578b\\/i\",\"\\/\\u97f5\\u5f90\\u5a18\\/i\",\"\\/\\u906d\\u4fbf\\u8863\\/i\",\"\\/\\u906d\\u5230\\u8b66\\/i\",\"\\/\\u906d\\u8b66\\u5bdf\\/i\",\"\\/\\u906d\\u6b66\\u8b66\\/i\",\"\\/\\u62e9\\u6cb9\\u5f55\\/i\",\"\\/\\u66fe\\u9053\\u4eba\\/i\",\"\\/\\u70b8\\u5f39\\u6559\\/i\",\"\\/\\u70b8\\u5f39\\u9065\\u63a7\\/i\",\"\\/\\u70b8\\u5e7f\\u5dde\\/i\",\"\\/\\u70b8\\u7acb\\u4ea4\\/i\",\"\\/\\u70b8\\u836f\\u7684\\u5236\\/i\",\"\\/\\u70b8\\u836f\\u914d\\/i\",\"\\/\\u70b8\\u836f\\u5236\\/i\",\"\\/\\u5f20\\u6625\\u6865\\/i\",\"\\/\\u627e\\u67aa\\u624b\\/i\",\"\\/\\u627e\\u63f4\\u4ea4\\/i\",\"\\/\\u627e\\u653f\\u6cd5\\u59d4\\u526f\\/i\",\"\\/\\u8d75\\u7d2b\\u9633\\/i\",\"\\/\\u9488\\u523a\\u6848\\/i\",\"\\/\\u9488\\u523a\\u4f24\\/i\",\"\\/\\u9488\\u523a\\u4e8b\\/i\",\"\\/\\u9488\\u523a\\u6b7b\\/i\",\"\\/\\u4fa6\\u63a2\\u8bbe\\u5907\\/i\",\"\\/\\u771f\\u94b1\\u6597\\u5730\\/i\",\"\\/\\u771f\\u94b1\\u6295\\u6ce8\\u771f\\u5584\\u5fcd\\/i\",\"\\/\\u771f\\u5b9e\\u6587\\u51ed\\/i\",\"\\/\\u771f\\u5b9e\\u8d44\\u683c\\/i\",\"\\/\\u9707\\u60ca\\u4e00\\u4e2a\\u6c11\\/i\",\"\\/\\u9707\\u5176\\u56fd\\u571f\\/i\",\"\\/\\u8bc1\\u5230\\u4ed8\\u6b3e\\/i\",\"\\/\\u8bc1\\u4ef6\\u529e\\/i\",\"\\/\\u8bc1\\u4ef6\\u96c6\\u56e2\\/i\",\"\\/\\u8bc1\\u751f\\u6210\\u5668\\/i\",\"\\/\\u8bc1\\u4e66\\u529e\\/i\",\"\\/\\u8bc1\\u4e00\\u6b21\\u6027\\/i\",\"\\/\\u653f\\u5e9c\\u64cd\\/i\",\"\\/\\u653f\\u8bba\\u533a\\/i\",\"\\/\\u8b49\\u4ef6\\/i\",\"\\/\\u690d\\u7269\\u51b0\\/i\",\"\\/\\u6b96\\u5668\\u62a4\\/i\",\"\\/\\u6307\\u7eb9\\u8003\\u52e4\\/i\",\"\\/\\u6307\\u7eb9\\u819c\\/i\",\"\\/\\u6307\\u7eb9\\u5957\\/i\",\"\\/\\u81f3\\u56fd\\u5bb6\\u9ad8\\/i\",\"\\/\\u5fd7\\u4e0d\\u613f\\u8ddf\\/i\",\"\\/\\u5236\\u670d\\u8bf1\\/i\",\"\\/\\u5236\\u624b\\u67aa\\/i\",\"\\/\\u5236\\u8bc1\\u5b9a\\u91d1\\/i\",\"\\/\\u5236\\u4f5c\\u8bc1\\u4ef6\\/i\",\"\\/\\u4e2d\\u7684\\u73ed\\u7985\\/i\",\"\\/\\u4e2d\\u5171\\u9ed1\\/i\",\"\\/\\u4e2d\\u56fd\\u4e0d\\u5f3a\\/i\",\"\\/\\u79cd\\u516c\\u52a1\\u5458\\/i\",\"\\/\\u79cd\\u5b66\\u5386\\u8bc1\\/i\",\"\\/\\u4f17\\u50cf\\u7f94\\/i\",\"\\/\\u5dde\\u60e8\\u6848\\/i\",\"\\/\\u5dde\\u5927\\u6279\\u8d2a\\/i\",\"\\/\\u5dde\\u4e09\\u7bad\\/i\",\"\\/\\u5b99\\u6700\\u9ad8\\u6cd5\\/i\",\"\\/\\u663c\\u5c06\\u8fd1\\/i\",\"\\/\\u4e3b\\u5e2d\\u5fcf\\/i\",\"\\/\\u4f4f\\u82f1\\u56fd\\u623f\\/i\",\"\\/\\u52a9\\u8003\\/i\",\"\\/\\u52a9\\u8003\\u7f51\\/i\",\"\\/\\u4e13\\u4e1a\\u529e\\u7406\\/i\",\"\\/\\u4e13\\u4e1a\\u4ee3\\/i\",\"\\/\\u4e13\\u4e1a\\u4ee3\\u5199\\/i\",\"\\/\\u4e13\\u4e1a\\u52a9\\/i\",\"\\/\\u8f6c\\u662f\\u653f\\u5e9c\\/i\",\"\\/\\u8d5a\\u94b1\\u8d44\\u6599\\/i\",\"\\/\\u88c5\\u5f39\\u7532\\/i\",\"\\/\\u88c5\\u67aa\\u5957\\/i\",\"\\/\\u88c5\\u6d88\\u97f3\\/i\",\"\\/\\u7740\\u62a4\\u58eb\\u7684\\u80f8\\/i\",\"\\/\\u7740\\u6d9b\\u54e5\\/i\",\"\\/\\u59ff\\u4e0d\\u5bf9\\u6b7b\\/i\",\"\\/\\u8d44\\u683c\\u8b49\\/i\",\"\\/\\u8d44\\u6599\\u6cc4\\/i\",\"\\/\\u6893\\u5065\\u7279\\u836f\\/i\",\"\\/\\u5b57\\u724c\\u6c7d\\/i\",\"\\/\\u81ea\\u5df1\\u627e\\u67aa\\/i\",\"\\/\\u81ea\\u6170\\u7528\\/i\",\"\\/\\u81ea\\u7531\\u5723\\/i\",\"\\/\\u81ea\\u7531\\u4e9a\\/i\",\"\\/\\u603b\\u4f1a\\u7f8e\\u5973\\/i\",\"\\/\\u8db3\\u7403\\u73a9\\u6cd5\\/i\",\"\\/\\u6700\\u725b\\u516c\\u5b89\\/i\",\"\\/\\u9189\\u94a2\\u67aa\\/i\",\"\\/\\u9189\\u8ff7\\u836f\\/i\",\"\\/\\u9189\\u4e59\\u919a\\/i\",\"\\/\\u5c0a\\u7235\\u7c89\\/i\",\"\\/\\u5de6\\u8f6c\\u662f\\u653f\\/i\",\"\\/\\u4f5c\\u5f0a\\u5668\\/i\",\"\\/\\u4f5c\\u5404\\u79cd\\u8bc1\\/i\",\"\\/\\u4f5c\\u785d\\u5316\\u7518\\/i\",\"\\/\\u5511\\u4ed1\\/i\",\"\\/\\u505a\\u7231\\u5c0f\\/i\",\"\\/\\u505a\\u539f\\u5b50\\u5f39\\/i\",\"\\/\\u505a\\u8bc1\\u4ef6\\/i\"]'),('fof-filter.emailWhenFlagged','1'),('fof-filter.flaggedEmail','检测到您的帖子包含敏感词、违禁词，已暂时隐藏。\n\n如有异议，请联系论坛管理员请求人工核查。如果核实没有违规内容，我们将恢复您的帖子。\n\n感谢您的理解与配合。'),('fof-filter.flaggedSubject','您的帖子已被隐藏'),('fof-filter.words','阿扁推翻\n阿宾\n阿賓\n挨了一炮\n爱液横流\n安街逆\n安局办公楼\n安局豪华\n安门事\n安眠藥\n案的准确\n八九民\n八九学\n八九政治\n把病人整\n把邓小平\n把学生整\n罢工门\n白黄牙签\n败培训\n办本科\n办理本科\n办理各种\n办理票据\n办理文凭\n办理真实\n办理证书\n办理资格\n办文凭\n办怔\n办证\n半刺刀\n辦毕业\n辦證\n谤罪获刑\n磅解码器\n磅遥控器\n宝在甘肃修\n保过答案\n报复执法\n爆发骚\n北省委门\n被打死\n被指抄袭\n被中共\n本公司担\n本无码\n毕业證\n变牌绝\n辩词与梦\n冰毒\n冰火毒\n冰火佳\n冰火九重\n冰火漫\n冰淫传\n冰在火上\n波推龙\n博彩娱\n博会暂停\n博园区伪\n不查都\n不查全\n不思四化\n布卖淫女\n部忙组阁\n部是这样\n才知道只生\n财众科技\n采花堂\n踩踏事\n苍山兰\n苍蝇水\n藏春阁\n藏獨\n操了嫂\n操嫂子\n策没有不\n插屁屁\n察象蚂\n拆迁灭\n车牌隐\n成人电\n成人卡通\n成人聊\n成人片\n成人视\n成人图\n成人文\n成人小\n城管灭\n惩公安\n惩贪难\n充气娃\n冲凉死\n抽着大中\n抽着芙蓉\n出成绩付\n出售发票\n出售军\n穿透仪器\n春水横溢\n纯度白\n纯度黄\n次通过考\n催眠水\n催情粉\n催情药\n催情藥\n挫仑\n达毕业证\n答案包\n答案提供\n打标语\n打错门\n打飞机专\n打死经过\n打死人\n打砸办公\n大鸡巴\n大雞巴\n大纪元\n大揭露\n大奶子\n大批贪官\n大肉棒\n大嘴歌\n代办发票\n代办各\n代办文\n代办学\n代办制\n代辦\n代表烦\n代開\n代考\n代理发票\n代理票据\n代您考\n代您考\n代写毕\n代写论\n代孕\n贷办\n贷借款\n贷开\n戴海静\n当代七整\n当官要精\n当官在于\n党的官\n党后萎\n党前干劲\n刀架保安\n导的情人\n导叫失\n导人的最\n导人最\n导小商\n到花心\n得财兼\n的同修\n灯草和\n等级證\n等屁民\n等人老百\n等人是老\n等人手术\n邓爷爷转\n邓玉娇\n地产之歌\n地下先烈\n地震哥\n帝国之梦\n递纸死\n点数优惠\n电狗\n电话监\n电鸡\n甸果敢\n蝶舞按\n丁香社\n丁子霖\n顶花心\n东北独立\n东复活\n东京热\n東京熱\n洞小口紧\n都当警\n都当小姐\n都进中央\n毒蛇钻\n独立台湾\n赌球网\n短信截\n对日强硬\n多美康\n躲猫猫\n俄羅斯\n恶势力操\n恶势力插\n恩氟烷\n儿园惨\n儿园砍\n儿园杀\n儿园凶\n二奶大\n发牌绝\n发票出\n发票代\n发票销\n發票\n法车仑\n法伦功\n法轮\n法轮佛\n法维权\n法一轮\n法院给废\n法正乾\n反测速雷\n反雷达测\n反屏蔽\n范燕琼\n方迷香\n防电子眼\n防身药水\n房贷给废\n仿真枪\n仿真证\n诽谤罪\n费私服\n封锁消\n佛同修\n夫妻交换\n福尔马林\n福娃的預\n福娃頭上\n福香巴\n府包庇\n府集中领\n妇销魂\n附送枪\n复印件生\n复印件制\n富民穷\n富婆给废\n改号软件\n感扑克\n冈本真\n肛交\n肛门是邻\n岡本真\n钢针狗\n钢珠枪\n港澳博球\n港馬會\n港鑫華\n高就在政\n高考黑\n高莺莺\n搞媛交\n告长期\n告洋状\n格证考试\n各类考试\n各类文凭\n跟踪器\n工程吞得\n工力人\n公安错打\n公安网监\n公开小姐\n攻官小姐\n共狗\n共王储\n狗粮\n狗屁专家\n鼓动一些\n乖乖粉\n官商勾\n官也不容\n官因发帖\n光学真题\n跪真相\n滚圆大乳\n国际投注\n国家妓\n国家软弱\n国家吞得\n国库折\n国一九五七\n國內美\n哈药直销\n海访民\n豪圈钱\n号屏蔽器\n和狗交\n和狗性\n和狗做\n黑火药的\n红色恐怖\n红外透视\n紅色恐\n胡江内斗\n胡紧套\n胡錦濤\n胡适眼\n胡耀邦\n湖淫娘\n虎头猎\n华国锋\n华门开\n化学扫盲\n划老公\n还会吹萧\n还看锦涛\n环球证件\n换妻\n皇冠投注\n黄冰\n浑圆豪乳\n活不起\n火车也疯\n机定位器\n机号定\n机号卫\n机卡密\n机屏蔽器\n基本靠吼\n绩过后付\n激情电\n激情短\n激情妹\n激情炮\n级办理\n级答案\n急需嫖\n集体打砸\n集体腐\n挤乳汁\n擠乳汁\n佳静安定\n家一样饱\n家属被打\n甲虫跳\n甲流了\n奸成瘾\n兼职上门\n监听器\n监听王\n简易炸\n江胡内斗\n江太上\n江系人\n江贼民\n疆獨\n蒋彦永\n叫自慰\n揭贪难\n姐包夜\n姐服务\n姐兼职\n姐上门\n金扎金\n金钟气\n津大地震\n津地震\n进来的罪\n京地震\n京要地震\n经典谎言\n精子射在\n警察被\n警察的幌\n警察殴打\n警察说保\n警车雷达\n警方包庇\n警用品\n径步枪\n敬请忍\n究生答案\n九龙论坛\n九评共\n酒象喝汤\n酒像喝汤\n就爱插\n就要色\n举国体\n巨乳\n据说全民\n绝食声\n军长发威\n军刺\n军品特\n军用手\n开邓选\n开锁工具\n開碼\n開票\n砍杀幼\n砍伤儿\n康没有不\n康跳楼\n考答案\n考后付款\n考机构\n考考邓\n考联盟\n考前答\n考前答案\n考前付\n考设备\n考试包过\n考试保\n考试答案\n考试机构\n考试联盟\n考试枪\n考研考中\n考中答案\n磕彰\n克分析\n克千术\n克透视\n空和雅典\n孔摄像\n控诉世博\n控制媒\n口手枪\n骷髅死\n快速办\n矿难不公\n拉登说\n拉开水晶\n来福猎\n拦截器\n狼全部跪\n浪穴\n老虎机\n雷人女官\n类准确答\n黎阳平\n李洪志\n李咏曰\n理各种证\n理是影帝\n理证件\n理做帐报\n力骗中央\n力月西\n丽媛离\n利他林\n连发手\n聯繫電\n炼大法\n两岸才子\n两会代\n两会又三\n聊视频\n聊斋艳\n了件渔袍\n猎好帮手\n猎枪销\n猎槍\n獵槍\n领土拿\n流血事\n六合彩\n六死\n六四事\n六月联盟\n龙湾事件\n隆手指\n陆封锁\n陆同修\n氯胺酮\n乱奸\n乱伦类\n乱伦小\n亂倫\n伦理大\n伦理电影\n伦理毛\n伦理片\n轮功\n轮手枪\n论文代\n罗斯小姐\n裸聊网\n裸舞视\n落霞缀\n麻古\n麻果配\n麻果丸\n麻将透\n麻醉狗\n麻醉枪\n麻醉槍\n麻醉藥\n蟆叫专家\n卖地财政\n卖发票\n卖银行卡\n卖自考\n漫步丝\n忙爱国\n猫眼工具\n毛一鲜\n媒体封锁\n每周一死\n美艳少妇\n妹按摩\n妹上门\n门按摩\n门保健\n門服務\n氓培训\n蒙汗药\n迷幻型\n迷幻药\n迷幻藥\n迷昏口\n迷昏药\n迷昏藥\n迷魂香\n迷魂药\n迷魂藥\n迷奸药\n迷情水\n迷情药\n迷藥\n谜奸药\n蜜穴\n灭绝罪\n民储害\n民九亿商\n民抗议\n明慧网\n铭记印尼\n摩小姐\n母乳家\n木齐针\n幕没有不\n幕前戲\n内射\n南充针\n嫩穴\n嫩阴\n泥马之歌\n你的西域\n拟涛哥\n娘两腿之间\n妞上门\n浓精\n怒的志愿\n女被人家搞\n女激情\n女技师\n女人和狗\n女任职名\n女上门\n女優\n鸥之歌\n拍肩神药\n拍肩型\n牌分析\n牌技网\n炮的小蜜\n陪考枪\n配有消\n喷尿\n嫖俄罗\n嫖鸡\n平惨案\n平叫到床\n仆不怕饮\n普通嘌\n期货配\n奇迹的黄\n奇淫散\n骑单车出\n气狗\n气枪\n汽狗\n汽枪\n氣槍\n铅弹\n钱三字经\n枪出售\n枪的参\n枪的分\n枪的结\n枪的制\n枪货到\n枪决女犯\n枪决现场\n枪模\n枪手队\n枪手网\n枪销售\n枪械制\n枪子弹\n强权政府\n强硬发言\n抢其火炬\n切听器\n窃听器\n禽流感了\n勤捞致\n氢弹手\n清除负面\n清純壆\n情聊天室\n情妹妹\n情视频\n情自拍\n氰化钾\n氰化钠\n请集会\n请示威\n请愿\n琼花问\n区的雷人\n娶韩国\n全真证\n群奸暴\n群起抗暴\n群体性事\n绕过封锁\n惹的国\n人权律\n人体艺\n人游行\n人在云上\n人真钱\n认牌绝\n任于斯国\n柔胸粉\n肉洞\n肉棍\n如厕死\n乳交\n软弱的国\n赛后骚\n三挫\n三级片\n三秒倒\n三网友\n三唑\n骚妇\n骚浪\n骚穴\n骚嘴\n扫了爷爷\n色电影\n色妹妹\n色视频\n色小说\n杀指南\n山涉黑\n煽动不明\n煽动群众\n上门激\n烧公安局\n烧瓶的\n韶关斗\n韶关玩\n韶关旭\n射网枪\n涉嫌抄袭\n深喉冰\n神七假\n神韵艺术\n生被砍\n生踩踏\n生肖中特\n圣战不息\n盛行在舞\n尸博\n失身水\n失意药\n狮子旗\n十八等\n十大谎\n十大禁\n十个预言\n十类人不\n十七大幕\n实毕业证\n实体娃\n实学历文\n士康事件\n式粉推\n视解密\n是躲猫\n手变牌\n手答案\n手狗\n手机跟\n手机监\n手机窃\n手机追\n手拉鸡\n手木仓\n手槍\n守所死法\n兽交\n售步枪\n售纯度\n售单管\n售弹簧刀\n售防身\n售狗子\n售虎头\n售火药\n售假币\n售健卫\n售军用\n售猎枪\n售氯胺\n售麻醉\n售冒名\n售枪支\n售热武\n售三棱\n售手枪\n售五四\n售信用\n售一元硬\n售子弹\n售左轮\n书办理\n熟妇\n术牌具\n双管立\n双管平\n水阎王\n丝护士\n丝情侣\n丝袜保\n丝袜恋\n丝袜美\n丝袜妹\n丝袜网\n丝足按\n司长期有\n司法黑\n私房写真\n死法分布\n死要见毛\n四博会\n四大扯\n个四小码\n苏家屯集\n诉讼集团\n素女心\n速代办\n速取证\n酸羟亚胺\n蹋纳税\n太王四神\n泰兴幼\n泰兴镇中\n泰州幼\n贪官也辛\n探测狗\n涛共产\n涛一样胡\n特工资\n特码\n特上门\n体透视镜\n替考\n替人体\n天朝特\n天鹅之旅\n天推广歌\n田罢工\n田田桑\n田停工\n庭保养\n庭审直播\n通钢总经\n偷電器\n偷肃贪\n偷听器\n偷偷贪\n头双管\n透视功能\n透视镜\n透视扑\n透视器\n透视眼镜\n透视药\n透视仪\n秃鹰汽\n突破封锁\n突破网路\n推油按\n脱衣艳\n瓦斯手\n袜按摩\n外透视镜\n外围赌球\n湾版假\n万能钥匙\n万人骚动\n王立军\n王益案\n网民案\n网民获刑\n网民诬\n微型摄像\n围攻警\n围攻上海\n维汉员\n维权基\n维权人\n维权谈\n委坐船\n谓的和谐\n温家堡\n温切斯特\n温影帝\n溫家寶\n瘟加饱\n瘟假饱\n文凭证\n文强\n纹了毛\n闻被控制\n闻封锁\n瓮安\n我的西域\n我搞台独\n乌蝇水\n无耻语录\n无码专\n五套功\n五月天\n午夜电\n午夜极\n武警暴\n武警殴\n武警已增\n务员答案\n务员考试\n雾型迷\n西藏限\n西服进去\n希脏\n习进平\n习晋平\n席复活\n席临终前\n席指着护\n洗澡死\n喜贪赃\n先烈纷纷\n现大地震\n现金投注\n线透视镜\n限制言\n陷害案\n陷害罪\n相自首\n香港论坛\n香港马会\n香港一类\n香港总彩\n硝化甘\n小穴\n校骚乱\n协晃悠\n写两会\n泄漏的内\n新建户\n新疆叛\n新疆限\n新金瓶\n新唐人\n信访专班\n信接收器\n兴中心幼\n星上门\n行长王益\n形透视镜\n型手枪\n姓忽悠\n幸运码\n性爱日\n性福情\n性感少\n性推广歌\n胸主席\n徐玉元\n学骚乱\n学位證\n學生妹\n丫与王益\n烟感器\n严晓玲\n言被劳教\n言论罪\n盐酸曲\n颜射\n恙虫病\n姚明进去\n要人权\n要射精了\n要射了\n要泄了\n夜激情\n液体炸\n一小撮别\n遗情书\n蚁力神\n益关注组\n益受贿\n阴间来电\n陰唇\n陰道\n陰戶\n淫魔舞\n淫情女\n淫肉\n淫騷妹\n淫兽\n淫兽学\n淫水\n淫穴\n隐形耳\n隐形喷剂\n应子弹\n婴儿命\n咏妓\n用手枪\n幽谷三\n游精佑\n有奶不一\n右转是政\n幼齿类\n娱乐透视\n愚民同\n愚民政\n与狗性\n玉蒲团\n育部女官\n冤民大\n鸳鸯洗\n园惨案\n园发生砍\n园砍杀\n园凶杀\n园血案\n原一九五七\n原装弹\n袁腾飞\n晕倒型\n韵徐娘\n遭便衣\n遭到警\n遭警察\n遭武警\n择油录\n曾道人\n炸弹教\n炸弹遥控\n炸广州\n炸立交\n炸药的制\n炸药配\n炸药制\n张春桥\n找枪手\n找援交\n找政法委副\n赵紫阳\n针刺案\n针刺伤\n针刺事\n针刺死\n侦探设备\n真钱斗地\n真钱投注真善忍\n真实文凭\n真实资格\n震惊一个民\n震其国土\n证到付款\n证件办\n证件集团\n证生成器\n证书办\n证一次性\n政府操\n政论区\n證件\n植物冰\n殖器护\n指纹考勤\n指纹膜\n指纹套\n至国家高\n志不愿跟\n制服诱\n制手枪\n制证定金\n制作证件\n中的班禅\n中共黑\n中国不强\n种公务员\n种学历证\n众像羔\n州惨案\n州大批贪\n州三箭\n宙最高法\n昼将近\n主席忏\n住英国房\n助考\n助考网\n专业办理\n专业代\n专业代写\n专业助\n转是政府\n赚钱资料\n装弹甲\n装枪套\n装消音\n着护士的胸\n着涛哥\n姿不对死\n资格證\n资料泄\n梓健特药\n字牌汽\n自己找枪\n自慰用\n自由圣\n自由亚\n总会美女\n足球玩法\n最牛公安\n醉钢枪\n醉迷药\n醉乙醚\n尊爵粉\n左转是政\n作弊器\n作各种证\n作硝化甘\n唑仑\n做爱小\n做原子弹\n做证件'),('fof-follow-tags.following_page_default',''),('fof-links.show_icons_only_on_mobile','0'),('fof-nightmode.default_theme','0'),('fof-polls.allowOptionImage','1'),('fof-pretty-mail.mailhtml','<html>\n    <head>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n        <style type=\"text/css\">\n            body {\n                font-family: \'Open Sans\', sans-serif;\n                background: white;\n                color: #426799;\n                margin: 0;\n                padding: 0;\n            }\n            .content {\n                box-sizing: border-box;\n                width: 100%;\n                max-width: 500px;\n                margin: 0 auto;\n                padding: 10px 20px;\n            }\n            .header {\n                border-bottom: 1px solid #e8ecf3;\n             }\n             .header a {\n                color: {{ $settings->get(\'theme_primary_color\') }};\n                text-decoration: none;\n             }\n             .footer {\n                background: #e8ecf3;\n             }\n        </style>\n        @if ($forumStyle !== \'\')\n        <style>\n            {!! $forumStyle !!}\n        </style>\n        @endif\n    </head>\n    <body>\n    <div class=\"header\">\n        <div class=\"content\">\n            <a href=\"{{ $url->to(\'forum\')->base() }}\">{{ $settings->get(\'forum_title\') }}</a>\n        </div>\n    </div>\n    <div class=\"content\">\n        {!! $body !!}\n    </div>\n    <div class=\"footer\">\n        <div class=\"content\">\n            <p>Sent from {{ $settings->get(\'forum_title\') }} using FoF Pretty Mail</p>\n        </div>\n    </div>\n    </body>\n</html>\n'),('fof-pretty-mail.newPost','<html>\n    <head>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n        <style type=\"text/css\">\n            body {\n                font-family: \'Open Sans\', sans-serif;\n                background: white;\n                color: #426799;\n                margin: 0;\n                padding: 0;\n            }\n            .content {\n                box-sizing: border-box;\n                width: 100%;\n                max-width: 500px;\n                margin: 0 auto;\n                padding: 10px 20px;\n            }\n            .header {\n                border-bottom: 1px solid #e8ecf3;\n            }\n            .header a {\n                color: {{ $settings->get(\'theme_primary_color\') }};\n                text-decoration: none;\n            }\n            .footer {\n                background: #e8ecf3;\n            }\n        </style>\n        <style>\n            {!! $forumStyle !!}\n        </style>\n    </head>\n    <body>\n    <div class=\"header\">\n        <div class=\"content\">\n            <a href=\"{{ $url->to(\'forum\')->base() }}\">{{ $settings->get(\'forum_title\') }}</a>\n        </div>\n    </div>\n    <div class=\"content\">\n        <div class=\"info\">\n            <p>Hey {!! $user->display_name !!}!</p>\n\n            <p><a href=\"{{ $url->to(\'forum\')->route(\'user\', [\'username\' => $blueprint->post->user->username]) }}\">{!! $blueprint->post->user->username !!}</a> made a post in a discussion you\'re following: <a href=\"{{ $url->to(\'forum\')->route(\'discussion\', [\'id\' => $blueprint->post->discussion_id, \'near\' => $blueprint->post->number]) }}\">{!! $blueprint->post->discussion->title !!}</a></p>\n\n            ---\n\n        </div>\n        <br/>\n        <div class=\"post-content\">\n            {!! $blueprint->post->formatContent() !!}\n        </div>\n        <br/>\n        <div class=\"info\">\n            ---\n\n            <p>You won\'t receive any more notifications about this discussion until you\'re up-to-date.</p>\n        </div>\n    </div>\n    <div class=\"footer\">\n        <div class=\"content\">\n            <p>Sent from {{ $settings->get(\'forum_title\') }} using FoF Pretty Mail</p>\n        </div>\n    </div>\n    </body>\n</html>\n'),('fof-pretty-mail.postMentioned','<html>\n    <head>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n        <style type=\"text/css\">\n            body {\n                font-family: \'Open Sans\', sans-serif;\n                background: white;\n                color: #426799;\n                margin: 0;\n                padding: 0;\n            }\n            .content {\n                box-sizing: border-box;\n                width: 100%;\n                max-width: 500px;\n                margin: 0 auto;\n                padding: 10px 20px;\n            }\n            .header {\n                border-bottom: 1px solid #e8ecf3;\n            }\n            .header a {\n                color: {{ $settings->get(\'theme_primary_color\') }};\n                text-decoration: none;\n            }\n            .footer {\n                background: #e8ecf3;\n            }\n        </style>\n        <style>\n            {!! $forumStyle !!}\n        </style>\n    </head>\n    <body>\n    <div class=\"header\">\n        <div class=\"content\">\n            <a href=\"{{ $url->to(\'forum\')->base() }}\">{{ $settings->get(\'forum_title\') }}</a>\n        </div>\n    </div>\n    <div class=\"content\">\n        <div class=\"info\">\n            <p>Hey {!! $user->display_name !!}!</p>\n\n            <p><a href=\"{{ $url->to(\'forum\')->route(\'user\', [\'username\' => $blueprint->reply->user->username]) }}\">{!! $blueprint->reply->user->username !!}</a> replied to your post (#{!! $blueprint->post->number !!}) in <a href=\"{{ $url->to(\'forum\')->route(\'discussion\', [\'id\' => $blueprint->post->discussion_id, \'near\' => $blueprint->reply->number]) }}\">{!! $blueprint->post->discussion->title !!}</a>.</p>\n\n            ---\n\n        </div>\n        <br/>\n        <div class=\"post-content\">\n            {!! $blueprint->reply->formatContent() !!}\n        </div>\n        <br/>\n    </div>\n    <div class=\"footer\">\n        <div class=\"content\">\n            <p>Sent from {{ $settings->get(\'forum_title\') }} using FoF Pretty Mail</p>\n        </div>\n    </div>\n    </body>\n</html>'),('fof-pretty-mail.userMentioned','<html>\n    <head>\n        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n        <style type=\"text/css\">\n            body {\n                font-family: \'Open Sans\', sans-serif;\n                background: white;\n                color: #426799;\n                margin: 0;\n                padding: 0;\n            }\n            .content {\n                box-sizing: border-box;\n                width: 100%;\n                max-width: 500px;\n                margin: 0 auto;\n                padding: 10px 20px;\n            }\n            .header {\n                border-bottom: 1px solid #e8ecf3;\n            }\n            .header a {\n                color: {{ $settings->get(\'theme_primary_color\') }};\n                text-decoration: none;\n            }\n            .footer {\n                background: #e8ecf3;\n            }\n        </style>\n        <style>\n            {!! $forumStyle !!}\n        </style>\n    </head>\n    <body>\n    <div class=\"header\">\n        <div class=\"content\">\n            <a href=\"{{ $url->to(\'forum\')->base() }}\">{{ $settings->get(\'forum_title\') }}</a>\n        </div>\n    </div>\n    <div class=\"content\">\n        <div class=\"info\">\n            <p>Hey {!! $user->display_name !!}!</p>\n\n            <p><a href=\"{{ $url->to(\'forum\')->route(\'user\', [\'username\' => $blueprint->post->user->username]) }}\">{!! $blueprint->post->user->username !!}</a> mentioned you in a post in <a href=\"{{ $url->to(\'forum\')->route(\'discussion\', [\'id\' => $blueprint->post->discussion_id, \'near\' => $blueprint->post->number]) }}\">{!! $blueprint->post->discussion->title !!}</a>.</p>\n\n            ---\n\n        </div>\n        <br/>\n        <div class=\"post-content\">\n            {!! $blueprint->post->formatContent() !!}\n        </div>\n        <br/>\n    </div>\n    <div class=\"footer\">\n        <div class=\"content\">\n            <p>Sent from {{ $settings->get(\'forum_title\') }} using FoF Pretty Mail</p>\n        </div>\n    </div>\n    </body>\n</html>\n'),('fof-share-social.canonical-urls',''),('fof-share-social.networks.facebook','0'),('fof-share-social.networks.linkedin',''),('fof-share-social.networks.my_mail',''),('fof-share-social.networks.native','1'),('fof-share-social.networks.odnoklassniki',''),('fof-share-social.networks.qq','1'),('fof-share-social.networks.qzone','1'),('fof-share-social.networks.reddit',''),('fof-share-social.networks.telegram','1'),('fof-share-social.networks.twitter','1'),('fof-share-social.networks.vkontakte',''),('fof-share-social.networks.whatsapp',''),('fof-sitemap.frequency','daily'),('fof-sitemap.mode','run'),('fof-terms.date-format',''),('fof-terms.hide-updated-at',''),('fof-terms.signup-legal-text','阅读并同意'),('fof-user-directory-link',''),('fof-user-directory.default-sort','most_discussions'),('fof-user-directory.use-small-cards',''),('fofNightMode.show_theme_toggle_on_header_always','1'),('forum_description','Foresee Studio工作室官方论坛'),('forum_keywords','人工智能研发、创新技术、机器学习、计算机视觉、AI绘图、大语言模型、工程师社区、设计思维、行业应用、技术创新、智慧探索、未来科技、高质量解决方案、持续创新、科技前沿'),('forum_title','Foresee Studio论坛'),('ianm-level-ranks.pointsText','Lv.'),('ianm-synopsis.rich-excerpts',''),('itnt-uitab.home_page','/'),('keven1024-csdn.conditional_to_see','0'),('keven1024-csdn.content_visibility','conditional'),('keven1024-csdn.copy_add_copyright','1'),('keven1024-csdn.divisible_copy_all','0'),('keven1024-csdn.divisible_copy_code','0'),('keven1024-csdn.divisible_event','0'),('keven1024-csdn.divisible_f12','1'),('keven1024-csdn.divisible_image','0'),('keven1024-csdn.divisible_right_key','0'),('keven1024-csdn.floor_background_refresh','0'),('keven1024-csdn.floor_background_webgl','0'),('keven1024-csdn.group_to_see','0'),('mail_driver','smtp'),('mail_encryption','ssl'),('mail_from','jlstudioemail@163.com'),('mail_host','smtp.163.com'),('mail_password','VYUJNTROMCKCMPWL'),('mail_port','465'),('mail_username','jlstudioemail@163.com'),('michaelbelgium-discussionviews.abbr_numbers',''),('michaelbelgium-discussionviews.ignore_crawlers',''),('michaelbelgium-discussionviews.max_listcount','3'),('michaelbelgium-discussionviews.show_footer_viewlist',''),('michaelbelgium-discussionviews.track_unique',''),('seo_allow_all_bots',''),('seo_post_crawler','1'),('seo_review_settings','1706716800'),('seo_reviewed_post_crawler','1'),('seo_reviewed_search_engines','1'),('seo_social_media_image_path','site-image-toatu8qe.png'),('seo_twitter_card_size','summary'),('show_language_selector','1'),('slug_driver_Flarum\\Discussion\\Discussion','id'),('slug_driver_Flarum\\User\\User','id'),('the-turk-flamoji.auto_hide','1'),('the-turk-flamoji.emoji_data','en'),('the-turk-flamoji.emoji_style','twemoji'),('the-turk-flamoji.emoji_version','12.1'),('the-turk-flamoji.initial_category','smileys'),('the-turk-flamoji.recents_count','50'),('the-turk-flamoji.show_category_buttons','1'),('the-turk-flamoji.show_preview','0'),('the-turk-flamoji.show_recents','1'),('the-turk-flamoji.show_search','1'),('the-turk-flamoji.show_variants','1'),('the-turk-flamoji.specify_categories','[\"smileys\",\"people\",\"animals\",\"food\",\"activities\",\"travel\",\"objects\",\"symbols\",\"flags\"]'),('the-turk-mathren.enable_fleqn','0'),('the-turk-mathren.enable_leqno','1'),('the-turk-mathren.macros',''),('the-turk-mathren.throw_on_error','1'),('theme_colored_header','1'),('theme_dark_mode','0'),('theme_primary_color','#506cbc'),('theme_secondary_color','#6c8ccc'),('undefined',''),('version','1.8.4'),('welcome_message','登高不傲，居低不怨，保持谦卑<br> 一同追寻智慧，在使命中寻找意义，对抗虚无与虚荣'),('welcome_title','Welcome to Foresee Studio论坛');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tag_user`
--

DROP TABLE IF EXISTS `tag_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_user` (
  `user_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `marked_as_read_at` datetime DEFAULT NULL,
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `subscription` enum('follow','lurk','ignore','hide') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`,`tag_id`),
  KEY `tag_user_tag_id_foreign` (`tag_id`),
  KEY `tag_user_user_id_subscription_index` (`user_id`,`subscription`),
  KEY `tag_user_subscription_index` (`subscription`),
  CONSTRAINT `tag_user_tag_id_foreign` FOREIGN KEY (`tag_id`) REFERENCES `tags` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tag_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tag_user`
--

LOCK TABLES `tag_user` WRITE;
/*!40000 ALTER TABLE `tag_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `tag_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `color` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_path` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_mode` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `parent_id` int(10) unsigned DEFAULT NULL,
  `default_sort` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_restricted` tinyint(1) NOT NULL DEFAULT '0',
  `is_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `discussion_count` int(10) unsigned NOT NULL DEFAULT '0',
  `last_posted_at` datetime DEFAULT NULL,
  `last_posted_discussion_id` int(10) unsigned DEFAULT NULL,
  `last_posted_user_id` int(10) unsigned DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_qna` tinyint(1) NOT NULL DEFAULT '0',
  `qna_reminders` tinyint(1) NOT NULL DEFAULT '0',
  `is_article_series` tinyint(1) NOT NULL DEFAULT '0',
  `excerpt_length` int(10) unsigned DEFAULT NULL,
  `rich_excerpts` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tags_slug_unique` (`slug`),
  KEY `tags_parent_id_foreign` (`parent_id`),
  KEY `tags_last_posted_user_id_foreign` (`last_posted_user_id`),
  KEY `tags_last_posted_discussion_id_foreign` (`last_posted_discussion_id`),
  CONSTRAINT `tags_last_posted_discussion_id_foreign` FOREIGN KEY (`last_posted_discussion_id`) REFERENCES `discussions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tags_last_posted_user_id_foreign` FOREIGN KEY (`last_posted_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `tags_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `tags` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (1,' 站务','SYSOP','论坛事务处理','#e55d52',NULL,NULL,0,NULL,NULL,0,0,10,'2023-12-31 08:43:46',19,1,'fas fa-clipboard-list',NULL,'2023-12-31 08:43:46',0,0,1,NULL,NULL),(2,' 教程','course','course','#4fa7bc',NULL,NULL,1,NULL,NULL,0,0,2,'2023-12-27 05:48:10',3,1,'fas fa-book','2023-12-27 14:35:17','2023-12-27 14:42:01',0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_email_confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar_url` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `preferences` blob,
  `joined_at` datetime DEFAULT NULL,
  `last_seen_at` datetime DEFAULT NULL,
  `marked_all_as_read_at` datetime DEFAULT NULL,
  `read_notifications_at` datetime DEFAULT NULL,
  `discussion_count` int(10) unsigned NOT NULL DEFAULT '0',
  `comment_count` int(10) unsigned NOT NULL DEFAULT '0',
  `read_flags_at` datetime DEFAULT NULL,
  `suspended_until` datetime DEFAULT NULL,
  `suspend_reason` text COLLATE utf8mb4_unicode_ci,
  `suspend_message` text COLLATE utf8mb4_unicode_ci,
  `first_post_approval_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `first_discussion_approval_count` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `best_answer_count` int(10) unsigned DEFAULT NULL,
  `invite_code` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_buttons` longtext COLLATE utf8mb4_unicode_ci,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `cover` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_joined_at_index` (`joined_at`),
  KEY `users_last_seen_at_index` (`last_seen_at`),
  KEY `users_discussion_count_index` (`discussion_count`),
  KEY `users_comment_count_index` (`comment_count`),
  KEY `users_nickname_index` (`nickname`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','John Tao','2137299207@qq.com',1,'$2y$10$w7QxQ.tFdgFWvNyZeIgVGOJcm8IDWIAZRserw1Ljc6GYsPdYZW0Q.','O6gkxPawmHj9dr0n.png',_binary '{\"followAfterReply\":false,\"flarum-subscriptions.notify_for_all_posts\":false,\"followTagsPageDefault\":null,\"showSynopsisExcerpts\":true,\"showSynopsisExcerptsOnMobile\":false,\"fofNightMode\":1,\"fofNightMode_perDevice\":false,\"draftAutosaveEnable\":true,\"draftAutosaveInterval\":5,\"notify_discussionRenamed_alert\":true,\"notify_userSuspended_alert\":true,\"notify_userSuspended_email\":true,\"notify_userUnsuspended_alert\":true,\"notify_userUnsuspended_email\":true,\"notify_postMentioned_alert\":true,\"notify_postMentioned_email\":false,\"notify_userMentioned_alert\":true,\"notify_userMentioned_email\":true,\"notify_groupMentioned_alert\":true,\"notify_groupMentioned_email\":false,\"notify_newPost_alert\":true,\"notify_newPost_email\":true,\"notify_discussionLocked_alert\":true,\"notify_newDiscussionInTag_alert\":true,\"notify_newDiscussionInTag_email\":true,\"notify_newPostInTag_alert\":true,\"notify_newPostInTag_email\":true,\"notify_newDiscussionTag_alert\":true,\"notify_newDiscussionTag_email\":true,\"notify_discussionCreated_alert\":true,\"notify_discussionCreated_email\":true,\"notify_postCreated_alert\":false,\"notify_postCreated_email\":false,\"notify_postUnapproved_alert\":false,\"notify_postUnapproved_email\":true,\"notify_userCreated_alert\":false,\"notify_userCreated_email\":false,\"notify_postFlagged_alert\":true,\"notify_postFlagged_email\":true,\"notify_selectBestAnswer_alert\":true,\"notify_selectBestAnswer_email\":true,\"notify_awardedBestAnswer_alert\":true,\"notify_awardedBestAnswer_email\":false,\"notify_bestAnswerInDiscussion_alert\":false,\"notify_bestAnswerInDiscussion_email\":false,\"notify_postLiked_alert\":true,\"discloseOnline\":true,\"indexProfile\":true,\"locale\":\"zh-Hans\"}','2023-12-27 02:32:07','2024-01-02 13:01:26',NULL,'2024-01-02 03:16:42',11,11,'2023-12-28 05:41:51',NULL,NULL,NULL,0,0,0,NULL,NULL,'长恨此身非我有，何时忘却营营。小舟从此逝，书海寄余生。','cLnXsQiJUdA1JkXk.jpg'),(2,'Wrecking-Midnight','先知科技工作室','Wrecking-Midnight@outlook.com',1,'$2y$10$RNV1QROvZrirvxw5uJDpuOcQNPLb83ZuweGECYJWMeplPd7XUxPl6','VAWKBZi4jOnda8ZL.png',_binary '{\"followAfterReply\":false,\"flarum-subscriptions.notify_for_all_posts\":false,\"followTagsPageDefault\":null,\"fofNightMode\":0,\"fofNightMode_perDevice\":false,\"draftAutosaveEnable\":false,\"draftAutosaveInterval\":6,\"notify_discussionRenamed_alert\":true,\"notify_userSuspended_alert\":true,\"notify_userSuspended_email\":true,\"notify_userUnsuspended_alert\":true,\"notify_userUnsuspended_email\":true,\"notify_postMentioned_alert\":true,\"notify_postMentioned_email\":false,\"notify_userMentioned_alert\":true,\"notify_userMentioned_email\":false,\"notify_groupMentioned_alert\":true,\"notify_groupMentioned_email\":false,\"notify_newPost_alert\":true,\"notify_newPost_email\":true,\"notify_discussionLocked_alert\":true,\"notify_newDiscussionInTag_alert\":true,\"notify_newDiscussionInTag_email\":true,\"notify_newPostInTag_alert\":true,\"notify_newPostInTag_email\":true,\"notify_newDiscussionTag_alert\":true,\"notify_newDiscussionTag_email\":true,\"notify_discussionCreated_alert\":false,\"notify_discussionCreated_email\":false,\"notify_postCreated_alert\":false,\"notify_postCreated_email\":false,\"notify_postUnapproved_alert\":false,\"notify_postUnapproved_email\":false,\"notify_userCreated_alert\":false,\"notify_userCreated_email\":false,\"notify_postFlagged_alert\":false,\"notify_postFlagged_email\":false,\"notify_selectBestAnswer_alert\":true,\"notify_selectBestAnswer_email\":true,\"notify_awardedBestAnswer_alert\":true,\"notify_awardedBestAnswer_email\":false,\"notify_bestAnswerInDiscussion_alert\":false,\"notify_bestAnswerInDiscussion_email\":false,\"notify_postLiked_alert\":true,\"discloseOnline\":true,\"indexProfile\":true,\"locale\":null}','2023-12-28 00:52:16','2023-12-28 08:05:40',NULL,NULL,3,3,NULL,NULL,NULL,NULL,0,2,0,NULL,NULL,NULL,NULL),(3,'JinJin',NULL,'1804576009@qq.com',1,'$2y$10$9K7ahSKvhENVU68hUd4JCelhcIFbfmjWr1m5SB6tMZJvyeRVZnnu2','8eGv53WmGyvVgYnR.png',_binary '{\"followAfterReply\":false,\"flarum-subscriptions.notify_for_all_posts\":false,\"followTagsPageDefault\":null,\"fofNightMode\":1,\"fofNightMode_perDevice\":false,\"draftAutosaveEnable\":false,\"draftAutosaveInterval\":6,\"notify_discussionRenamed_alert\":true,\"notify_userSuspended_alert\":true,\"notify_userSuspended_email\":true,\"notify_userUnsuspended_alert\":true,\"notify_userUnsuspended_email\":true,\"notify_postMentioned_alert\":true,\"notify_postMentioned_email\":false,\"notify_userMentioned_alert\":true,\"notify_userMentioned_email\":false,\"notify_groupMentioned_alert\":true,\"notify_groupMentioned_email\":false,\"notify_newPost_alert\":true,\"notify_newPost_email\":true,\"notify_discussionLocked_alert\":true,\"notify_newDiscussionInTag_alert\":true,\"notify_newDiscussionInTag_email\":true,\"notify_newPostInTag_alert\":true,\"notify_newPostInTag_email\":true,\"notify_newDiscussionTag_alert\":true,\"notify_newDiscussionTag_email\":true,\"notify_discussionCreated_alert\":false,\"notify_discussionCreated_email\":false,\"notify_postCreated_alert\":false,\"notify_postCreated_email\":false,\"notify_postUnapproved_alert\":false,\"notify_postUnapproved_email\":false,\"notify_userCreated_alert\":false,\"notify_userCreated_email\":false,\"notify_postFlagged_alert\":false,\"notify_postFlagged_email\":false,\"notify_selectBestAnswer_alert\":true,\"notify_selectBestAnswer_email\":true,\"notify_awardedBestAnswer_alert\":true,\"notify_awardedBestAnswer_email\":false,\"notify_bestAnswerInDiscussion_alert\":false,\"notify_bestAnswerInDiscussion_email\":false,\"notify_postLiked_alert\":true,\"discloseOnline\":true,\"indexProfile\":true,\"locale\":null}','2023-12-28 08:37:29','2023-12-29 07:05:57','2023-12-28 08:38:37','2023-12-28 08:38:44',0,0,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users_notes`
--

DROP TABLE IF EXISTS `users_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_notes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `note` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_by_user_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `users_notes_added_by_user_id_foreign` (`added_by_user_id`),
  CONSTRAINT `users_notes_added_by_user_id_foreign` FOREIGN KEY (`added_by_user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_notes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_notes`
--

LOCK TABLES `users_notes` WRITE;
/*!40000 ALTER TABLE `users_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_notes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'flarum'
--

--
-- Dumping routines for database 'flarum'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-02 21:03:16
